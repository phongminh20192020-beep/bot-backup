"use strict";

// ─── Local self-signed certificate generator ──────────────────────────────────
// Standalone, run manually: node scripts/generate-cert.js
// Not part of the bot's normal startup -- this only needs to run once (or
// whenever you want to regenerate/rotate the cert). Generates its own
// keypair and signs its own certificate locally -- no CA, no network call,
// no dependency on anything external. Browsers will show a "not trusted"
// warning for it (expected for any self-signed cert -- that warning is what
// self-signed means), but it's enough to run the dashboard over HTTPS
// locally/on a private network.
//
// Requires the "selfsigned" package -- install with:
//   npm install --save-dev selfsigned

const fs   = require("fs");
const path = require("path");
const selfsigned = require("selfsigned");

const OUT_DIR   = path.join(__dirname, "..", "certs");
const KEY_PATH  = path.join(OUT_DIR, "key.pem");
const CERT_PATH = path.join(OUT_DIR, "cert.pem");

const attrs = [{ name: "commonName", value: process.env.CERT_COMMON_NAME || "localhost" }];

const pems = selfsigned.generate(attrs, {
  days:      parseInt(process.env.CERT_VALID_DAYS || "825", 10), // ~2.25 years, under browsers' max cert lifetime
  keySize:   2048,
  algorithm: "sha256",
  extensions: [
    { name: "basicConstraints", cA: false },
    { name: "keyUsage", keyCertSign: false, digitalSignature: true, keyEncipherment: true },
    {
      name: "subjectAltName",
      altNames: [
        { type: 2, value: "localhost" },   // DNS
        { type: 7, ip: "127.0.0.1" },       // IP
      ],
    },
  ],
});

if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

fs.writeFileSync(KEY_PATH, pems.private, { mode: 0o600 });
fs.writeFileSync(CERT_PATH, pems.cert, { mode: 0o644 });

console.log(`[Cert] Generated a self-signed certificate:`);
console.log(`  Key:  ${KEY_PATH}`);
console.log(`  Cert: ${CERT_PATH}`);
console.log(`  Valid for: ${process.env.CERT_VALID_DAYS || "825"} days`);
console.log(`\nBrowsers will flag this as untrusted -- that's expected for a self-signed cert (no CA vouches for it).`);
console.log(`The dashboard server will pick these up automatically if they exist in certs/ next time it starts.`);
