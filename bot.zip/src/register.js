// Standalone script for manually registering slash commands, e.g. `npm run register`.
// Not needed on hosts without shell access -- ready.js already registers
// commands automatically on every startup. Kept for local development and
// hosts that do give shell access.
require("dotenv").config();
const { registerCommands } = require("./utils/registerCommands");

(async () => {
  console.log("Registering slash commands globally...");
  const count = await registerCommands({
    token: process.env.DISCORD_TOKEN,
    clientId: process.env.CLIENT_ID,
  });
  console.log(`Done — registered ${count} command(s).`);
})().catch(console.error);
