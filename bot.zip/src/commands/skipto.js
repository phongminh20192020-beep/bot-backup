"use strict";

const { SlashCommandBuilder } = require("discord.js");
const { formatDuration } = require("../utils/helpers");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("skipto")
    .setDescription("Skip directly to a specific song in the queue")
    .addIntegerOption(o =>
      o.setName("position")
        .setDescription("Queue position to jump to (see /queue for numbers)")
        .setRequired(true)
        .setMinValue(1)
    ),

  async execute(interaction, client) {
    await interaction.deferReply();

    const player = client.lavalink.getPlayer(interaction.guildId);
    if (!player || !player.queue.current)
      return interaction.editReply("Nothing is currently playing.");

    const tracks = player.queue.tracks;
    if (!tracks.length)
      return interaction.editReply("The queue is empty — there's nothing to skip to.");

    const position = interaction.options.getInteger("position", true);
    if (position > tracks.length) {
      return interaction.editReply(
        `There ${tracks.length === 1 ? "is" : "are"} only **${tracks.length}** track${tracks.length !== 1 ? "s" : ""} in the queue. Try a position between 1 and ${tracks.length}.`
      );
    }

    const target  = tracks[position - 1];
    const skipped = position - 1; // tracks discarded along the way

    try {
      // player.skip(n) treats n as the 1-indexed position in queue.tracks to land on
      await player.skip(position);
      const title = target.info.title.length > 60
        ? target.info.title.slice(0, 59) + "…"
        : target.info.title;

      await interaction.editReply(
        `<:Skip:1537804163860275210> Skipped to **${title}** — ${formatDuration(target.info.duration)}` +
        (skipped > 0 ? ` *(skipped over ${skipped} track${skipped !== 1 ? "s" : ""})*` : "")
      );
    } catch (err) {
      console.error("[SkipTo] player.skip() error:", err.message);
      await interaction.editReply("Couldn't skip — the audio node isn't responding right now. Try again in a moment.");
    }
  },
};
