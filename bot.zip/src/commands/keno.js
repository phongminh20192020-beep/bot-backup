"use strict";

const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { getBalance, addCoins, removeCoins } = require("../utils/economy");
const { renderKenoBoard } = require("../utils/kenoRender");

const IMAGE_NAME = "keno.png";

const POOL_SIZE   = 40;
const DRAWN_COUNT = 20;
const TARGET_RTP  = 0.93;

function factorial(n) { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; }
function comb(n, r) {
  if (r < 0 || r > n) return 0;
  return factorial(n) / (factorial(r) * factorial(n - r));
}

/** Exact probability of matching exactly `m` of `k` picks when `drawn` of `pool` are drawn. */
function hyperProb(pool, drawn, k, m) {
  return (comb(k, m) * comb(pool - k, drawn - m)) / comb(pool, drawn);
}

/**
 * Build a paytable for a given number of picks `k`, calibrated so the exact
 * expected value (computed from the true hypergeometric distribution, not
 * simulated) lands at TARGET_RTP regardless of k. Matches at or below the
 * threshold pay nothing; matches above it are weighted by squared distance
 * above threshold so the payout curve accelerates toward a full match,
 * same shape as a real keno paytable.
 */
function buildPaytable(k, targetRtp = TARGET_RTP) {
  const threshold = Math.max(0, Math.ceil(k / 2) - 1);
  const probs = [];
  const weights = [];
  let weightedProbSum = 0;

  for (let m = 0; m <= k; m++) {
    const p = hyperProb(POOL_SIZE, DRAWN_COUNT, k, m);
    const w = m > threshold ? (m - threshold) ** 2 : 0;
    probs.push(p);
    weights.push(w);
    weightedProbSum += p * w;
  }

  const scale = weightedProbSum > 0 ? targetRtp / weightedProbSum : 0;
  return weights.map(w => Math.round(w * scale * 100) / 100);
}

function drawNumbers(count) {
  const pool = Array.from({ length: POOL_SIZE }, (_, i) => i + 1);
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, count);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("keno")
    .setDescription(`Pick 1-10 numbers from 1-${POOL_SIZE}; ${DRAWN_COUNT} get drawn, matches pay out`)
    .addStringOption(o =>
      o.setName("picks")
        .setDescription(`1-10 numbers, comma-separated (1-${POOL_SIZE}), e.g. "3,7,12,19"`)
        .setRequired(true)
    )
    .addIntegerOption(o =>
      o.setName("bet")
        .setDescription("How many coins to wager")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1_000_000)
    ),

  async execute(interaction) {
    const raw = interaction.options.getString("picks", true);
    const bet = interaction.options.getInteger("bet", true);

    const picks = [...new Set(raw.split(",").map(s => parseInt(s.trim(), 10)))];

    if (picks.some(n => Number.isNaN(n) || n < 1 || n > POOL_SIZE)) {
      return interaction.reply({ content: `Picks must be whole numbers between 1 and ${POOL_SIZE}.`, ephemeral: true });
    }
    if (picks.length < 1 || picks.length > 10) {
      return interaction.reply({ content: "Pick between 1 and 10 unique numbers.", ephemeral: true });
    }

    const balance = getBalance(interaction.user.id);
    if (balance < bet) {
      return interaction.reply({
        content: `You don't have enough coins for that bet — your balance is **${balance.toLocaleString()}** coins.`,
        ephemeral: true,
      });
    }

    removeCoins(interaction.user.id, bet);

    const drawn   = drawNumbers(DRAWN_COUNT);
    const matches = picks.filter(n => drawn.includes(n));
    const paytable = buildPaytable(picks.length);
    const multiplier = paytable[matches.length];

    const winnings = Math.floor(bet * multiplier);
    if (winnings > 0) addCoins(interaction.user.id, winnings);
    const newBalance = getBalance(interaction.user.id);

    const status = multiplier > 0
      ? `**${matches.length}/${picks.length} matched!** You win **${winnings.toLocaleString()}** coins (${multiplier}x). Balance: **${newBalance.toLocaleString()}**.`
      : `**${matches.length}/${picks.length} matched.** You lose your **${bet.toLocaleString()}** coin bet. Balance: **${newBalance.toLocaleString()}**.`;

    const embed = new EmbedBuilder()
      .setTitle("🔢 Keno")
      .setDescription(status)
      .setImage(`attachment://${IMAGE_NAME}`)
      .setFooter({ text: `Bet: ${bet.toLocaleString()} coins` });

    const image = renderKenoBoard(picks, drawn);
    const attachment = new AttachmentBuilder(image, { name: IMAGE_NAME });

    await interaction.reply({ embeds: [embed], files: [attachment] });
  },
};
