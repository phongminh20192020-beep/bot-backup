"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const { getBalance, addCoins, removeCoins } = require("../utils/economy");
const { renderDiceDuel } = require("../utils/diceduelRender");

const IMAGE_NAME = "diceduel.png";

const rollPair = () => [1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6)];

module.exports = {
  data: new SlashCommandBuilder()
    .setName("diceduel")
    .setDescription("Roll 2d6 against the dealer; win and you can push your luck for double or nothing")
    .addIntegerOption(o =>
      o.setName("bet")
        .setDescription("How many coins to wager")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1_000_000)
    ),

  async execute(interaction) {
    const bet     = interaction.options.getInteger("bet", true);
    const balance = getBalance(interaction.user.id);

    if (balance < bet) {
      return interaction.reply({
        content: `You don't have enough coins for that bet — your balance is **${balance.toLocaleString()}** coins.`,
        ephemeral: true,
      });
    }

    removeCoins(interaction.user.id, bet);

    let pot = bet; // grows each successful double-or-nothing
    let round = 0;

    const buildPayload = (playerDice, dealerDice, statusText, { disabled = false, showButtons = false } = {}) => {
      const image = renderDiceDuel(playerDice, dealerDice);
      const attachment = new AttachmentBuilder(image, { name: IMAGE_NAME });
      const embed = new EmbedBuilder()
        .setTitle("🎲 Dice Duel")
        .setDescription(statusText)
        .setImage(`attachment://${IMAGE_NAME}`)
        .setFooter({ text: `Bet: ${bet.toLocaleString()} coins  •  Current pot: ${pot.toLocaleString()} coins` });

      const components = showButtons ? [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("dd_double").setLabel("Double or Nothing").setEmoji("🎲").setStyle(ButtonStyle.Danger).setDisabled(disabled),
          new ButtonBuilder().setCustomId("dd_cashout").setLabel("Cash Out").setEmoji("💰").setStyle(ButtonStyle.Success).setDisabled(disabled)
        ),
      ] : [];

      return { embeds: [embed], files: [attachment], components };
    };

    const playRound = () => {
      round++;
      const playerDice = rollPair();
      const dealerDice = rollPair();
      const playerRoll = playerDice[0] + playerDice[1];
      const dealerRoll = dealerDice[0] + dealerDice[1];
      return { playerDice, dealerDice, playerRoll, dealerRoll };
    };

    const settle = (outcome, playerRoll, dealerRoll) => {
      if (outcome === "win") {
        pot *= 2;
        return { line: `**${playerRoll} beats ${dealerRoll} — you win!**`, done: false };
      }
      if (outcome === "tie") {
        return { line: `**Push — both rolled ${playerRoll}.** Roll again for the same pot.`, done: false, retry: true };
      }
      return { line: `**${dealerRoll} beats ${playerRoll} — dealer wins.** You lose the pot.`, done: true, lost: true };
    };

    const resolveOutcome = (playerRoll, dealerRoll) =>
      playerRoll > dealerRoll ? "win" : playerRoll < dealerRoll ? "lose" : "tie";

    // Initial roll
    let { playerDice, dealerDice, playerRoll, dealerRoll } = playRound();
    let outcome = resolveOutcome(playerRoll, dealerRoll);
    let result  = settle(outcome, playerRoll, dealerRoll);

    while (result.retry) {
      ({ playerDice, dealerDice, playerRoll, dealerRoll } = playRound());
      outcome = resolveOutcome(playerRoll, dealerRoll);
      result  = settle(outcome, playerRoll, dealerRoll);
    }

    if (result.lost) {
      const newBalance = getBalance(interaction.user.id);
      return interaction.reply(buildPayload(playerDice, dealerDice,
        `${result.line}\nYou lose your **${bet.toLocaleString()}** coin bet. Balance: **${newBalance.toLocaleString()}**.`,
        {}
      ));
    }

    const msg = await interaction.reply({
      ...buildPayload(playerDice, dealerDice, `${result.line}\nPush your luck for double or nothing, or cash out **${pot.toLocaleString()}** coins.`, { showButtons: true }),
      fetchReply: true,
    });

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 2 * 60 * 1000,
    });

    collector.on("collect", async btn => {
      if (btn.user.id !== interaction.user.id) {
        return btn.reply({ content: "This isn't your game.", ephemeral: true });
      }

      if (btn.customId === "dd_cashout") {
        collector.stop("done");
        addCoins(interaction.user.id, pot);
        const newBalance = getBalance(interaction.user.id);
        return btn.update(buildPayload(playerDice, dealerDice,
          `Cashed out! You win **${pot.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true }
        ));
      }

      // Double or nothing
      ({ playerDice, dealerDice, playerRoll, dealerRoll } = playRound());
      outcome = resolveOutcome(playerRoll, dealerRoll);
      result  = settle(outcome, playerRoll, dealerRoll);

      while (result.retry) {
        ({ playerDice, dealerDice, playerRoll, dealerRoll } = playRound());
        outcome = resolveOutcome(playerRoll, dealerRoll);
        result  = settle(outcome, playerRoll, dealerRoll);
      }

      if (result.lost) {
        collector.stop("done");
        const newBalance = getBalance(interaction.user.id);
        return btn.update(buildPayload(playerDice, dealerDice,
          `${result.line}\nYou lose the **${pot.toLocaleString()}** coin pot. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true }
        ));
      }

      await btn.update(buildPayload(playerDice, dealerDice,
        `${result.line}\nPush your luck for double or nothing, or cash out **${pot.toLocaleString()}** coins.`,
        { showButtons: true }
      ));
    });

    collector.on("end", (_collected, reason) => {
      if (reason === "done") return;
      addCoins(interaction.user.id, pot);
      const newBalance = getBalance(interaction.user.id);
      interaction.editReply(buildPayload(playerDice, dealerDice,
        `Timed out — auto cashed-out. You win **${pot.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`,
        { disabled: true }
      )).catch(() => {});
    });
  },
};
