"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { isOwner } = require("../utils/owners");
const { getInboxChannelId } = require("../utils/inboxStore");

/** Best-effort copy of an outgoing DM into the inbox channel, for a paper trail. Never throws. */
async function logToInbox(client, { sentBy, target, message }) {
  const channelId = getInboxChannelId();
  if (!channelId) return;
  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased?.()) return;

  const embed = new EmbedBuilder()
    .setAuthor({ name: `${target.tag} (${target.id})`, iconURL: target.displayAvatarURL() })
    .setDescription(message)
    .setFooter({ text: `Outgoing DM sent by ${sentBy.tag}` })
    .setTimestamp();

  await channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("dm")
    .setDescription("[Owner only] Send a DM to a user")
    .addUserOption(o =>
      o.setName("user")
        .setDescription("Who to DM")
        .setRequired(true)
    )
    .addStringOption(o =>
      o.setName("message")
        .setDescription("The message to send")
        .setRequired(true)
        .setMaxLength(2000)
    ),

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const target  = interaction.options.getUser("user", true);
    const message = interaction.options.getString("message", true);

    if (target.bot) {
      return interaction.reply({ content: "Can't DM another bot.", ephemeral: true });
    }

    try {
      await target.send({ content: message });
    } catch (err) {
      return interaction.reply({
        content: `❌ Couldn't DM ${target.tag} — they may have DMs closed, or blocked the bot. (${err.message})`,
        ephemeral: true,
      });
    }

    await logToInbox(client, { sentBy: interaction.user, target, message });

    await interaction.reply({ content: `✅ Sent your DM to **${target.tag}**.`, ephemeral: true });
  },
};
