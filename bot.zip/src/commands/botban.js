"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { isOwner } = require("../utils/owners");
const { blockUser, unblockUser, listBlocked } = require("../utils/blocklist");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("botban")
    .setDescription("[Owner only] Block/unblock a user from using this bot at all")
    .addSubcommand(sub =>
      sub.setName("add")
        .setDescription("Block a user from every bot interaction (commands, DMs, noname chat)")
        .addUserOption(o => o.setName("user").setDescription("Who to block").setRequired(true))
        .addStringOption(o => o.setName("reason").setDescription("Why (shown in /botban list)"))
    )
    .addSubcommand(sub =>
      sub.setName("remove")
        .setDescription("Unblock a user")
        .addUserOption(o => o.setName("user").setDescription("Who to unblock").setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName("list")
        .setDescription("Show everyone currently blocked")
    ),

  async execute(interaction) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === "add") {
      const target = interaction.options.getUser("user", true);
      const reason = interaction.options.getString("reason");

      if (isOwner(target.id)) {
        return interaction.reply({ content: "can't block another owner.", ephemeral: true });
      }
      if (target.id === interaction.client.user.id) {
        return interaction.reply({ content: "can't block the bot itself.", ephemeral: true });
      }

      blockUser(target.id, reason, interaction.user.id);
      return interaction.reply({
        content: `🚫 Blocked **${target.tag}** (\`${target.id}\`)${reason ? ` — ${reason}` : ""}. They'll get no response from any command, DM, or noname chat.`,
        ephemeral: true,
      });
    }

    if (sub === "remove") {
      const target = interaction.options.getUser("user", true);
      const entry = unblockUser(target.id);
      return interaction.reply({
        content: entry ? `✅ Unblocked **${target.tag}**.` : `**${target.tag}** wasn't blocked.`,
        ephemeral: true,
      });
    }

    // list
    const blocked = listBlocked();
    const ids = Object.keys(blocked);
    if (!ids.length) {
      return interaction.reply({ content: "Nobody's currently blocked.", ephemeral: true });
    }

    const lines = ids.map(id => {
      const e = blocked[id];
      const since = Math.floor(e.blockedAt / 1000);
      return `<@${id}> (\`${id}\`) — ${e.reason} — blocked <t:${since}:R> by <@${e.blockedBy}>`;
    });

    const embed = new EmbedBuilder()
      .setTitle("Blocked users")
      .setDescription(lines.join("\n").slice(0, 4000))
      .setFooter({ text: `${ids.length} blocked` });

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
