"use strict";

const { SlashCommandBuilder } = require("discord.js");
const { buildNowPlayingEmbed, buildControlRow } = require("../utils/musicPanel");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("nowplaying")
    .setDescription("Show details about the currently playing track"),

  async execute(interaction, client) {
    await interaction.deferReply();

    const player = client.lavalink.getPlayer(interaction.guildId);
    if (!player || !player.queue.current)
      return interaction.editReply("Nothing is currently playing.");

    await interaction.editReply({
      embeds:     [buildNowPlayingEmbed(player)],
      components: [buildControlRow(player)],
    });
  },
};
