"use strict";

const { SlashCommandBuilder, ChannelType } = require("discord.js");
const { isOwner } = require("../utils/owners");
const { getInboxChannelId, setInboxChannelId, clearInboxChannelId } = require("../utils/inboxStore");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("inboxset")
    .setDescription("[Owner only] Set which channel receives forwarded DMs")
    .addSubcommand(sub =>
      sub.setName("set")
        .setDescription("Set the inbox channel")
        .addChannelOption(o =>
          o.setName("channel")
            .setDescription("The channel DMs should be forwarded into")
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub.setName("view")
        .setDescription("Show the currently configured inbox channel")
    )
    .addSubcommand(sub =>
      sub.setName("clear")
        .setDescription("Stop forwarding DMs anywhere")
    ),

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === "set") {
      const channel = interaction.options.getChannel("channel", true);

      const me = channel.guild?.members?.me;
      const perms = me ? channel.permissionsFor(me) : null;
      if (!perms?.has("ViewChannel") || !perms?.has("SendMessages")) {
        return interaction.reply({
          content: `❌ I don't have permission to view/send in ${channel}. Give me View Channel + Send Messages there first.`,
          ephemeral: true,
        });
      }

      setInboxChannelId(channel.id);
      return interaction.reply({ content: `📥 DMs sent to the bot will now be forwarded to ${channel}.`, ephemeral: true });
    }

    if (sub === "clear") {
      clearInboxChannelId();
      return interaction.reply({ content: "📭 DM forwarding has been turned off.", ephemeral: true });
    }

    // view
    const channelId = getInboxChannelId();
    if (!channelId) {
      return interaction.reply({ content: "No inbox channel is set. Use `/inboxset set` to configure one.", ephemeral: true });
    }
    const channel = await client.channels.fetch(channelId).catch(() => null);
    return interaction.reply({
      content: channel
        ? `📥 DMs are currently forwarded to ${channel} (\`${channelId}\`).`
        : `⚠️ The configured inbox channel (\`${channelId}\`) no longer exists or isn't visible to me anymore.`,
      ephemeral: true,
    });
  },
};
