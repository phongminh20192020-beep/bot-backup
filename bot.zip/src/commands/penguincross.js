"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const { getBalance, addCoins, removeCoins } = require("../utils/economy");
const { renderPenguinTrack } = require("../utils/penguinCrossRender");

const IMAGE_NAME = "penguincross.png";
const MAX_HOPS = 15;

// Survival chance drops each hop (floored so it's never a sure loss), and
// the multiplier compounds each hop. Tuned so the peak expected value
// across every possible stopping point stays right at ~break-even (checked
// against a per-hop EV table before shipping these constants) -- pushing
// further past the first couple of hops is a genuinely bad bet, same as
// any real push-your-luck game.
const survivalChance = hop => Math.max(0.4, 0.90 - 0.035 * hop);
const MULT_PER_HOP = 1.11;

module.exports = {
  data: new SlashCommandBuilder()
    .setName("penguincross")
    .setDescription("Hop the penguin across the ice, cashing out before it slips, wagering coins")
    .addIntegerOption(o =>
      o.setName("bet")
        .setDescription("How many coins to wager")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1_000_000)
    ),

  async execute(interaction) {
    const bet     = interaction.options.getInteger("bet", true);
    const balance = getBalance(interaction.user.id);

    if (balance < bet) {
      return interaction.reply({
        content: `You don't have enough coins for that bet — your balance is **${balance.toLocaleString()}** coins.`,
        ephemeral: true,
      });
    }

    removeCoins(interaction.user.id, bet);

    let hopsDone   = 0;
    let multiplier = 1;

    const buildPayload = (statusText, { disabled = false, fellAt = null } = {}) => {
      const image = renderPenguinTrack(hopsDone, fellAt);
      const attachment = new AttachmentBuilder(image, { name: IMAGE_NAME });
      return {
        embeds: [
          new EmbedBuilder()
            .setTitle("🐧 Penguin Cross")
            .setDescription(`Hops: **${hopsDone}**  •  Multiplier: **${multiplier.toFixed(2)}x**\n\n${statusText}`)
            .setImage(`attachment://${IMAGE_NAME}`)
            .setFooter({ text: `Bet: ${bet.toLocaleString()} coins  •  Cash out value: ${Math.floor(bet * multiplier).toLocaleString()} coins` }),
        ],
        files: [attachment],
        components: [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("pc_hop").setLabel("Hop").setEmoji("🐧").setStyle(ButtonStyle.Primary).setDisabled(disabled || hopsDone >= MAX_HOPS),
            new ButtonBuilder().setCustomId("pc_cashout").setLabel("Cash Out").setEmoji("💰").setStyle(ButtonStyle.Success).setDisabled(disabled || hopsDone === 0)
          ),
        ],
      };
    };

    const msg = await interaction.reply({ ...buildPayload("Hop onto the ice to begin."), fetchReply: true });

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 3 * 60 * 1000,
    });

    collector.on("collect", async btn => {
      if (btn.user.id !== interaction.user.id) {
        return btn.reply({ content: "This isn't your game.", ephemeral: true });
      }

      if (btn.customId === "pc_cashout") {
        collector.stop("done");
        const winnings = Math.floor(bet * multiplier);
        addCoins(interaction.user.id, winnings);
        const newBalance = getBalance(interaction.user.id);
        return btn.update(buildPayload(
          `Cashed out after **${hopsDone}** hop${hopsDone === 1 ? "" : "s"}! You win **${winnings.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true }
        ));
      }

      const survived = Math.random() < survivalChance(hopsDone);

      if (!survived) {
        collector.stop("done");
        const fellAt = hopsDone;
        const newBalance = getBalance(interaction.user.id);
        return btn.update(buildPayload(
          `The ice cracks! You lose your **${bet.toLocaleString()}** coin bet. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true, fellAt }
        ));
      }

      hopsDone++;
      multiplier *= MULT_PER_HOP;

      if (hopsDone >= MAX_HOPS) {
        collector.stop("done");
        const winnings = Math.floor(bet * multiplier);
        addCoins(interaction.user.id, winnings);
        const newBalance = getBalance(interaction.user.id);
        return btn.update(buildPayload(
          `You made it all the way across! You win **${winnings.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true }
        ));
      }

      await btn.update(buildPayload("Solid ground. Hop again, or cash out."));
    });

    collector.on("end", (_collected, reason) => {
      if (reason === "done") return;
      const refund = hopsDone > 0 ? Math.floor(bet * multiplier) : bet;
      if (refund > 0) addCoins(interaction.user.id, refund);
      const newBalance = getBalance(interaction.user.id);
      interaction.editReply(buildPayload(
        `Timed out — auto cashed-out. You get **${refund.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`,
        { disabled: true }
      )).catch(() => {});
    });
  },
};
