"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const {
  startGame,
  playCard,
  drawOnTurn,
  advanceTurn,
  chooseBotMove,
  canPlay,
  canPlayWildFour,
  playableIndices,
  cardLabel,
} = require("../utils/unoEngine");
const { renderHandImage, renderTableImage } = require("../utils/unoRender");

const DEFAULT_WAIT_SEC = 20;
const TURN_TIMEOUT_MS  = 90_000;
const COLORS = ["red", "yellow", "green", "blue"];
const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = {
  data: new SlashCommandBuilder()
    .setName("uno")
    .setDescription("Start a game of UNO — 2 to 4 players, fills empty seats with bots")
    .addIntegerOption(o =>
      o.setName("size")
        .setDescription("Total number of seats at the table")
        .setRequired(true)
        .addChoices(
          { name: "2 players", value: 2 },
          { name: "3 players", value: 3 },
          { name: "4 players", value: 4 }
        )
    )
    .addIntegerOption(o =>
      o.setName("wait")
        .setDescription(`Seconds to wait for others to join (default ${DEFAULT_WAIT_SEC})`)
        .setMinValue(10)
        .setMaxValue(60)
    ),

  async execute(interaction) {
    const size    = interaction.options.getInteger("size", true);
    const waitSec = interaction.options.getInteger("wait") ?? DEFAULT_WAIT_SEC;

    const seats = [{ id: interaction.user.id, user: interaction.user, isBot: false }];
    let started = false;
    let state   = null;
    let gameCollector = null;

    // ─── Lobby rendering ────────────────────────────────────────────────
    const renderLobbyEmbed = () =>
      new EmbedBuilder()
        .setTitle("🎴 UNO Table — Open")
        .setDescription(
          `${seats.map(s => `• ${s.user.username}`).join("\n")}\n\n` +
          `Seats: **${seats.length}/${size}**\n` +
          `Starts in **${waitSec}s** (or when the host clicks Start Now). Empty seats fill with bots.`
        );

    const renderLobbyRow = () =>
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("uno_join").setLabel("Join").setStyle(ButtonStyle.Success).setDisabled(seats.length >= size),
        new ButtonBuilder().setCustomId("uno_start").setLabel("Start Now").setStyle(ButtonStyle.Primary)
      );

    const msg = await interaction.reply({ embeds: [renderLobbyEmbed()], components: [renderLobbyRow()], fetchReply: true });

    // ─── Shared table rendering ─────────────────────────────────────────
    const refreshPublicTable = async logLine => {
      const current = state.players[state.turnIndex];
      const unoFlag = current.hand.length === 1 ? `\n🔥 **${current.username} has UNO!**` : "";
      const embed = new EmbedBuilder()
        .setTitle("🎴 UNO Table")
        .setDescription(`${logLine ? logLine + "\n\n" : ""}It's **${current.username}**'s turn.${unoFlag}`)
        .setImage("attachment://table.png");
      const attachment = new AttachmentBuilder(renderTableImage(state), { name: "table.png" });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("uno_hand").setLabel("🖐️ My Hand").setStyle(ButtonStyle.Primary)
      );
      await msg.edit({ embeds: [embed], files: [attachment], components: [row] }).catch(() => {});
    };

    const announceWinner = async winner => {
      const attachment = new AttachmentBuilder(renderTableImage(state), { name: "table.png" });
      const embed = new EmbedBuilder()
        .setTitle("🎉 UNO — Game Over!")
        .setDescription(`**${winner.username}** wins the game!`)
        .setImage("attachment://table.png");
      await msg.edit({ embeds: [embed], files: [attachment], components: [] }).catch(() => {});
      gameCollector?.stop("finished");
    };

    // ─── Bot turn loop ──────────────────────────────────────────────────
    const runBotLoop = async () => {
      while (!state.winnerId && state.players[state.turnIndex].isBot) {
        await sleep(1200);
        const botIdx = state.turnIndex;
        const bot    = state.players[botIdx];
        const move   = chooseBotMove(state, botIdx);

        if (move.action === "draw") {
          const drawn = drawOnTurn(state, botIdx);
          if (drawn) {
            const topCard  = state.discard[state.discard.length - 1];
            const cardIdx  = bot.hand.length - 1;
            const playable = canPlay(drawn, state.currentColor, topCard) &&
              !(drawn.type === "wild4" && !canPlayWildFour(bot.hand, cardIdx, state.currentColor));
            if (playable) {
              let chosenColor;
              if (drawn.color === "wild") {
                const counts = { red: 0, yellow: 0, green: 0, blue: 0 };
                bot.hand.forEach((c, i) => { if (i !== cardIdx && c.color !== "wild") counts[c.color]++; });
                const best = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
                chosenColor = best[1] > 0 ? best[0] : COLORS[Math.floor(Math.random() * 4)];
              }
              const result = playCard(state, botIdx, cardIdx, chosenColor);
              await refreshPublicTable(`${bot.username} drew and played **${cardLabel(drawn)}**${chosenColor ? ` (chose ${chosenColor})` : ""}.`);
              if (result.effect === "win") return announceWinner(bot);
              continue;
            }
          }
          advanceTurn(state);
          await refreshPublicTable(`${bot.username} drew a card.`);
          continue;
        }

        const card   = bot.hand[move.cardIdx];
        const result = playCard(state, botIdx, move.cardIdx, move.chosenColor);
        await refreshPublicTable(`${bot.username} played **${cardLabel(card)}**${move.chosenColor ? ` (chose ${move.chosenColor})` : ""}.`);
        if (result.effect === "win") return announceWinner(bot);
      }
    };

    const afterHumanMove = async (player, result) => {
      if (result.effect === "win") return announceWinner(player);
      await refreshPublicTable(`${player.username} played a card.`);
      await runBotLoop();
    };

    // ─── "My Hand" -> per-player ephemeral turn UI ─────────────────────
    const handleHandButton = async btn => {
      const player = state.players.find(p => p.id === btn.user.id && !p.isBot);
      if (!player) return btn.reply({ content: "You're not seated at this table.", ephemeral: true });

      const idx = state.players.findIndex(p => p.id === player.id);
      const isMyTurn = state.turnIndex === idx;
      const handAttachment = () => new AttachmentBuilder(renderHandImage(player.hand), { name: "hand.png" });

      if (!isMyTurn) {
        return btn.reply({
          content: `Your hand — waiting for **${state.players[state.turnIndex].username}**'s turn.`,
          files: [handAttachment()],
          ephemeral: true,
        });
      }

      const buildTurnUI = () => {
        const topCard = state.discard[state.discard.length - 1];
        const legal   = playableIndices(player.hand, state.currentColor, topCard);
        const options = player.hand.slice(0, 24).map((c, i) => ({
          label: cardLabel(c).slice(0, 100),
          value: String(i),
          description: legal.includes(i) ? "Playable" : "Not playable right now",
        }));
        options.push({ label: "Draw a card", value: "draw", description: "Draw from the deck" });
        const menu = new StringSelectMenuBuilder()
          .setCustomId("uno_action")
          .setPlaceholder("Choose a card to play, or draw")
          .addOptions(options.slice(0, 25));
        return [new ActionRowBuilder().addComponents(menu)];
      };

      const colorRow = cardIdx =>
        new ActionRowBuilder().addComponents(
          COLORS.map(c =>
            new ButtonBuilder()
              .setCustomId(`uno_color_${c}_${cardIdx}`)
              .setLabel(c[0].toUpperCase() + c.slice(1))
              .setStyle(ButtonStyle.Secondary)
          )
        );

      const ephemeral = await btn.reply({
        content: "It's your turn! Pick a card to play, or draw.",
        files: [handAttachment()],
        components: buildTurnUI(),
        ephemeral: true,
        fetchReply: true,
      });

      let resolved = false;
      const turnCollector = ephemeral.createMessageComponentCollector({ time: TURN_TIMEOUT_MS });

      turnCollector.on("collect", async i => {
        if (i.user.id !== player.id) return i.reply({ content: "This isn't your turn.", ephemeral: true });

        // Select menu: play a card, or draw
        if (i.isStringSelectMenu() && i.customId === "uno_action") {
          const value = i.values[0];

          if (value === "draw") {
            const drawn = drawOnTurn(state, idx);
            if (!drawn) {
              resolved = true;
              turnCollector.stop("done");
              await i.update({ content: "The deck is empty — turn passed.", files: [], components: [] });
              advanceTurn(state);
              await refreshPublicTable(`${player.username} tried to draw, but the deck is empty.`);
              return runBotLoop();
            }

            const topCard  = state.discard[state.discard.length - 1];
            const drawnIdx = player.hand.length - 1;
            const playable = canPlay(drawn, state.currentColor, topCard) &&
              !(drawn.type === "wild4" && !canPlayWildFour(player.hand, drawnIdx, state.currentColor));

            if (!playable) {
              resolved = true;
              turnCollector.stop("done");
              await i.update({ content: `You drew **${cardLabel(drawn)}** — no valid play, turn passed.`, files: [], components: [] });
              advanceTurn(state);
              await refreshPublicTable(`${player.username} drew a card.`);
              return runBotLoop();
            }

            const yesNo = new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId("uno_playdrawn_yes").setLabel(`Play ${cardLabel(drawn)}`).setStyle(ButtonStyle.Success),
              new ButtonBuilder().setCustomId("uno_playdrawn_no").setLabel("Keep it, pass turn").setStyle(ButtonStyle.Secondary)
            );
            return i.update({ content: `You drew **${cardLabel(drawn)}** — play it now or keep it?`, files: [], components: [yesNo] });
          }

          // Playing a card already in hand
          const cardIdx = parseInt(value, 10);
          const card = player.hand[cardIdx];
          if (!card) return i.reply({ content: "That card isn't there anymore.", ephemeral: true });

          if (card.color === "wild") {
            return i.update({ content: `Playing **${cardLabel(card)}** — choose a color:`, files: [], components: [colorRow(cardIdx)] });
          }

          try {
            const result = playCard(state, idx, cardIdx);
            resolved = true;
            turnCollector.stop("done");
            await i.update({ content: `You played **${cardLabel(card)}**.`, files: [], components: [] });
            return afterHumanMove(player, result);
          } catch (err) {
            return i.reply({ content: err.message, ephemeral: true });
          }
        }

        // Follow-up: play the just-drawn card
        if (i.isButton() && i.customId === "uno_playdrawn_yes") {
          const drawnIdx  = player.hand.length - 1;
          const drawnCard = player.hand[drawnIdx];
          if (drawnCard.color === "wild") {
            return i.update({ content: `Playing **${cardLabel(drawnCard)}** — choose a color:`, components: [colorRow(drawnIdx)] });
          }
          const result = playCard(state, idx, drawnIdx);
          resolved = true;
          turnCollector.stop("done");
          await i.update({ content: `You played **${cardLabel(drawnCard)}**.`, components: [] });
          return afterHumanMove(player, result);
        }

        if (i.isButton() && i.customId === "uno_playdrawn_no") {
          resolved = true;
          turnCollector.stop("done");
          advanceTurn(state);
          await i.update({ content: "Kept the card — turn passed.", components: [] });
          await refreshPublicTable(`${player.username} drew and kept a card.`);
          return runBotLoop();
        }

        // Color choice for a wild card
        if (i.isButton() && i.customId.startsWith("uno_color_")) {
          const [, , color, idxStr] = i.customId.split("_");
          const cardIdx = parseInt(idxStr, 10);
          const card = player.hand[cardIdx];
          try {
            const result = playCard(state, idx, cardIdx, color);
            resolved = true;
            turnCollector.stop("done");
            await i.update({ content: `You played **${cardLabel(card)}** and chose ${color}.`, components: [] });
            return afterHumanMove(player, result);
          } catch (err) {
            return i.update({ content: err.message, components: [] });
          }
        }
      });

      turnCollector.on("end", async (_c, reason) => {
        if (resolved || reason !== "time") return;
        // Timed out without acting -- auto draw-and-pass so the game doesn't stall.
        const drawn = drawOnTurn(state, idx);
        advanceTurn(state);
        await ephemeral.edit({
          content: drawn
            ? `⌛ Timed out — drew **${cardLabel(drawn)}** and passed your turn.`
            : "⌛ Timed out — turn passed.",
          files: [], components: [],
        }).catch(() => {});
        await refreshPublicTable(`${player.username} took too long and their turn was passed.`);
        await runBotLoop();
      });
    };

    // ─── Lobby -> game transition ───────────────────────────────────────
    const beginGame = async () => {
      if (started) return;
      started = true;
      lobbyCollector.stop("start");

      let botCount = 0;
      while (seats.length < size) {
        botCount++;
        seats.push({ id: `bot_${botCount}`, user: null, isBot: true, username: `Bot ${botCount}` });
      }

      const playerInfos = seats.map(s => ({
        id: s.id, isBot: s.isBot, username: s.isBot ? s.username : s.user.username,
      }));
      state = startGame(playerInfos);

      for (const s of seats) {
        if (s.isBot) continue;
        const hand = state.players.find(p => p.id === s.id).hand;
        const attachment = new AttachmentBuilder(renderHandImage(hand), { name: "hand.png" });
        try {
          await s.user.send({
            content: `🎴 Your UNO hand for the game in **${interaction.guild?.name ?? "this server"}**! Use the table message's "My Hand" button any time for an updated view and to take your turn.`,
            files: [attachment],
          });
        } catch {
          await msg.channel.send({
            content: `${s.user} — I couldn't DM you your hand (check that DMs from server members are allowed). You can still play using the "🖐️ My Hand" button on the table below.`,
          }).catch(() => {});
        }
      }

      await refreshPublicTable("Game started! Cards have been dealt.");

      gameCollector = msg.createMessageComponentCollector({
        componentType: ComponentType.Button,
        filter: i => i.customId === "uno_hand",
      });
      gameCollector.on("collect", handleHandButton);

      await runBotLoop();
    };

    // ─── Lobby collector ────────────────────────────────────────────────
    const lobbyCollector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      filter: i => i.customId === "uno_join" || i.customId === "uno_start",
    });

    lobbyCollector.on("collect", async btn => {
      if (started) return;

      if (btn.customId === "uno_start") {
        if (btn.user.id !== interaction.user.id) {
          return btn.reply({ content: "Only the host can start early.", ephemeral: true });
        }
        await btn.deferUpdate();
        return beginGame();
      }

      // uno_join
      if (btn.user.bot) return btn.reply({ content: "Bots fill empty seats automatically — no need to add one.", ephemeral: true });
      if (seats.find(s => s.id === btn.user.id)) return btn.reply({ content: "You're already seated.", ephemeral: true });
      if (seats.length >= size) return btn.reply({ content: "This table is full.", ephemeral: true });

      seats.push({ id: btn.user.id, user: btn.user, isBot: false });
      await btn.update({ embeds: [renderLobbyEmbed()], components: [renderLobbyRow()] });
      if (seats.length === size) await beginGame();
    });

    setTimeout(() => { if (!started) beginGame(); }, waitSec * 1000);
  },
};
