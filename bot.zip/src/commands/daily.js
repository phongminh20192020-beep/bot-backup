"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { claimDaily, DAILY_AMOUNT } = require("../utils/economy");

function formatRemaining(ms) {
  const totalSeconds = Math.ceil(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;

  const parts = [];
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  if (!h) parts.push(`${s}s`); // skip seconds once we're into hours, keeps it readable
  return parts.join(" ");
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("daily")
    .setDescription(`Claim your daily ${DAILY_AMOUNT.toLocaleString()} coins`),

  async execute(interaction) {
    const result = claimDaily(interaction.user.id);

    if (!result.success) {
      const embed = new EmbedBuilder()
        .setTitle("⏳ Already claimed")
        .setDescription(`You've already grabbed today's coins. Come back in **${formatRemaining(result.remainingMs)}**.`);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setTitle("💰 Daily reward claimed!")
      .setDescription(
        `You received **${result.amount.toLocaleString()}** coins.\n` +
        `New balance: **${result.balance.toLocaleString()}** coins.`
      );

    await interaction.reply({ embeds: [embed] });
  },
};
