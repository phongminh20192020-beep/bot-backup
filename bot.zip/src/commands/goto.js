"use strict";

const { SlashCommandBuilder } = require("discord.js");
const { formatDuration } = require("../utils/helpers");

// Accepts "90" (seconds), "1:30" (m:ss), or "1:05:00" (h:mm:ss)
function parseTimestamp(input) {
  const trimmed = input.trim();

  if (/^\d+$/.test(trimmed)) return parseInt(trimmed, 10) * 1000;

  const parts = trimmed.split(":").map(p => p.trim());
  if (!parts.every(p => /^\d+$/.test(p))) return null;

  const nums = parts.map(Number);
  if (nums.length === 2) return (nums[0] * 60 + nums[1]) * 1000;
  if (nums.length === 3) return (nums[0] * 3600 + nums[1] * 60 + nums[2]) * 1000;
  return null;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("goto")
    .setDescription("Seek to a specific point in the current track")
    .addStringOption(o =>
      o.setName("timestamp")
        .setDescription("Where to jump to — e.g. 90, 1:30, or 1:05:00")
        .setRequired(true)
    ),

  async execute(interaction, client) {
    await interaction.deferReply();

    const player = client.lavalink.getPlayer(interaction.guildId);
    if (!player?.queue.current)
      return interaction.editReply("Nothing is playing right now.");

    const track = player.queue.current;
    if (track.info.isStream)
      return interaction.editReply("Can't seek in a live stream.");
    if (!track.info.isSeekable)
      return interaction.editReply("This track doesn't support seeking.");

    const raw = interaction.options.getString("timestamp", true);
    const targetMs = parseTimestamp(raw);
    if (targetMs === null)
      return interaction.editReply("Couldn't parse that timestamp — try something like `90`, `1:30`, or `1:05:00`.");

    if (targetMs > track.info.duration) {
      return interaction.editReply(
        `That's past the end of the track (**${formatDuration(track.info.duration)}** total).`
      );
    }

    await player.seek(targetMs);

    await interaction.editReply(
      `<:Success:1537804182206160936> Jumped to **${formatDuration(targetMs)}** / ${formatDuration(track.info.duration)}.`
    );
  },
};
