"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const { getBalance, addCoins, removeCoins } = require("../utils/economy");
const { renderCrashChart } = require("../utils/crashRender");

const IMAGE_NAME = "crash.png";

// House edge factor -- validated by simulation: whatever fixed cash-out
// target a player commits to, EV converges to ~E regardless of the target,
// which is the property this formula needs (checked via a 200k-trial sim
// across several fixed cash-out targets before shipping this constant).
const E = 0.97;
const TICK_MS = 900;
const STEP    = 0.06;

function rollCrashPoint() {
  const r = Math.random();
  const val = (100 * E) / (100 * (1 - r));
  return Math.max(1.00, Math.round(val * 100) / 100);
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = {
  data: new SlashCommandBuilder()
    .setName("crash")
    .setDescription("Watch the multiplier climb and cash out before it crashes, wagering coins")
    .addIntegerOption(o =>
      o.setName("bet")
        .setDescription("How many coins to wager")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1_000_000)
    ),

  async execute(interaction) {
    const bet     = interaction.options.getInteger("bet", true);
    const balance = getBalance(interaction.user.id);

    if (balance < bet) {
      return interaction.reply({
        content: `You don't have enough coins for that bet — your balance is **${balance.toLocaleString()}** coins.`,
        ephemeral: true,
      });
    }

    removeCoins(interaction.user.id, bet);

    const crashPoint = rollCrashPoint();
    let current  = 1.00;
    let resolved = false;
    const history = [1.00];

    const buildPayload = (statusText, { disabled = false, crashed = false } = {}) => {
      const image = renderCrashChart(history, crashed);
      const attachment = new AttachmentBuilder(image, { name: IMAGE_NAME });
      return {
        embeds: [
          new EmbedBuilder()
            .setTitle("📈 Crash")
            .setDescription(statusText)
            .setImage(`attachment://${IMAGE_NAME}`)
            .setFooter({ text: `Bet: ${bet.toLocaleString()} coins` }),
        ],
        files: [attachment],
        components: [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("crash_cashout")
              .setLabel(`Cash Out (${Math.floor(bet * current).toLocaleString()})`)
              .setEmoji("💰")
              .setStyle(ButtonStyle.Success)
              .setDisabled(disabled)
          ),
        ],
      };
    };

    const msg = await interaction.reply({ ...buildPayload("Climbing..."), fetchReply: true });

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 60 * 1000,
    });

    const cashOut = async btn => {
      if (resolved) return;
      resolved = true;
      collector.stop("done");
      const winnings = Math.floor(bet * current);
      addCoins(interaction.user.id, winnings);
      const newBalance = getBalance(interaction.user.id);
      await btn.update(buildPayload(
        `Cashed out at **${current.toFixed(2)}x**! You win **${winnings.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`,
        { disabled: true }
      ));
    };

    collector.on("collect", async btn => {
      if (btn.user.id !== interaction.user.id) {
        return btn.reply({ content: "This isn't your game.", ephemeral: true });
      }
      if (btn.customId === "crash_cashout") await cashOut(btn);
    });

    collector.on("end", (_collected, reason) => {
      if (reason === "done") return;
      if (!resolved) {
        resolved = true;
        const newBalance = getBalance(interaction.user.id);
        interaction.editReply(buildPayload(
          `Timed out while climbing — treated as a crash. You lose your **${bet.toLocaleString()}** coin bet. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true }
        )).catch(() => {});
      }
    });

    // Tick loop: climbs the multiplier and edits the message each tick,
    // independently of the collector. Both sides check `resolved` before
    // acting, so whichever happens first -- a crash or a cash-out -- wins.
    while (!resolved) {
      await sleep(TICK_MS);
      if (resolved) break;

      current = Math.round((current + STEP * current) * 100) / 100;

      if (current >= crashPoint) {
        resolved = true;
        collector.stop("done");
        current = crashPoint;
        history.push(current);
        const newBalance = getBalance(interaction.user.id);
        await interaction.editReply(buildPayload(
          `💥 **Crashed at ${crashPoint.toFixed(2)}x!** You lose your **${bet.toLocaleString()}** coin bet. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true, crashed: true }
        )).catch(() => {});
        break;
      }

      history.push(current);
      await interaction.editReply(buildPayload("Climbing...")).catch(() => {});
    }
  },
};
