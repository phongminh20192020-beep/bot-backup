"use strict";

const { SlashCommandBuilder, EmbedBuilder, ActivityType } = require("discord.js");
const { isOwner } = require("../utils/owners");

const TYPE_CHOICES = [
  { name: "Playing",   value: "playing" },
  { name: "Listening", value: "listening" },
  { name: "Watching",  value: "watching" },
  { name: "Competing", value: "competing" },
  { name: "Streaming", value: "streaming" },
  { name: "Custom",    value: "custom" },
];

const TYPE_MAP = {
  playing:   ActivityType.Playing,
  listening: ActivityType.Listening,
  watching:  ActivityType.Watching,
  competing: ActivityType.Competing,
  streaming: ActivityType.Streaming,
  custom:    ActivityType.Custom,
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName("setstatus")
    .setDescription("[Owner only] Set the bot's activity status")
    .addStringOption(o =>
      o.setName("type")
        .setDescription("Activity type")
        .setRequired(true)
        .addChoices(...TYPE_CHOICES)
    )
    .addStringOption(o =>
      o.setName("text")
        .setDescription("The status text")
        .setRequired(true)
        .setMaxLength(128)
    )
    .addStringOption(o =>
      o.setName("url")
        .setDescription("Twitch/YouTube URL — required only when type is Streaming")
    ),

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const type = interaction.options.getString("type", true);
    const text = interaction.options.getString("text", true);
    const url  = interaction.options.getString("url");

    if (type === "streaming") {
      const validStream = url && /^(https?:\/\/)?(www\.)?(twitch\.tv|youtube\.com)\//i.test(url);
      if (!validStream) {
        return interaction.reply({
          content: "Streaming status needs a valid `url` option pointing to a twitch.tv or youtube.com link.",
          ephemeral: true,
        });
      }
    }

    const activity = { name: text, type: TYPE_MAP[type] };
    if (type === "streaming") activity.url = url;

    client.user.setPresence({ activities: [activity], status: "online" });

    const label = TYPE_CHOICES.find(c => c.value === type).name;
    const embed = new EmbedBuilder()
      .setTitle("✅ Status updated")
      .setDescription(`Set activity to **${label}** — "${text}"`);

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
