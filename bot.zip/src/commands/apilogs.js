"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { isOwner } = require("../utils/owners");
const { getRecentLogs, getApiStats, clearLogs } = require("../utils/apiLogger");
const { listModels } = require("../utils/groq");

function timeAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function buildOverviewEmbed() {
  const stats = getApiStats();

  if (!stats.length) {
    return new EmbedBuilder()
      .setTitle("API Logs")
      .setDescription("No API calls have been logged since the bot last restarted.");
  }

  const lines = stats.map(s => {
    const icon = s.lastOk ? "🟢" : "🔴";
    const rate = ((s.ok / s.calls) * 100).toFixed(0);
    let line = `${icon} **${s.api}** — ${s.calls} call${s.calls === 1 ? "" : "s"}, ${rate}% ok, avg **${s.avgMs}ms**, last ${timeAgo(s.lastAt)}`;
    if (!s.lastOk && s.lastError) line += `\n\u2003↳ last error: \`${s.lastError.slice(0, 100)}\``;
    return line;
  });

  return new EmbedBuilder()
    .setTitle("API Logs — Overview")
    .setDescription(lines.join("\n"))
    .setFooter({ text: "In-memory since last restart · use /apilogs recent for individual calls" });
}

function buildRecentEmbed(filterApi, limit) {
  const entries = getRecentLogs(200).filter(e => !filterApi || e.api.toLowerCase() === filterApi.toLowerCase());
  const shown = entries.slice(0, limit);

  if (!shown.length) {
    return new EmbedBuilder()
      .setTitle("API Logs — Recent Calls")
      .setDescription(filterApi ? `No logged calls for **${filterApi}** yet.` : "No API calls have been logged since the bot last restarted.");
  }

  const lines = shown.map(e => {
    const icon = e.ok ? "🟢" : "🔴";
    let line = `${icon} \`${timeAgo(e.at)}\` **${e.api}** — ${e.action}${e.detail ? ` (${e.detail})` : ""} — **${e.ms}ms**`;
    if (!e.ok && e.error) line += `\n\u2003↳ \`${e.error.slice(0, 100)}\``;
    return line;
  });

  return new EmbedBuilder()
    .setTitle(`API Logs — Recent Calls${filterApi ? ` (${filterApi})` : ""}`)
    .setDescription(lines.join("\n").slice(0, 4000))
    .setFooter({ text: `Showing ${shown.length} of ${entries.length} logged call(s) · in-memory since last restart` });
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("apilogs")
    .setDescription("[Owner only] View recent third-party API call activity")
    .addSubcommand(sub =>
      sub.setName("overview")
        .setDescription("Per-API summary: call counts, success rate, latency")
    )
    .addSubcommand(sub =>
      sub.setName("recent")
        .setDescription("Individual recent API calls, newest first")
        .addStringOption(o =>
          o.setName("api")
            .setDescription("Filter to one API (e.g. Groq, NaraRouter, Wordnik)")
        )
        .addIntegerOption(o =>
          o.setName("limit")
            .setDescription("How many entries to show (default 15, max 30)")
            .setMinValue(1)
            .setMaxValue(30)
        )
    )
    .addSubcommand(sub =>
      sub.setName("clear")
        .setDescription("Clear the in-memory log")
    )
    .addSubcommand(sub =>
      sub.setName("ping")
        .setDescription("Live-check the Groq API right now (GET /v1/models)")
    ),

  async execute(interaction) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === "clear") {
      clearLogs();
      return interaction.reply({ content: "🧹 API log cleared.", ephemeral: true });
    }

    if (sub === "ping") {
      await interaction.deferReply();
      const start = Date.now();
      try {
        const models = await listModels();
        const ms = Date.now() - start;
        const names = models.slice(0, 10).map(m => `\`${m.id}\``).join(", ");
        const embed = new EmbedBuilder()
          .setTitle("🟢 Groq API — live check")
          .setDescription(
            `GET \`/v1/models\` responded in **${ms}ms**.\n` +
            `**${models.length}** model(s) available${models.length ? `:\n${names}${models.length > 10 ? `, +${models.length - 10} more` : ""}` : "."}`
          );
        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        const embed = new EmbedBuilder()
          .setTitle("🔴 Groq API — live check failed")
          .setDescription(`\`${err.message.slice(0, 300)}\``);
        return interaction.editReply({ embeds: [embed] });
      }
    }

    if (sub === "recent") {
      const filterApi = interaction.options.getString("api");
      const limit = interaction.options.getInteger("limit") ?? 15;
      return interaction.reply({ embeds: [buildRecentEmbed(filterApi, limit)] });
    }

    // Default: overview
    return interaction.reply({ embeds: [buildOverviewEmbed()] });
  },
};