"use strict";

const { SlashCommandBuilder, PermissionsBitField } = require("discord.js");
const { isOwner } = require("../utils/owners");

function botCanSend(channel, guild) {
  if (!channel?.isTextBased?.() || channel.isThread?.()) return false;
  const me = guild.members.me;
  if (!me) return false;
  const perms = channel.permissionsFor(me);
  return !!perms?.has(PermissionsBitField.Flags.SendMessages) && !!perms.has(PermissionsBitField.Flags.ViewChannel);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("msgto")
    .setDescription("[Owner only] Send a message to a channel in any server the bot is in")
    .addStringOption(o =>
      o.setName("guild")
        .setDescription("Which server to message")
        .setRequired(true)
        .setAutocomplete(true)
    )
    .addStringOption(o =>
      o.setName("message")
        .setDescription("The message to send")
        .setRequired(true)
        .setMaxLength(2000)
    )
    .addStringOption(o =>
      o.setName("channel")
        .setDescription("Which channel (defaults to the system channel, or the first one I can post in)")
        .setAutocomplete(true)
    ),

  async autocomplete(interaction, client) {
    const focused = interaction.options.getFocused(true);

    if (focused.name === "guild") {
      const query = focused.value.toLowerCase();
      const matches = [...client.guilds.cache.values()]
        .filter(g => g.name.toLowerCase().includes(query) || g.id.includes(query))
        .slice(0, 25)
        .map(g => ({ name: `${g.name} (${g.id})`.slice(0, 100), value: g.id }));
      return interaction.respond(matches);
    }

    if (focused.name === "channel") {
      const guildId = interaction.options.getString("guild");
      const guild = guildId ? client.guilds.cache.get(guildId) : null;
      if (!guild) return interaction.respond([]);

      const query = focused.value.toLowerCase();
      const matches = [...guild.channels.cache.values()]
        .filter(c => botCanSend(c, guild))
        .filter(c => c.name.toLowerCase().includes(query))
        .slice(0, 25)
        .map(c => ({ name: `#${c.name}`.slice(0, 100), value: c.id }));
      return interaction.respond(matches);
    }
  },

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const guildId    = interaction.options.getString("guild", true);
    const message    = interaction.options.getString("message", true);
    const channelId  = interaction.options.getString("channel");

    const guild = client.guilds.cache.get(guildId);
    if (!guild) {
      return interaction.reply({ content: "I'm not in a server with that ID (anymore).", ephemeral: true });
    }

    let channel;
    if (channelId) {
      channel = guild.channels.cache.get(channelId);
      if (!channel || !botCanSend(channel, guild)) {
        return interaction.reply({ content: "That channel wasn't found, or I don't have permission to post there.", ephemeral: true });
      }
    } else {
      channel = (guild.systemChannel && botCanSend(guild.systemChannel, guild))
        ? guild.systemChannel
        : [...guild.channels.cache.values()].find(c => botCanSend(c, guild));
    }

    if (!channel) {
      return interaction.reply({ content: `I don't have permission to send messages in any channel on **${guild.name}**.`, ephemeral: true });
    }

    try {
      await channel.send({ content: message });
    } catch (err) {
      return interaction.reply({ content: `Failed to send: ${err.message}`, ephemeral: true });
    }

    await interaction.reply({
      content: `✅ Sent your message to **${guild.name}** in #${channel.name}.`,
      ephemeral: true,
    });
  },
};
