"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { getBalance } = require("../utils/economy");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Check your (or someone else's) coin balance")
    .addUserOption(o =>
      o.setName("user")
        .setDescription("Whose balance to check (defaults to you)")
    ),

  async execute(interaction) {
    const target  = interaction.options.getUser("user") ?? interaction.user;
    const balance = getBalance(target.id);
    const isSelf  = target.id === interaction.user.id;

    const embed = new EmbedBuilder()
      .setTitle(`${isSelf ? "Your" : `${target.username}'s`} balance`)
      .setDescription(`💰 **${balance.toLocaleString()}** coins`);

    await interaction.reply({ embeds: [embed] });
  },
};
