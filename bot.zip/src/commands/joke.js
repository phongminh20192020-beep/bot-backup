"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

const API_URL = "https://icanhazdadjoke.com/";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("joke")
    .setDescription("Get a random dad joke"),

  async execute(interaction) {
    await interaction.deferReply();

    let joke;
    try {
      const res = await fetch(API_URL, {
        headers: {
          Accept: "application/json",
          "User-Agent": "Discord Bot (https://icanhazdadjoke.com/api)",
        },
      });
      if (!res.ok) throw new Error(`API returned ${res.status}`);
      const data = await res.json();
      joke = data.joke;
    } catch (err) {
      console.error("[Joke] Failed to fetch from icanhazdadjoke:", err.message);
      return interaction.editReply("Couldn't fetch a joke right now — try again in a bit.");
    }

    // No .setColor() call -- leaves the embed on Discord's default
    // (no colored side bar) instead of forcing a custom accent color.
    const embed = new EmbedBuilder()
      .setTitle("Random Dad Joke")
      .setDescription(joke)
      .setFooter({ text: "icanhazdadjoke.com" });

    await interaction.editReply({ embeds: [embed] });
  },
};
