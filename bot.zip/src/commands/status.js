"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { isInAfkVoice } = require("../utils/afkVoice");

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const parts = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  parts.push(`${m}m`);
  return parts.join(" ");
}

function mb(bytes) {
  return (bytes / 1024 / 1024).toFixed(1) + " MB";
}

function shardStatusLabel(status) {
  // discord.js Shard status enum: 0=Ready, 1=Connecting, 2=Reconnecting,
  // 3=Idle, 4=Nearly, 5=Disconnected, 6=WaitingForGuilds, 7=Identifying, 8=Resuming
  const labels = {
    0: "<:Success:1537804182206160936> Ready",
    5: "<:Fail:1537804179777650778> Disconnected",
  };
  return labels[status] || "<:Sandclock:1537804160211361874> Connecting";
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("status")
    .setDescription("Show the bot's performance and connection status"),

  async execute(interaction, client) {
    await interaction.deferReply();

    const players = [...client.lavalink.players.values()];
    const node = client.lavalink.nodeManager.nodes.get("main");
    const mem = process.memoryUsage();

    const shards = [...client.ws.shards.values()];
    const shardLines = shards
      .map(s => `\`#${s.id}\` ${shardStatusLabel(s.status)} — **${Number.isFinite(s.ping) ? Math.round(s.ping) : "?"}ms**`)
      .join("\n") || "No shard info available.";

    // Which shard/node actually handled THIS command -- a guild is always
    // pinned to one specific shard (guild.shardId), and to whichever node
    // its player is currently attached to (falls back to "main" if there's
    // no active player for this guild yet).
    const replyShardId = interaction.guild?.shardId ?? 0;
    const replyShard    = client.ws.shards.get(replyShardId);
    const replyNode      = client.lavalink.getPlayer(interaction.guildId)?.node ?? node;

    const apiLatencyMs = Date.now() - interaction.createdTimestamp; // full round trip: user -> Discord -> this bot

    const lavalinkPlayer   = client.lavalink.getPlayer(interaction.guildId);
    const lavalinkIsActive = !!lavalinkPlayer?.connected;
    const afkVoiceIsActive = isInAfkVoice(interaction.guildId);

    const gatewayInUse = lavalinkIsActive
      ? "Lavalink"
      : afkVoiceIsActive
        ? "DSCJSVoice"
        : "Not connected";

    const embed = new EmbedBuilder()
      .setTitle("Bot Status")
      .addFields(
        {
          name: "Bot",
          value: [
            `Ping: **${Number.isFinite(client.ws?.ping) ? Math.round(client.ws.ping) : "?"}ms**`,
            `Uptime: **${formatUptime(client.uptime || 0)}**`,
            `Servers: **${client.guilds.cache.size}**`,
            `Players: **${players.filter(p => p.playing).length}** active / **${players.length}** total`,
          ].join("\n"),
          inline: true,
        },
        {
          name: `Shards (${shards.length})`,
          value: shardLines,
          inline: true,
        },
        {
          name: "This Reply",
          value: [
            `Gateway: **${gatewayInUse}**`,
            `Shard: **#${replyShardId}**`,
            `Node: **${replyNode?.id ?? "?"}**`,
            `Latency: **${apiLatencyMs}ms**`,
            `Websocket ping: **${Number.isFinite(replyShard?.ping) ? Math.round(replyShard.ping) : "?"}ms**`,
            `Lavalink ping: **${Number.isFinite(replyNode?.heartBeatPing) ? Math.round(replyNode.heartBeatPing) : "?"}ms**`,
          ].join("\n"),
          inline: true,
        },
        {
          name: "Process",
          value: [
            `Memory (RSS): **${mb(mem.rss)}**`,
            `Heap: **${mb(mem.heapUsed)}** / ${mb(mem.heapTotal)}`,
            `Node.js: **${process.version}**`,
          ].join("\n"),
          inline: true,
        },
        {
          name: "\u200b",
          value: "\u200b",
          inline: false,
        },
        {
          name: "Lavalink Node",
          value: node?.connected
            ? [
                `Status: <:Success:1537804182206160936> **Connected**`,
                `Node uptime: **${node.stats ? formatUptime(node.stats.uptime) : "?"}**`,
                `Node players: **${node.stats?.playingPlayers ?? "?"}** playing / ${node.stats?.players ?? "?"} total`,
              ].join("\n")
            : `Status: <:Fail:1537804179777650778> **Disconnected**\nPlayback and search may fail until it reconnects.`,
          inline: true,
        },
        node?.connected && node.stats
          ? {
              name: "Node Load",
              value: [
                `CPU (system): **${(node.stats.cpu.systemLoad * 100).toFixed(1)}%**`,
                `CPU (Lavalink): **${(node.stats.cpu.lavalinkLoad * 100).toFixed(1)}%**`,
                `Memory: **${mb(node.stats.memory.used)}** / ${mb(node.stats.memory.allocated)}`,
              ].join("\n"),
              inline: true,
            }
          : { name: "\u200b", value: "\u200b", inline: true }
      )
      .setFooter({ text: node?.connected ? "All systems normal" : "Audio node unreachable — see /status above" })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};