"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  AttachmentBuilder,
} = require("discord.js");
const { createGame, reveal, toggleFlag } = require("../utils/minesweeperEngine");
const { renderMinesweeperImage } = require("../utils/minesweeperRender");

const SIZE  = 8;
const MINES = 10;
const IMAGE_NAME = "minesweeper.png";
const COLS = ["A", "B", "C", "D", "E", "F", "G", "H"]; // size-8 column labels

/** Splits an 8-item button row into two ActionRows (5 + 3) -- Discord caps each row at 5 buttons. */
function chunkIntoRows(buttons) {
  return [
    new ActionRowBuilder().addComponents(buttons.slice(0, 5)),
    new ActionRowBuilder().addComponents(buttons.slice(5)),
  ];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("minesweeper")
    .setDescription("Play a classic 8x8 minesweeper"),

  async execute(interaction) {
    let game = createGame(SIZE, MINES);

    const statusText = () => {
      if (game.state === "won")  return "🎉 **You win!** All safe cells cleared.";
      if (game.state === "lost") return "💥 **Boom.** Hit a mine — game over.";
      return "Press **Flag** or **Shovel** to pick a cell (only you can see the picker).";
    };

    const buildPayload = () => {
      const embed = new EmbedBuilder()
        .setTitle("Minesweeper")
        .setDescription(statusText())
        .setImage(`attachment://${IMAGE_NAME}`);
      const attachment = new AttachmentBuilder(renderMinesweeperImage(game), { name: IMAGE_NAME });
      return { embeds: [embed], files: [attachment] };
    };

    const buildMainRow = () => {
      const over = game.state !== "playing";
      return [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("ms_flag").setLabel("🚩 Flag").setStyle(ButtonStyle.Secondary).setDisabled(over),
        new ButtonBuilder().setCustomId("ms_dig").setLabel("⛏️ Shovel").setStyle(ButtonStyle.Secondary).setDisabled(over),
        new ButtonBuilder().setCustomId("ms_new").setLabel("🔄 New Game").setStyle(ButtonStyle.Secondary),
      )];
    };

    const msg = await interaction.reply({
      ...buildPayload(),
      components: buildMainRow(),
      fetchReply: true,
    });

    /** Builds the private column/row button-grid picker for a given mode + partial pick state. */
    function buildPickerRows(mode, pickedCol) {
      const colButtons = COLS.map((label, i) =>
        new ButtonBuilder()
          .setCustomId(`ms_pick_col_${i}`)
          .setLabel(label)
          .setStyle(pickedCol === i ? ButtonStyle.Primary : ButtonStyle.Secondary)
      );
      const rowButtons = Array.from({ length: SIZE }, (_, i) =>
        new ButtonBuilder()
          .setCustomId(`ms_pick_row_${i}`)
          .setLabel(String(i + 1))
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(pickedCol === null) // pick a column first, then a row
      );
      return [...chunkIntoRows(colButtons), ...chunkIntoRows(rowButtons)];
    }

    const mainCollector = msg.createMessageComponentCollector({ time: 10 * 60 * 1000 });

    mainCollector.on("collect", async int => {
      if (int.user.id !== interaction.user.id) {
        return int.reply({ content: "This isn't your game.", ephemeral: true });
      }

      if (int.customId === "ms_new") {
        game = createGame(SIZE, MINES);
        return int.update({ ...buildPayload(), components: buildMainRow() });
      }

      const mode = int.customId === "ms_flag" ? "flag" : "dig";
      let pickedCol = null;

      // Private cell picker -- column buttons first, row buttons unlock once
      // a column's picked. Whichever row gets pressed completes the cell
      // and applies the action immediately.
      const picker = await int.reply({
        content: `**${mode === "flag" ? "🚩 Flag" : "⛏️ Shovel"}** mode — pick a column, then a row.`,
        components: buildPickerRows(mode, pickedCol),
        ephemeral: true,
        fetchReply: true,
      });

      const pickerCollector = picker.createMessageComponentCollector({ time: 2 * 60 * 1000 });

      pickerCollector.on("collect", async pickInt => {
        if (pickInt.customId.startsWith("ms_pick_col_")) {
          pickedCol = Number(pickInt.customId.split("_").pop());
          return pickInt.update({
            content: `**${mode === "flag" ? "🚩 Flag" : "⛏️ Shovel"}** mode — column **${COLS[pickedCol]}** picked, now pick a row.`,
            components: buildPickerRows(mode, pickedCol),
          });
        }

        if (pickInt.customId.startsWith("ms_pick_row_") && pickedCol !== null) {
          const row = Number(pickInt.customId.split("_").pop());
          const index = row * SIZE + pickedCol;

          if (mode === "flag") toggleFlag(game, index);
          else reveal(game, index);

          pickerCollector.stop("picked");

          await pickInt.update({
            content: `✅ ${mode === "flag" ? "Flagged" : "Dug"} **${COLS[pickedCol]}${row + 1}**.`,
            components: [],
          });

          // Push the result to the actual board message everyone sees.
          await msg.edit({ ...buildPayload(), components: buildMainRow() }).catch(() => {});
        }
      });

      pickerCollector.on("end", (_collected, reason) => {
        if (reason === "picked") return;
        int.editReply({ content: "Picker timed out — press Flag/Shovel again to retry.", components: [] }).catch(() => {});
      });
    });

    mainCollector.on("end", () => {
      msg.edit({ ...buildPayload(), components: buildMainRow().map(r => {
        r.components.forEach(c => c.setDisabled(true));
        return r;
      }) }).catch(() => {});
    });
  },
};