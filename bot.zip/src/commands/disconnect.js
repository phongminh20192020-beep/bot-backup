"use strict";

const { SlashCommandBuilder } = require("discord.js");
const { clearVoiceStatus, resetPresence } = require("../utils/helpers");
const { saveQueue }           = require("../utils/queueStore");
const { leaveAfkChannel, isInAfkVoice } = require("../utils/afkVoice");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("disconnect")
    .setDescription("Save the queue, clear and leave the voice channel"),

  async execute(interaction, client) {
    await interaction.deferReply();

    const player = client.lavalink.getPlayer(interaction.guildId);
    const afkVoice = isInAfkVoice(interaction.guildId);

    if (!player?.connected && !afkVoice)
      return interaction.editReply("I'm not in a voice channel.");

    if (player) {
      const current    = player.queue.current;
      const trackCount = (current ? 1 : 0) + player.queue.tracks.length;

      player.set("autoplayAnnounced", false);
      if (trackCount > 0) saveQueue(player);

      await clearVoiceStatus(client, player.voiceChannelId);
      await player.destroy();
    }

    if (afkVoice) leaveAfkChannel(interaction.guildId);

    resetPresence(client);
    await interaction.editReply("Disconnected <:Success:1537804182206160936>");
  },
};