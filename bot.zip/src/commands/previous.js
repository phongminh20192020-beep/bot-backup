"use strict";

const { SlashCommandBuilder } = require("discord.js");
const { playPrevious } = require("../utils/musicPanel");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("previous")
    .setDescription("Go back and play the previous track"),

  async execute(interaction, client) {
    await interaction.deferReply();

    const player = client.lavalink.getPlayer(interaction.guildId);
    if (!player || !player.queue.current)
      return interaction.editReply("Nothing is currently playing.");

    const voiceChannel = interaction.member?.voice?.channel;
    if (!voiceChannel || voiceChannel.id !== player.voiceChannelId)
      return interaction.editReply("You need to be in the same voice channel as me to do that.");

    try {
      const prev = await playPrevious(player);
      if (!prev)
        return interaction.editReply("There's no previous track to go back to.");

      await interaction.editReply(`<:Previous:1537804161960378388> Playing previous track: **${prev.info.title}**`);
    } catch (err) {
      console.error("[Previous] playback error:", err.message);
      await interaction.editReply("Couldn't go back — the audio node isn't responding right now. Try again in a moment.");
    }
  },
};
