"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const {
  newGame,
  makeMove,
  resign,
  chooseBotMove,
  legalMovesFrom,
  squaresWithLegalMoves,
  squareName,
  isInCheck,
  PIECE_NAME,
} = require("../utils/chessEngine");
const { renderBoardImage } = require("../utils/chessRender");

const DEFAULT_WAIT_SEC = 20;
const MOVE_UI_TIMEOUT_MS = 120_000;
const sleep = ms => new Promise(r => setTimeout(r, ms));

const PROMO_LABEL = { q: "Queen", r: "Rook", b: "Bishop", n: "Knight" };

module.exports = {
  data: new SlashCommandBuilder()
    .setName("chess")
    .setDescription("Play a game of chess with real, rendered pieces — vs another player or the built-in bot")
    .addUserOption(o =>
      o.setName("opponent")
        .setDescription("Challenge a specific player (omit to open a lobby, or auto-fill with the bot)")
    )
    .addIntegerOption(o =>
      o.setName("wait")
        .setDescription(`If no opponent is named: seconds to wait for someone to join (default ${DEFAULT_WAIT_SEC})`)
        .setMinValue(10)
        .setMaxValue(60)
    ),

  async execute(interaction) {
    const opponentUser = interaction.options.getUser("opponent");
    const waitSec = interaction.options.getInteger("wait") ?? DEFAULT_WAIT_SEC;

    if (opponentUser && opponentUser.bot) {
      return interaction.reply({ content: "You can't challenge a bot account — omit `opponent` to play against my built-in chess bot instead.", ephemeral: true });
    }
    if (opponentUser && opponentUser.id === interaction.user.id) {
      return interaction.reply({ content: "You can't challenge yourself — omit `opponent` to play the built-in bot.", ephemeral: true });
    }

    // ─── Direct challenge flow ────────────────────────────────────────
    if (opponentUser) {
      const challengeText = `${interaction.user} (White) has challenged ${opponentUser} (Black) to a game of chess.`;
      const challengeEmbed = extra => new EmbedBuilder().setTitle("♟️ Chess Challenge").setDescription(challengeText + (extra ? `\n\n${extra}` : ""));
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("chess_accept").setLabel("Accept").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId("chess_decline").setLabel("Decline").setStyle(ButtonStyle.Danger)
      );
      const msg = await interaction.reply({ embeds: [challengeEmbed()], components: [row], fetchReply: true });

      const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60_000, max: 1 });
      collector.on("collect", async btn => {
        if (btn.user.id !== opponentUser.id) return btn.reply({ content: "This challenge isn't addressed to you.", ephemeral: true });
        if (btn.customId === "chess_decline") {
          await btn.update({ embeds: [challengeEmbed("❌ Challenge declined.")], components: [] });
          return;
        }
        await btn.update({ components: [] });
        return startGameOnMessage(msg, interaction.user, opponentUser);
      });
      collector.on("end", async (collected) => {
        if (collected.size === 0) {
          await msg.edit({ embeds: [challengeEmbed("⌛ Challenge timed out.")], components: [] }).catch(() => {});
        }
      });
      return;
    }

    // ─── Open lobby flow (join, or auto-fill with the bot) ─────────────
    let joined = null;
    let started = false;

    const lobbyEmbed = () =>
      new EmbedBuilder()
        .setTitle("♟️ Chess — Open Table")
        .setDescription(
          `**${interaction.user.username}** (White) is looking for an opponent.\n\n` +
          (joined ? `**${joined.username}** has joined as Black!` : `Click **Join** to play as Black, or wait **${waitSec}s** to play the bot.`)
        );
    const lobbyRow = () =>
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("chess_join").setLabel("Join as Black").setStyle(ButtonStyle.Success).setDisabled(!!joined)
      );

    const msg = await interaction.reply({ embeds: [lobbyEmbed()], components: [lobbyRow()], fetchReply: true });

    const lobbyCollector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, filter: i => i.customId === "chess_join" });
    lobbyCollector.on("collect", async btn => {
      if (started) return;
      if (btn.user.bot) return btn.reply({ content: "Bots can't join — I'll fill the seat with my own built-in bot if nobody does.", ephemeral: true });
      if (btn.user.id === interaction.user.id) return btn.reply({ content: "You're already at the table as White.", ephemeral: true });
      if (joined) return btn.reply({ content: "Someone already took that seat.", ephemeral: true });
      joined = btn.user;
      started = true;
      lobbyCollector.stop("start");
      await btn.update({ embeds: [lobbyEmbed()], components: [] });
      return startGameOnMessage(msg, interaction.user, joined);
    });

    setTimeout(async () => {
      if (started) return;
      started = true;
      lobbyCollector.stop("start");
      await msg.edit({ embeds: [lobbyEmbed()], components: [] }).catch(() => {});
      return startGameOnMessage(msg, interaction.user, null);
    }, waitSec * 1000);
  },
};

// ─── Shared game runner ───────────────────────────────────────────────────
async function startGameOnMessage(msg, whiteUser, blackUserOrNull) {
  const state = newGame();
  const players = {
    w: { color: "w", id: whiteUser.id, username: whiteUser.username, isBot: false },
    b: blackUserOrNull
      ? { color: "b", id: blackUserOrNull.id, username: blackUserOrNull.username, isBot: false }
      : { color: "b", id: "bot", username: "Chess Bot", isBot: true },
  };

  let gameCollector = null;

  const statusLine = () => {
    if (state.status === "checkmate") return `♔ Checkmate — **${players[state.winner].username}** wins!`;
    if (state.status === "stalemate") return "🤝 Stalemate — it's a draw.";
    if (state.status === "draw") return "🤝 Draw (50-move rule).";
    if (state.status === "resigned") return `🏳️ **${players[state.turn].username}** resigned — **${players[state.winner].username}** wins!`;
    const toMove = players[state.turn];
    const checkFlag = isInCheck(state, state.turn) ? " — **Check!**" : "";
    return `**${toMove.username}**'s move (${state.turn === "w" ? "White" : "Black"})${checkFlag}`;
  };

  const buildPublicComponents = () => {
    if (state.status !== "active") return [];
    return [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("chess_move").setLabel("♟️ Make a Move").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("chess_resign").setLabel("Resign").setStyle(ButtonStyle.Danger)
    )];
  };

  const refreshPublic = async logLine => {
    const embed = new EmbedBuilder()
      .setTitle("♟️ Chess")
      .setDescription(`White: **${players.w.username}** ${players.w.isBot ? "(bot)" : ""} — Black: **${players.b.username}** ${players.b.isBot ? "(bot)" : ""}\n\n${logLine ? logLine + "\n\n" : ""}${statusLine()}`)
      .setImage("attachment://board.png");
    const attachment = new AttachmentBuilder(renderBoardImage(state, { flip: false }), { name: "board.png" });
    await msg.edit({ embeds: [embed], files: [attachment], components: buildPublicComponents() }).catch(() => {});
    if (state.status !== "active") gameCollector?.stop("finished");
  };

  await refreshPublic("Game started! White to move.");

  const runBotIfNeeded = async () => {
    while (state.status === "active" && players[state.turn].isBot) {
      await sleep(1000);
      const move = chooseBotMove(state);
      if (!move) break; // shouldn't happen if status is active, but guards against desync
      const promoteTo = move.promotion ? "q" : undefined;
      makeMove(state, move.fromRow, move.fromCol, move.toRow, move.toCol, promoteTo);
      await refreshPublic(`${players[state.lastMove.color].username} played **${state.lastMove.san}**.`);
    }
  };

  gameCollector = msg.createMessageComponentCollector({
    filter: i => i.customId === "chess_move" || i.customId === "chess_resign",
  });

  gameCollector.on("collect", async btn => {
    if (state.status !== "active") return;
    const player = btn.user.id === players.w.id ? players.w : (btn.user.id === players.b.id ? players.b : null);
    if (!player) return btn.reply({ content: "You're not part of this game.", ephemeral: true });

    if (btn.customId === "chess_resign") {
      const confirmRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("chess_resign_yes").setLabel("Yes, resign").setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId("chess_resign_no").setLabel("Cancel").setStyle(ButtonStyle.Secondary)
      );
      const confirmMsg = await btn.reply({ content: "Resign the game? This can't be undone.", components: [confirmRow], ephemeral: true, fetchReply: true });
      const confirmCollector = confirmMsg.createMessageComponentCollector({ time: 30_000, max: 1 });
      confirmCollector.on("collect", async c => {
        if (c.customId === "chess_resign_no") return c.update({ content: "Resignation cancelled.", components: [] });
        resign(state, player.color);
        await c.update({ content: "You resigned.", components: [] });
        await refreshPublic(`🏳️ ${player.username} resigned.`);
      });
      return;
    }

    // chess_move
    if (player.color !== state.turn) {
      return btn.reply({ content: "It's not your turn.", ephemeral: true });
    }
    return runMoveFlow(btn, state, player, refreshPublic, runBotIfNeeded, players);
  });
}

// ─── Ephemeral move-selection flow: pick a square, then a destination ─────
async function runMoveFlow(btn, state, player, refreshPublic, runBotIfNeeded, players) {
  const squares = squaresWithLegalMoves(state, player.color);

  const fromOptions = squares.slice(0, 25).map(s => ({
    label: `${PIECE_NAME[s.piece.type]} ${squareName(s.row, s.col)}`,
    value: `${s.row},${s.col}`,
  }));

  const fromMenu = () => new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder().setCustomId("chess_from").setPlaceholder("Choose a piece to move").addOptions(fromOptions)
  );

  const previewAttachment = (selected, legalTargets) =>
    new AttachmentBuilder(renderBoardImage(state, { flip: player.color === "b", selected, legalTargets }), { name: "preview.png" });

  const ephemeral = await btn.reply({
    content: "It's your move! Pick a piece.",
    files: [previewAttachment(null, [])],
    components: [fromMenu()],
    ephemeral: true,
    fetchReply: true,
  });

  let resolved = false;
  const collector = ephemeral.createMessageComponentCollector({ time: MOVE_UI_TIMEOUT_MS });

  const finalizeMove = async (i, fromRow, fromCol, toRow, toCol, promoteTo) => {
    let result;
    try {
      result = makeMove(state, fromRow, fromCol, toRow, toCol, promoteTo);
    } catch (err) {
      return i.update({ content: `${err.message} Try again.`, files: [], components: [fromMenu()] });
    }
    resolved = true;
    collector.stop("done");
    await i.update({ content: `You played **${state.lastMove.san}**.`, files: [], components: [] });
    await refreshPublic(`${player.username} played **${state.lastMove.san}**.`);
    await runBotIfNeeded();
  };

  collector.on("collect", async i => {
    if (i.user.id !== btn.user.id) return i.reply({ content: "This isn't your move to make.", ephemeral: true });

    if (i.isStringSelectMenu() && i.customId === "chess_from") {
      const [row, col] = i.values[0].split(",").map(Number);
      const legal = legalMovesFrom(state, row, col);
      const legalTargets = legal.map(m => ({ row: m.toRow, col: m.toCol, capture: !!m.capture }));
      const toOptions = legal.slice(0, 25).map(m => ({
        label: `${squareName(m.toRow, m.toCol)}${m.capture ? " (capture)" : ""}${m.castle ? ` — castle ${m.castle === "K" ? "kingside" : "queenside"}` : ""}${m.promotion ? " (promotes)" : ""}`,
        value: `${row},${col},${m.toRow},${m.toCol}`,
      }));
      const toMenu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId("chess_to").setPlaceholder("Choose where to move").addOptions(toOptions)
      );
      const backRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("chess_back").setLabel("« Choose a different piece").setStyle(ButtonStyle.Secondary)
      );
      return i.update({
        content: `Moving the ${PIECE_NAME[state.board[row][col].type]} on ${squareName(row, col)} — pick a destination.`,
        files: [previewAttachment({ row, col }, legalTargets)],
        components: [toMenu, backRow],
      });
    }

    if (i.isButton() && i.customId === "chess_back") {
      return i.update({ content: "It's your move! Pick a piece.", files: [previewAttachment(null, [])], components: [fromMenu()] });
    }

    if (i.isStringSelectMenu() && i.customId === "chess_to") {
      const [fromRow, fromCol, toRow, toCol] = i.values[0].split(",").map(Number);
      const legal = legalMovesFrom(state, fromRow, fromCol);
      const move = legal.find(m => m.toRow === toRow && m.toCol === toCol);
      if (move && move.promotion) {
        const promoRow = new ActionRowBuilder().addComponents(
          ["q", "r", "b", "n"].map(p =>
            new ButtonBuilder().setCustomId(`chess_promo_${fromRow}_${fromCol}_${toRow}_${toCol}_${p}`).setLabel(PROMO_LABEL[p]).setStyle(ButtonStyle.Primary)
          )
        );
        return i.update({ content: "Pawn promotion — choose a piece:", files: [], components: [promoRow] });
      }
      return finalizeMove(i, fromRow, fromCol, toRow, toCol);
    }

    if (i.isButton() && i.customId.startsWith("chess_promo_")) {
      const [, , fromRow, fromCol, toRow, toCol, p] = i.customId.split("_");
      return finalizeMove(i, Number(fromRow), Number(fromCol), Number(toRow), Number(toCol), p);
    }
  });

  collector.on("end", async (_c, reason) => {
    if (resolved || reason !== "time") return;
    await ephemeral.edit({ content: "⌛ Move selection timed out — click **Make a Move** again when you're ready.", files: [], components: [] }).catch(() => {});
  });
}
