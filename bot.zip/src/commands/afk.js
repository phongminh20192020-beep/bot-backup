"use strict";

const { SlashCommandBuilder } = require("discord.js");
const { clearVoiceStatus }    = require("../utils/helpers");
const { joinAfkChannel }      = require("../utils/afkVoice");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("afk")
    .setDescription("Stop music and keep the bot in the voice channel indefinitely"),

  async execute(interaction, client) {
    await interaction.deferReply();

    const voiceChannel = interaction.member.voice?.channel;
    if (!voiceChannel)
      return interaction.editReply("You must be in a voice channel.");

    // Leave Lavalink entirely for this guild -- AFK mode no longer depends
    // on it at all, so free up the node instead of leaving an idle player.
    const player = client.lavalink.getPlayer(interaction.guildId);
    if (player) {
      await clearVoiceStatus(client, player.voiceChannelId);
      await player.destroy().catch(() => {});
    }

    joinAfkChannel(client, interaction.guild, voiceChannel);

    await interaction.editReply("<:AFK:1537804134600671233> AFK mode active");
  },
};