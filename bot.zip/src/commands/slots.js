"use strict";

const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { getBalance, addCoins, removeCoins } = require("../utils/economy");
const { renderSlots } = require("../utils/slotsRender");

const IMAGE_NAME = "slots.png";

// Weighted so rarer symbols pay more -- weight is "how many tickets in the
// bag", payout is the multiplier for landing 3 of that symbol.
const SYMBOLS = [
  { key: "cherry",  emoji: "🍒", weight: 40, payout: 1.5 },
  { key: "lemon",   emoji: "🍋", weight: 28, payout: 2 },
  { key: "grape",   emoji: "🍇", weight: 18, payout: 3 },
  { key: "bell",    emoji: "🔔", weight: 10, payout: 6 },
  { key: "diamond", emoji: "💎", weight: 5,  payout: 12 },
  { key: "seven",   emoji: "7️⃣", weight: 2,  payout: 30 },
];
const TOTAL_WEIGHT = SYMBOLS.reduce((s, x) => s + x.weight, 0);

// Any two matching cherries anywhere pays a small consolation multiplier,
// same as real slot machines -- keeps near-misses feeling less dead.
const TWO_CHERRY_PAYOUT = 0.4;

function spinReel() {
  let roll = Math.random() * TOTAL_WEIGHT;
  for (const s of SYMBOLS) {
    if (roll < s.weight) return s;
    roll -= s.weight;
  }
  return SYMBOLS[0];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("slots")
    .setDescription("Spin the slot machine, wagering coins")
    .addIntegerOption(o =>
      o.setName("bet")
        .setDescription("How many coins to wager")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1_000_000)
    ),

  async execute(interaction) {
    const bet     = interaction.options.getInteger("bet", true);
    const balance = getBalance(interaction.user.id);

    if (balance < bet) {
      return interaction.reply({
        content: `You don't have enough coins for that bet — your balance is **${balance.toLocaleString()}** coins.`,
        ephemeral: true,
      });
    }

    removeCoins(interaction.user.id, bet);

    const reels = [spinReel(), spinReel(), spinReel()];

    let multiplier = 0;
    if (reels[0].emoji === reels[1].emoji && reels[1].emoji === reels[2].emoji) {
      multiplier = reels[0].payout;
    } else if (reels.filter(r => r.emoji === "🍒").length === 2) {
      multiplier = TWO_CHERRY_PAYOUT;
    }

    const winnings = Math.floor(bet * multiplier);
    if (winnings > 0) addCoins(interaction.user.id, winnings);
    const newBalance = getBalance(interaction.user.id);

    let status;
    if (multiplier === 0) status = `No match. You lose your **${bet.toLocaleString()}** coin bet. Balance: **${newBalance.toLocaleString()}**.`;
    else if (multiplier < 1) status = `Small hit! You get back **${winnings.toLocaleString()}** coins (${multiplier}x). Balance: **${newBalance.toLocaleString()}**.`;
    else status = `**JACKPOT-style win!** You get **${winnings.toLocaleString()}** coins (${multiplier}x)! Balance: **${newBalance.toLocaleString()}**.`;

    const embed = new EmbedBuilder()
      .setTitle("🎰 Slots")
      .setDescription(status)
      .setImage(`attachment://${IMAGE_NAME}`)
      .setFooter({ text: `Bet: ${bet.toLocaleString()} coins` });

    const image = renderSlots(reels.map(r => r.key));
    const attachment = new AttachmentBuilder(image, { name: IMAGE_NAME });

    await interaction.reply({ embeds: [embed], files: [attachment] });
  },
};
