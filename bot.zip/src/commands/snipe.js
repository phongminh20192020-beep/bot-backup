"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { getSnipes } = require("../utils/snipeCache");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("snipe")
    .setDescription("Show a recently deleted message in this channel")
    .addUserOption(o =>
      o.setName("user")
        .setDescription("Only show deletes from this user")
    )
    .addIntegerOption(o =>
      o.setName("index")
        .setDescription("Which deleted message back to show (1 = most recent, default 1)")
        .setMinValue(1)
        .setMaxValue(5)
    ),

  async execute(interaction) {
    const index      = interaction.options.getInteger("index") ?? 1;
    const userFilter  = interaction.options.getUser("user");
    let   snipes      = getSnipes(interaction.channel.id);

    if (userFilter) {
      snipes = snipes.filter(e => e.authorId === userFilter.id);
    }

    if (!snipes.length) {
      const who = userFilter ? ` from ${userFilter.tag}` : "";
      return interaction.reply({ content: `nothing to snipe in here${who} -- no tracked deletes in the last 30 min.`, ephemeral: true });
    }

    const entry = snipes[index - 1];
    if (!entry) {
      const who = userFilter ? ` from ${userFilter.tag}` : "";
      return interaction.reply({
        content: `only ${snipes.length} deleted message${snipes.length === 1 ? "" : "s"} tracked in this channel${who} -- try an index between 1 and ${snipes.length}.`,
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setAuthor({ name: entry.authorTag, iconURL: entry.authorAvatar })
      .setDescription(entry.content || "*(no text -- attachment only)*")
      .setFooter({ text: `#${index} most recent delete here · originally sent` })
      .setTimestamp(entry.createdTimestamp);

    if (entry.attachments.length) {
      embed.setImage(entry.attachments[0]);
      if (entry.attachments.length > 1) {
        embed.addFields({ name: "Other attachments", value: entry.attachments.slice(1).join("\n").slice(0, 1000) });
      }
    }

    return interaction.reply({ embeds: [embed] });
  },
};