"use strict";

const { SlashCommandBuilder, EmbedBuilder, Routes, UserFlagsBitField } = require("discord.js");
const { withApiLog } = require("../utils/apiLogger");

// Human-readable labels for the badge flags GET /users/{id} exposes via
// public_flags. Anything not in this map still shows up (falls back to the
// raw flag name from discord.js), this just prettifies the common ones.
const FLAG_LABELS = {
  Staff:                 "Discord Staff",
  Partner:               "Partnered Server Owner",
  Hypesquad:              "HypeSquad Events",
  BugHunterLevel1:        "Bug Hunter",
  HypeSquadOnlineHouse1:  "House of Bravery",
  HypeSquadOnlineHouse2:  "House of Brilliance",
  HypeSquadOnlineHouse3:  "House of Balance",
  PremiumEarlySupporter:  "Early Supporter",
  BugHunterLevel2:        "Bug Hunter (Gold)",
  VerifiedBot:            "Verified Bot",
  VerifiedDeveloper:      "Early Verified Bot Developer",
  CertifiedModerator:     "Moderator Programs Alumni",
  ActiveDeveloper:        "Active Developer",
};

const PREMIUM_TYPES = { 0: "None", 1: "Nitro Classic", 2: "Nitro", 3: "Nitro Basic" };

// GET /users/{id} -- this is the same public profile data Discord's own
// client shows on a profile card (username, avatar, banner, badges, account
// creation date). It does NOT expose email, phone, DMs, or anything private
// -- the bot token doesn't have access to any of that through this endpoint.
const fetchDiscordUser = withApiLog(
  "Discord",
  "GET /users/{id}",
  (client, userId) => client.rest.get(Routes.user(userId)),
  (client, userId) => userId
);

function avatarUrlFor(raw) {
  if (raw.avatar) {
    const ext = raw.avatar.startsWith("a_") ? "gif" : "png";
    return `https://cdn.discordapp.com/avatars/${raw.id}/${raw.avatar}.${ext}?size=1024`;
  }
  const idx = Number((BigInt(raw.id) >> 22n) % 6n);
  return `https://cdn.discordapp.com/embed/avatars/${idx}.png`;
}

function bannerUrlFor(raw) {
  if (!raw.banner) return null;
  const ext = raw.banner.startsWith("a_") ? "gif" : "png";
  return `https://cdn.discordapp.com/banners/${raw.id}/${raw.banner}.${ext}?size=1024`;
}

// Discord snowflake -> creation timestamp: top 42 bits are ms since the
// Discord epoch (2015-01-01T00:00:00.000Z).
function createdAtFor(id) {
  return new Date(Number((BigInt(id) >> 22n) + 1420070400000n));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("spy")
    .setDescription("Look up everything Discord's public API exposes about a user")
    .addUserOption(o => o.setName("user").setDescription("Who to look up").setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser("user", true);
    await interaction.deferReply();

    let raw;
    try {
      raw = await fetchDiscordUser(interaction.client, target.id);
    } catch (err) {
      return interaction.editReply(`couldn't fetch that user from Discord's API: \`${err.message.slice(0, 200)}\``);
    }

    const badgeNames = new UserFlagsBitField(raw.public_flags ?? 0)
      .toArray()
      .map(f => FLAG_LABELS[f] || f);

    const embed = new EmbedBuilder()
      .setTitle(raw.global_name || raw.username)
      .setThumbnail(avatarUrlFor(raw))
      .addFields(
        { name: "Username", value: `@${raw.username}`, inline: true },
        { name: "ID", value: raw.id, inline: true },
        { name: "Bot?", value: raw.bot ? "yes" : "no", inline: true },
        { name: "Account created", value: `<t:${Math.floor(createdAtFor(raw.id).getTime() / 1000)}:F>`, inline: true },
        { name: "Nitro", value: PREMIUM_TYPES[raw.premium_type ?? 0] || "Unknown", inline: true },
        { name: "Badges", value: badgeNames.length ? badgeNames.join(", ") : "none", inline: false },
      )
      .setFooter({ text: "Public profile data only -- the same info visible on their profile card in Discord." });

    const bannerUrl = bannerUrlFor(raw);
    if (bannerUrl) embed.setImage(bannerUrl);

    // Bonus, this-server-specific info if they're actually a member here --
    // the /users/{id} endpoint alone has no idea about guild membership.
    if (interaction.guild) {
      const member = await interaction.guild.members.fetch(raw.id).catch(() => null);
      if (member) {
        const roleNames = member.roles.cache
          .filter(r => r.id !== interaction.guild.id)
          .map(r => r.toString())
          .join(", ")
          .slice(0, 1000);
        embed.addFields(
          { name: "Nickname (this server)", value: member.nickname || "none", inline: true },
          { name: "Joined this server", value: member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : "unknown", inline: true },
          { name: "Roles", value: roleNames || "none", inline: false },
        );
      }
    }

    return interaction.editReply({ embeds: [embed] });
  },
};
