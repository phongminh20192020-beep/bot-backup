"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const {
  noMercyStartGame,
  noMercyPlayCard,
  noMercyResolveSeven,
  noMercyForceDrawStack,
  noMercyDrawOnTurn,
  noMercyChooseBotMove,
  nmCanPlay,
  nmCanPlayWildFour,
  nmPlayableIndices,
  nmCardLabel,
} = require("../utils/unoVariants");
const { advanceTurn } = require("../utils/unoEngine");
const { renderHandImage, renderTableImage } = require("../utils/unoRender");

const DEFAULT_WAIT_SEC = 20;
const TURN_TIMEOUT_MS  = 90_000;
const COLORS = ["red", "yellow", "green", "blue"];
const sleep = ms => new Promise(r => setTimeout(r, ms));

const RULES_TEXT =
  "**UNO No Mercy — house rules**\n" +
  "• **Draw Six**, **Draw Ten** join Draw Two / Wild Draw Four as attack cards.\n" +
  "• Draw cards **stack**: hit with one? Fire back any draw card (any color) to pass on a bigger total instead of drawing. The stack only resolves when someone can't or won't add to it.\n" +
  "• **Skip Everyone** — every other player is skipped and you go again.\n" +
  "• **Discard All** — also dumps every other card of that color from your hand.\n" +
  "• Number **0** — everyone passes their whole hand to the next player.\n" +
  "• Number **7** — swap your whole hand with a player of your choice.\n" +
  "• Reverse acts as a Skip in a 2-player game.";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unonomercy")
    .setDescription("Start a game of UNO No Mercy — stacking draw cards and brutal new cards")
    .addIntegerOption(o =>
      o.setName("size")
        .setDescription("Total number of seats at the table")
        .setRequired(true)
        .addChoices(
          { name: "2 players", value: 2 },
          { name: "3 players", value: 3 },
          { name: "4 players", value: 4 }
        )
    )
    .addIntegerOption(o =>
      o.setName("wait")
        .setDescription(`Seconds to wait for others to join (default ${DEFAULT_WAIT_SEC})`)
        .setMinValue(10)
        .setMaxValue(60)
    ),

  async execute(interaction) {
    const size    = interaction.options.getInteger("size", true);
    const waitSec = interaction.options.getInteger("wait") ?? DEFAULT_WAIT_SEC;

    const seats = [{ id: interaction.user.id, user: interaction.user, isBot: false }];
    let started = false;
    let state   = null;
    let gameCollector = null;

    const renderLobbyEmbed = () =>
      new EmbedBuilder()
        .setTitle("💀 UNO No Mercy Table — Open")
        .setDescription(
          `${seats.map(s => `• ${s.user.username}`).join("\n")}\n\n` +
          `Seats: **${seats.length}/${size}**\n` +
          `Starts in **${waitSec}s** (or when the host clicks Start Now). Empty seats fill with bots.\n\n${RULES_TEXT}`
        );

    const renderLobbyRow = () =>
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("unm_join").setLabel("Join").setStyle(ButtonStyle.Success).setDisabled(seats.length >= size),
        new ButtonBuilder().setCustomId("unm_start").setLabel("Start Now").setStyle(ButtonStyle.Primary)
      );

    const msg = await interaction.reply({ embeds: [renderLobbyEmbed()], components: [renderLobbyRow()], fetchReply: true });

    const pendingFlag = () => state.pendingDraw ? `\n☠️ **${state.pendingDraw.count} cards** pending — stack or draw!` : "";

    const refreshPublicTable = async logLine => {
      const current = state.players[state.turnIndex];
      const unoFlag = current.hand.length === 1 ? `\n🔥 **${current.username} has UNO!**` : "";
      const embed = new EmbedBuilder()
        .setTitle("💀 UNO No Mercy Table")
        .setDescription(`${logLine ? logLine + "\n\n" : ""}It's **${current.username}**'s turn.${unoFlag}${pendingFlag()}`)
        .setImage("attachment://table.png");
      const attachment = new AttachmentBuilder(renderTableImage(state), { name: "table.png" });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("unm_hand").setLabel("🖐️ My Hand").setStyle(ButtonStyle.Primary)
      );
      await msg.edit({ embeds: [embed], files: [attachment], components: [row] }).catch(() => {});
    };

    const announceWinner = async winner => {
      const attachment = new AttachmentBuilder(renderTableImage(state), { name: "table.png" });
      const embed = new EmbedBuilder()
        .setTitle("🎉 UNO No Mercy — Game Over!")
        .setDescription(`**${winner.username}** wins the game!`)
        .setImage("attachment://table.png");
      await msg.edit({ embeds: [embed], files: [attachment], components: [] }).catch(() => {});
      gameCollector?.stop("finished");
    };

    const effectLine = (actor, card, result, chosenColor) => {
      let line = `${actor.username} played **${nmCardLabel(card)}**${chosenColor ? ` (chose ${chosenColor})` : ""}.`;
      if (result.effect === "draw_stack") line += `\n☠️ Draw stack is now **${state.pendingDraw.count}**.`;
      if (result.effect === "skipall") line += "\n⛔ Everyone else is skipped!";
      if (result.effect === "discardall") line += `\n💥 Also dumped ${result.extraDiscarded} more ${card.color} card(s)!`;
      if (result.effect === "zero_rotate") line += "\n🔁 Everyone passed their hand along!";
      return line;
    };

    // ─── Bot turn loop ──────────────────────────────────────────────────
    const runBotLoop = async () => {
      while (!state.winnerId && state.players[state.turnIndex].isBot) {
        await sleep(1200);
        const botIdx = state.turnIndex;
        const bot    = state.players[botIdx];
        const move   = noMercyChooseBotMove(state, botIdx);

        if (move.action === "draw") {
          if (state.pendingDraw) {
            const n = noMercyForceDrawStack(state, botIdx);
            await refreshPublicTable(`${bot.username} couldn't stack — drew **${n}** cards.`);
            continue;
          }
          const drawn = noMercyDrawOnTurn(state, botIdx);
          if (drawn) {
            const cardIdx = bot.hand.length - 1;
            const playable = nmCanPlay(drawn, state) &&
              !(drawn.type === "draw4" && !nmCanPlayWildFour(bot.hand, cardIdx, state.currentColor));
            if (playable) {
              let chosenColor = null;
              if (drawn.color === "wild") {
                const counts = { red: 0, yellow: 0, green: 0, blue: 0 };
                bot.hand.forEach((c, i) => { if (i !== cardIdx && c.color !== "wild") counts[c.color]++; });
                const best = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
                chosenColor = best[1] > 0 ? best[0] : COLORS[Math.floor(Math.random() * 4)];
              }
              const result = noMercyPlayCard(state, botIdx, cardIdx, chosenColor);
              await refreshPublicTable(effectLine(bot, drawn, result, chosenColor));
              if (result.effect === "win") return announceWinner(bot);
              if (result.effect === "seven_pending") {
                const t = pickBotSevenTarget(botIdx);
                noMercyResolveSeven(state, botIdx, t);
                await refreshPublicTable(`${bot.username} swapped hands with ${state.players[t].username}!`);
              }
              continue;
            }
          }
          advanceTurn(state);
          await refreshPublicTable(`${bot.username} drew a card.`);
          continue;
        }

        const card   = bot.hand[move.cardIdx];
        const result = noMercyPlayCard(state, botIdx, move.cardIdx, move.chosenColor);
        await refreshPublicTable(effectLine(bot, card, result, move.chosenColor));
        if (result.effect === "win") return announceWinner(bot);
        if (result.effect === "seven_pending") {
          const t = move.sevenTargetIdx ?? pickBotSevenTarget(botIdx);
          noMercyResolveSeven(state, botIdx, t);
          await refreshPublicTable(`${bot.username} swapped hands with ${state.players[t].username}!`);
        }
      }
    };

    function pickBotSevenTarget(botIdx) {
      let best = -1, bestLen = Infinity;
      state.players.forEach((p, i) => { if (i !== botIdx && p.hand.length < bestLen) { bestLen = p.hand.length; best = i; } });
      return best;
    }

    const afterHumanMove = async (player, result, line) => {
      if (result.effect === "win") return announceWinner(player);
      await refreshPublicTable(line || `${player.username} played a card.`);
      await runBotLoop();
    };

    // ─── "My Hand" -> per-player ephemeral turn UI ─────────────────────
    const handleHandButton = async btn => {
      const player = state.players.find(p => p.id === btn.user.id && !p.isBot);
      if (!player) return btn.reply({ content: "You're not seated at this table.", ephemeral: true });

      const idx = state.players.findIndex(p => p.id === player.id);
      const isMyTurn = state.turnIndex === idx;
      const handAttachment = () => new AttachmentBuilder(renderHandImage(player.hand), { name: "hand.png" });

      if (!isMyTurn) {
        return btn.reply({
          content: `Your hand — waiting for **${state.players[state.turnIndex].username}**'s turn.`,
          files: [handAttachment()],
          ephemeral: true,
        });
      }

      const buildTurnUI = () => {
        const legal = nmPlayableIndices(player.hand, state);
        const options = player.hand.slice(0, 24).map((c, i) => ({
          label: nmCardLabel(c).slice(0, 100),
          value: String(i),
          description: legal.includes(i) ? "Playable" : "Not playable right now",
        }));
        options.push({
          label: state.pendingDraw ? `Draw ${state.pendingDraw.count} cards` : "Draw a card",
          value: "draw",
          description: "Draw from the deck",
        });
        const menu = new StringSelectMenuBuilder()
          .setCustomId("unm_action")
          .setPlaceholder(state.pendingDraw ? `Stack a draw card, or draw ${state.pendingDraw.count}` : "Choose a card to play, or draw")
          .addOptions(options.slice(0, 25));
        return [new ActionRowBuilder().addComponents(menu)];
      };

      const colorRow = cardIdx =>
        new ActionRowBuilder().addComponents(
          COLORS.map(c =>
            new ButtonBuilder()
              .setCustomId(`unm_color_${c}_${cardIdx}`)
              .setLabel(c[0].toUpperCase() + c.slice(1))
              .setStyle(ButtonStyle.Secondary)
          )
        );

      const targetRow = cardIdx =>
        new ActionRowBuilder().addComponents(
          state.players
            .filter(p => p.id !== player.id)
            .slice(0, 5)
            .map(p =>
              new ButtonBuilder()
                .setCustomId(`unm_seven_${state.players.findIndex(x => x.id === p.id)}_${cardIdx}`)
                .setLabel(`Swap with ${p.username}`.slice(0, 80))
                .setStyle(ButtonStyle.Danger)
            )
        );

      const ephemeral = await btn.reply({
        content: state.pendingDraw
          ? `It's your turn! ☠️ ${state.pendingDraw.count} cards are coming — stack a Draw card or take them.`
          : "It's your turn! Pick a card to play, or draw.",
        files: [handAttachment()],
        components: buildTurnUI(),
        ephemeral: true,
        fetchReply: true,
      });

      let resolved = false;
      const turnCollector = ephemeral.createMessageComponentCollector({ time: TURN_TIMEOUT_MS });

      const finishPlay = async (i, cardIdx, chosenColor, card) => {
        const result = noMercyPlayCard(state, idx, cardIdx, chosenColor);

        if (result.effect === "seven_pending") {
          await i.update({ content: `Playing **${nmCardLabel(card)}** — choose who to swap hands with:`, files: [], components: [targetRow(cardIdx)] });
          return; // wait for target selection; turn not resolved yet
        }

        resolved = true;
        turnCollector.stop("done");
        await i.update({ content: `You played **${nmCardLabel(card)}**${chosenColor ? ` (chose ${chosenColor})` : ""}.`, files: [], components: [] });
        return afterHumanMove(player, result, effectLine(player, card, result, chosenColor));
      };

      turnCollector.on("collect", async i => {
        if (i.user.id !== player.id) return i.reply({ content: "This isn't your turn.", ephemeral: true });

        if (i.isStringSelectMenu() && i.customId === "unm_action") {
          const value = i.values[0];

          if (value === "draw") {
            if (state.pendingDraw) {
              const n = noMercyForceDrawStack(state, idx);
              resolved = true;
              turnCollector.stop("done");
              await i.update({ content: `You drew **${n}** cards — turn passed.`, files: [], components: [] });
              await refreshPublicTable(`${player.username} took the ${n}-card stack.`);
              return runBotLoop();
            }

            const drawn = noMercyDrawOnTurn(state, idx);
            if (!drawn) {
              resolved = true;
              turnCollector.stop("done");
              await i.update({ content: "The deck is empty — turn passed.", files: [], components: [] });
              advanceTurn(state);
              await refreshPublicTable(`${player.username} tried to draw, but the deck is empty.`);
              return runBotLoop();
            }

            const drawnIdx = player.hand.length - 1;
            const playable = nmCanPlay(drawn, state) &&
              !(drawn.type === "draw4" && !nmCanPlayWildFour(player.hand, drawnIdx, state.currentColor));

            if (!playable) {
              resolved = true;
              turnCollector.stop("done");
              await i.update({ content: `You drew **${nmCardLabel(drawn)}** — no valid play, turn passed.`, files: [], components: [] });
              advanceTurn(state);
              await refreshPublicTable(`${player.username} drew a card.`);
              return runBotLoop();
            }

            const yesNo = new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId("unm_playdrawn_yes").setLabel(`Play ${nmCardLabel(drawn)}`).setStyle(ButtonStyle.Success),
              new ButtonBuilder().setCustomId("unm_playdrawn_no").setLabel("Keep it, pass turn").setStyle(ButtonStyle.Secondary)
            );
            return i.update({ content: `You drew **${nmCardLabel(drawn)}** — play it now or keep it?`, files: [], components: [yesNo] });
          }

          const cardIdx = parseInt(value, 10);
          const card = player.hand[cardIdx];
          if (!card) return i.reply({ content: "That card isn't there anymore.", ephemeral: true });

          if (card.color === "wild") {
            return i.update({ content: `Playing **${nmCardLabel(card)}** — choose a color:`, files: [], components: [colorRow(cardIdx)] });
          }

          try {
            return await finishPlay(i, cardIdx, undefined, card);
          } catch (err) {
            return i.reply({ content: err.message, ephemeral: true });
          }
        }

        if (i.isButton() && i.customId === "unm_playdrawn_yes") {
          const drawnIdx  = player.hand.length - 1;
          const drawnCard = player.hand[drawnIdx];
          if (drawnCard.color === "wild") {
            return i.update({ content: `Playing **${nmCardLabel(drawnCard)}** — choose a color:`, components: [colorRow(drawnIdx)] });
          }
          return finishPlay(i, drawnIdx, undefined, drawnCard);
        }

        if (i.isButton() && i.customId === "unm_playdrawn_no") {
          resolved = true;
          turnCollector.stop("done");
          advanceTurn(state);
          await i.update({ content: "Kept the card — turn passed.", components: [] });
          await refreshPublicTable(`${player.username} drew and kept a card.`);
          return runBotLoop();
        }

        if (i.isButton() && i.customId.startsWith("unm_color_")) {
          const [, , color, idxStr] = i.customId.split("_");
          const cardIdx = parseInt(idxStr, 10);
          const card = player.hand[cardIdx];
          try {
            return await finishPlay(i, cardIdx, color, card);
          } catch (err) {
            return i.update({ content: err.message, components: [] });
          }
        }

        if (i.isButton() && i.customId.startsWith("unm_seven_")) {
          const [, , targetIdxStr] = i.customId.split("_");
          const targetIdx = parseInt(targetIdxStr, 10);
          noMercyResolveSeven(state, idx, targetIdx);
          resolved = true;
          turnCollector.stop("done");
          const targetName = state.players[targetIdx].username;
          await i.update({ content: `You swapped hands with **${targetName}**.`, components: [] });
          return afterHumanMove(player, { effect: "swap" }, `${player.username} swapped hands with ${targetName}!`);
        }
      });

      turnCollector.on("end", async (_c, reason) => {
        if (resolved || reason !== "time") return;
        if (state.pendingDraw) {
          const n = noMercyForceDrawStack(state, idx);
          await ephemeral.edit({ content: `⌛ Timed out — drew **${n}** cards and passed your turn.`, files: [], components: [] }).catch(() => {});
          await refreshPublicTable(`${player.username} took too long and drew the ${n}-card stack.`);
          return runBotLoop();
        }
        const drawn = noMercyDrawOnTurn(state, idx);
        advanceTurn(state);
        await ephemeral.edit({
          content: drawn
            ? `⌛ Timed out — drew **${nmCardLabel(drawn)}** and passed your turn.`
            : "⌛ Timed out — turn passed.",
          files: [], components: [],
        }).catch(() => {});
        await refreshPublicTable(`${player.username} took too long and their turn was passed.`);
        await runBotLoop();
      });
    };

    // ─── Lobby -> game transition ───────────────────────────────────────
    const beginGame = async () => {
      if (started) return;
      started = true;
      lobbyCollector.stop("start");

      let botCount = 0;
      while (seats.length < size) {
        botCount++;
        seats.push({ id: `bot_${botCount}`, user: null, isBot: true, username: `Bot ${botCount}` });
      }

      const playerInfos = seats.map(s => ({ id: s.id, isBot: s.isBot, username: s.isBot ? s.username : s.user.username }));
      state = noMercyStartGame(playerInfos);

      for (const s of seats) {
        if (s.isBot) continue;
        const hand = state.players.find(p => p.id === s.id).hand;
        const attachment = new AttachmentBuilder(renderHandImage(hand), { name: "hand.png" });
        try {
          await s.user.send({
            content: `💀 Your UNO No Mercy hand for the game in **${interaction.guild?.name ?? "this server"}**! Use the table message's "My Hand" button any time for an updated view and to take your turn.`,
            files: [attachment],
          });
        } catch {
          await msg.channel.send({
            content: `${s.user} — I couldn't DM you your hand (check that DMs from server members are allowed). You can still play using the "🖐️ My Hand" button on the table below.`,
          }).catch(() => {});
        }
      }

      await refreshPublicTable("Game started! Cards have been dealt. No mercy.");

      gameCollector = msg.createMessageComponentCollector({
        componentType: ComponentType.Button,
        filter: i => i.customId === "unm_hand",
      });
      gameCollector.on("collect", handleHandButton);

      await runBotLoop();
    };

    // ─── Lobby collector ────────────────────────────────────────────────
    const lobbyCollector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      filter: i => i.customId === "unm_join" || i.customId === "unm_start",
    });

    lobbyCollector.on("collect", async btn => {
      if (started) return;

      if (btn.customId === "unm_start") {
        if (btn.user.id !== interaction.user.id) {
          return btn.reply({ content: "Only the host can start early.", ephemeral: true });
        }
        await btn.deferUpdate();
        return beginGame();
      }

      if (btn.user.bot) return btn.reply({ content: "Bots fill empty seats automatically — no need to add one.", ephemeral: true });
      if (seats.find(s => s.id === btn.user.id)) return btn.reply({ content: "You're already seated.", ephemeral: true });
      if (seats.length >= size) return btn.reply({ content: "This table is full.", ephemeral: true });

      seats.push({ id: btn.user.id, user: btn.user, isBot: false });
      await btn.update({ embeds: [renderLobbyEmbed()], components: [renderLobbyRow()] });
      if (seats.length === size) await beginGame();
    });

    setTimeout(() => { if (!started) beginGame(); }, waitSec * 1000);
  },
};
