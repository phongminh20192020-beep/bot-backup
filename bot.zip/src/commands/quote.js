"use strict";

const { ContextMenuCommandBuilder, ApplicationCommandType, AttachmentBuilder } = require("discord.js");
const path = require("path");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");

// Register real Roboto font files instead of trusting Georgia/Times New
// Roman/Roboto to already be installed on whatever host this runs on --
// that's what caused the "why is this bold and the wrong font" issue:
// Georgia isn't a real font on most Linux hosts, so canvas was silently
// falling back to a default system font (which rendered heavier/bolder
// than intended) instead of erroring. Registering explicit files makes the
// output identical regardless of host. Registered once at module load,
// under family name "Roboto" -- style/weight below then just work as
// normal CSS font-shorthand instead of needing separate family names per
// variant.
const FONTS_DIR = path.join(__dirname, "..", "..", "assets", "fonts");
// registerFromPath fails COMPLETELY SILENTLY if the file isn't found at
// that path -- no throw, no error, it just quietly never registers and
// every font call below falls back to whatever the host substitutes
// (which is the exact original "why is this bold/wrong font" bug this was
// meant to fix). Checking + logging loudly here so a missing/misplaced
// font bundle is immediately obvious in the console instead of silently
// reproducing the same bug with zero indication why.
for (const file of ["Roboto-Regular.ttf", "Roboto-Italic.ttf", "Roboto-Medium.ttf", "Roboto-MediumItalic.ttf"]) {
  const ok = GlobalFonts.registerFromPath(path.join(FONTS_DIR, file), "Roboto");
  if (!ok) {
    console.error(`[Quote] FAILED to register font "${file}" from ${FONTS_DIR} -- quote cards will render with a fallback font, not Roboto. Make sure assets/fonts/ was extracted to the PROJECT ROOT (same level as src/, package.json), not inside src/.`);
  }
}
if (!GlobalFonts.has("Roboto")) {
  console.error("[Quote] Roboto is NOT registered after startup -- every quote card from this point will use whatever font the host falls back to. Check the errors above for which file(s) failed to load.");
}

// registerFromPath() returning true and GlobalFonts.has("Roboto") being
// true only prove a family named "Roboto" exists -- neither one confirms
// the *italic* files actually contain real italic glyph data internally.
// If Roboto-Italic.ttf / Roboto-MediumItalic.ttf are corrupt, or are
// accidental duplicates of the regular/medium files, canvas will silently
// synthesize a fake slant on the regular face for any "italic" font
// request instead of erroring -- visually italic-ish, but not true
// Roboto Italic. This check catches that silently, at startup.
const robotoFamily = GlobalFonts.families.find(f => f.family === "Roboto");
const hasRealItalic = robotoFamily?.styles.some(s => s.style === "italic");
if (!hasRealItalic) {
  console.error("[Quote] Roboto family exists but has NO real italic face registered -- quote text (rendered with `italic ...px Roboto`) will render as a synthetic slant of Roboto Regular, not true Roboto Italic. Check that Roboto-Italic.ttf and Roboto-MediumItalic.ttf are genuine italic font files, not duplicates/corrupt copies of the regular files.");
}

const WIDTH  = 1200;
const HEIGHT = 650;
const IMAGE_W = Math.round(WIDTH * 0.46); // left photo panel width
const WATERMARK = "NoName's Copyright 2026";

const QUOTE_MAX_FONT = 72;
const QUOTE_MIN_FONT = 16;
const TOP_MARGIN = 50;
const BOTTOM_RESERVE = 140; // clearance for author name + handle + watermark below the quote
const QUOTE_AVAILABLE_HEIGHT = HEIGHT - TOP_MARGIN - BOTTOM_RESERVE;

// Greedily wraps text into at most maxLines. Returns whether any words had
// to be dropped -- callers use this to decide whether to shrink the font
// and try again before ever falling back to an ellipsis.
function wrapText(ctx, text, maxWidth, maxLines) {
  const words = text.split(/\s+/).filter(Boolean);
  const lines = [];
  let line = "";
  let i = 0;

  while (i < words.length) {
    const word = words[i];
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width <= maxWidth) {
      line = test;
      i++;
    } else if (line) {
      lines.push(line);
      line = "";
      if (lines.length === maxLines) break;
    } else {
      // a single word wider than maxWidth on its own -- place it anyway
      line = word;
      i++;
    }
  }
  if (line && lines.length < maxLines) lines.push(line);

  const truncated = i < words.length;
  if (truncated) {
    const last = lines[lines.length - 1] || "";
    let t = last;
    while (ctx.measureText(t + "…").width > maxWidth && t.length > 1) {
      t = t.slice(0, -1);
    }
    lines[lines.length - 1] = t + "…";
  }

  return { lines, truncated };
}

// Finds the largest font size (down to QUOTE_MIN_FONT) that lets the quote
// wrap into the available vertical space without truncating. Smaller font
// sizes fit more lines, so this is retried at each step down.
function fitQuoteText(ctx, text, maxWidth, availableHeight) {
  let best = null;

  for (let fontSize = QUOTE_MAX_FONT; fontSize >= QUOTE_MIN_FONT; fontSize -= 2) {
    ctx.font = `italic ${fontSize}px Roboto, sans-serif`;
    const lineHeight = Math.round(fontSize * 1.35);
    const maxLines = Math.max(1, Math.floor(availableHeight / lineHeight));
    const { lines, truncated } = wrapText(ctx, text, maxWidth, maxLines);
    best = { lines, fontSize, lineHeight, truncated };
    if (!truncated) return best;
  }

  // Even at the smallest size it didn't fully fit -- use the min-size
  // result with its ellipsis rather than shrinking indefinitely.
  return best;
}

// Converts a canvas region to true flat grayscale in place (cover-fit avatar).
function toGrayscale(ctx, x, y, w, h) {
  const imgData = ctx.getImageData(x, y, w, h);
  const d = imgData.data;
  for (let i = 0; i < d.length; i += 4) {
    const gray = 0.21 * d[i] + 0.72 * d[i + 1] + 0.07 * d[i + 2];
    d[i] = d[i + 1] = d[i + 2] = gray;
  }
  ctx.putImageData(imgData, x, y);
}

async function renderQuoteCard({ text, authorName, authorHandle, avatarUrl }) {
  const canvas = createCanvas(WIDTH, HEIGHT);
  const ctx = canvas.getContext("2d");

  // Right panel: solid black background for the whole card first.
  ctx.fillStyle = "#000000";
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  // Left panel: the real sender's real avatar, cover-fit, then desaturated
  // to match the black-and-white portrait look from the reference design.
  try {
    const avatar = await loadImage(avatarUrl);
    const scale = Math.max(IMAGE_W / avatar.width, HEIGHT / avatar.height);
    const dw = avatar.width * scale, dh = avatar.height * scale;
    const dx = (IMAGE_W - dw) / 2, dy = (HEIGHT - dh) / 2;

    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, IMAGE_W, HEIGHT);
    ctx.clip();
    ctx.drawImage(avatar, dx, dy, dw, dh);
    ctx.restore();

    toGrayscale(ctx, 0, 0, IMAGE_W, HEIGHT);

    // Soft fade where the photo meets the black panel so the edge doesn't
    // look like a hard cut.
    const fade = ctx.createLinearGradient(IMAGE_W - 120, 0, IMAGE_W, 0);
    fade.addColorStop(0, "rgba(0,0,0,0)");
    fade.addColorStop(1, "rgba(0,0,0,1)");
    ctx.fillStyle = fade;
    ctx.fillRect(IMAGE_W - 120, 0, 120, HEIGHT);
  } catch (err) {
    // Fallback flat panel if the avatar somehow fails to load (e.g.
    // network hiccup fetching from Discord's CDN) -- card still renders.
    ctx.fillStyle = "#2a2a2a";
    ctx.fillRect(0, 0, IMAGE_W, HEIGHT);
    console.error("[Quote] Failed to load avatar, using fallback panel:", err.message);
  }

  // --- Quote text (right panel) ---
  const textAreaX = IMAGE_W;
  const textAreaW = WIDTH - IMAGE_W;
  const textCenterX = textAreaX + textAreaW / 2;
  const maxWidth = textAreaW - 110; // safe margin inside the black panel, clear of the photo edge/fade and the right canvas edge

  ctx.textAlign = "center";
  ctx.textBaseline = "alphabetic";
  ctx.fillStyle = "#f2f2f2";

  const quoted = `${(text || "(no text)").replace(/^"|"$/g, "")}`;
  const { lines, fontSize, lineHeight } = fitQuoteText(ctx, quoted, maxWidth, QUOTE_AVAILABLE_HEIGHT);
  ctx.font = `italic ${fontSize}px Roboto, sans-serif`;

  // Centered on the card, same as the original layout -- blockHeight is
  // still bounded by QUOTE_AVAILABLE_HEIGHT whenever fitQuoteText didn't
  // have to truncate, so even the longest quote that fits leaves enough
  // room below for the name/handle/watermark.
  const blockHeight = lines.length * lineHeight;
  const startY = HEIGHT / 2 - blockHeight / 2 - 20;

  lines.forEach((line, i) => ctx.fillText(line, textCenterX, startY + i * lineHeight));

  // --- Author name + handle, directly under the quote ---
  // Clamped so a near-max-length quote (large blockHeight) can't push this
  // down far enough to collide with the watermark at the bottom -- without
  // this, the handle line and the watermark end up on top of each other.
  const nameY = Math.min(startY + blockHeight + 50, HEIGHT - 120);
  ctx.font = "italic 500 28px Roboto, sans-serif";
  ctx.fillStyle = "#ffffff";
  ctx.fillText(`- ${authorName}`, textCenterX, nameY);

  if (authorHandle) {
    ctx.font = "20px Roboto, sans-serif";
    ctx.fillStyle = "#9a9a9a";
    ctx.fillText(`@${authorHandle}`, textCenterX, nameY + 34);
  }

  // --- Watermark, bottom-right ---
  ctx.textAlign = "right";
  ctx.font = "16px Roboto, sans-serif";
  ctx.fillStyle = "rgba(255,255,255,0.35)";
  ctx.fillText(WATERMARK, WIDTH - 30, HEIGHT - 30);

  return canvas.toBuffer("image/png");
}

module.exports = {
  data: new ContextMenuCommandBuilder()
    .setName("Quote")
    .setType(ApplicationCommandType.Message),

  async execute(interaction) {
    await interaction.deferReply();

    const message = interaction.targetMessage;
    if (!message) return interaction.editReply("Couldn't find that message.");
    if (!message.content?.trim() && !message.author)
      return interaction.editReply("That message has no text to quote.");

    // The real sender's real avatar -- not the person who ran the command.
    const avatarUrl = message.author.displayAvatarURL({ extension: "png", size: 512 });

    const buffer = await renderQuoteCard({
      text:         message.content || "(no text — attachment/embed only)",
      authorName:   message.member?.displayName || message.author.username,
      authorHandle: message.author.username,
      avatarUrl,
    });

    const attachment = new AttachmentBuilder(buffer, { name: "quote.png" });
    await interaction.editReply({ files: [attachment] });
  },
};

module.exports.renderQuoteCard = renderQuoteCard;