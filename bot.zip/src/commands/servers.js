"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { isOwner } = require("../utils/owners");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("servers")
    .setDescription("[Owner only] List every server the bot is currently in"),

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const guilds = [...client.guilds.cache.values()]
      .sort((a, b) => b.memberCount - a.memberCount);

    const shown = guilds.slice(0, 25);
    const lines = shown.map(g => `**${g.name}** — \`${g.id}\` — ${g.memberCount.toLocaleString()} members`);

    const embed = new EmbedBuilder()
      .setTitle(`Servers (${guilds.length})`)
      .setDescription(lines.join("\n") || "Not in any servers.");

    if (guilds.length > shown.length) {
      embed.setFooter({ text: `Showing top ${shown.length} of ${guilds.length} by member count. Use /msgto's autocomplete to search the rest.` });
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
