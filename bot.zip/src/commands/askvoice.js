"use strict";

const { SlashCommandBuilder } = require("discord.js");
const { startSession, getSession, isSessionActive, speakOnce } = require("../utils/voiceSession");
const { getVoiceConflict } = require("../utils/voiceConflict");
const { askGroq } = require("../utils/groq");
const { synthesizeSpeech } = require("../utils/tts");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("askvoice")
    .setDescription("Ask a question out loud and get a spoken answer")
    .addStringOption(o =>
      o.setName("question")
        .setDescription("Type your question here instead of speaking it")
    ),

  async execute(interaction) {
    const guildId  = interaction.guildId;
    const question = interaction.options.getString("question");

    // A continuous /ttsvoice session is already listening to everyone in the
    // channel, including this person -- nothing new to set up. A typed
    // question can still be answered directly through that same connection.
    if (isSessionActive(guildId)) {
      if (!question) {
        return interaction.reply({ content: "I'm already listening in this server's voice channel — just talk!", ephemeral: true });
      }
      await interaction.deferReply({ ephemeral: true });
      const session = getSession(guildId);
      const action = await askGroq({ prompt: question });
      const speechPcm = await synthesizeSpeech(action.messages.map(m => m.text).join(" "));
      if (speechPcm) await session.speak(speechPcm);
      return interaction.editReply("🔊 Answered.");
    }

    const conflict = getVoiceConflict(interaction.client, guildId);
    if (conflict) return interaction.reply({ content: conflict, ephemeral: true });

    const voiceChannel = interaction.member.voice?.channel;
    if (!voiceChannel) {
      return interaction.reply({ content: "You need to be in a voice channel first.", ephemeral: true });
    }

    const perms = voiceChannel.permissionsFor(interaction.guild.members.me);
    if (!perms.has("Connect") || !perms.has("Speak")) {
      return interaction.reply({ content: "I need Connect and Speak permissions in that channel.", ephemeral: true });
    }

    await interaction.deferReply();

    // Typed question -- join just long enough to speak the answer, then leave.
    if (question) {
      try {
        const action = await askGroq({ prompt: question });
        const speechPcm = await synthesizeSpeech(action.messages.map(m => m.text).join(" "));
        if (speechPcm) await speakOnce({ voiceChannel, pcmBuffer: speechPcm });
      } catch (err) {
        return interaction.editReply(`Something went wrong: ${err.message}`);
      }
      return interaction.editReply(`🔊 Answered your question in **${voiceChannel.name}**.`);
    }

    // No typed question -- join, listen for this one person's next utterance, answer, then leave.
    try {
      await startSession({
        voiceChannel,
        textChannel: interaction.channel,
        onlyListenTo: [interaction.user.id],
        autoStopAfterReply: true,
        getReply: async transcript => {
          const action = await askGroq({ prompt: transcript });
          return action.messages.map(m => m.text).join(" ");
        },
      });
    } catch (err) {
      return interaction.editReply(`Couldn't join voice: ${err.message}`);
    }

    await interaction.editReply(`🎙️ Joined **${voiceChannel.name}** — go ahead and ask your question out loud!`);
  },
};