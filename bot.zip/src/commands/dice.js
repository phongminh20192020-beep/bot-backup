"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

function rollOne(sides) {
  return Math.floor(Math.random() * sides) + 1;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("dice")
    .setDescription("Roll some dice")
    .addIntegerOption(o =>
      o.setName("sides")
        .setDescription("Number of sides per die (default 6)")
        .setMinValue(2)
        .setMaxValue(1000)
    )
    .addIntegerOption(o =>
      o.setName("count")
        .setDescription("How many dice to roll (default 1)")
        .setMinValue(1)
        .setMaxValue(20)
    ),

  async execute(interaction) {
    const sides = interaction.options.getInteger("sides") ?? 6;
    const count = interaction.options.getInteger("count") ?? 1;

    const rolls = Array.from({ length: count }, () => rollOne(sides));
    const total = rolls.reduce((a, b) => a + b, 0);

    const embed = new EmbedBuilder()
      .setTitle(`🎲 Rolling ${count}d${sides}`)
      .setDescription(rolls.map(r => `\`${r}\``).join("  "));

    if (count > 1) embed.addFields({ name: "Total", value: `**${total}**` });

    await interaction.reply({ embeds: [embed] });
  },
};
