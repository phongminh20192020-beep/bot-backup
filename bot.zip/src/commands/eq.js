"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ComponentType,
} = require("discord.js");
const { EQ_BANDS, EQ_MIN_GAIN, EQ_MAX_GAIN, EQ_PRESETS, clampGain } = require("../utils/eq");

const PRESET_CHOICES = Object.entries(EQ_PRESETS).map(([value, { label }]) => ({ name: label, value }));

/**
 * Renders a straight left-to-right bar: how many segments are filled is
 * just the gain's position on the EQ_MIN_GAIN..EQ_MAX_GAIN scale, always
 * starting from the same left edge. (Previously this centered around zero
 * and filled outward in either direction, which made bars for values near
 * the edges of the range look "full" and values near zero look empty in a
 * way that didn't line up row to row -- this is just one consistent ruler.)
 */
function gainBar(gain, width = 6) {
  const FILLED = "<:EqFilled:1541666081175769140>";
  const BLANK  = "<:EqBlank:1541666083063336961>";

  const segments = width + 1;
  const filledCount = Math.min(
    segments,
    Math.max(0, Math.round(((gain - EQ_MIN_GAIN) / (EQ_MAX_GAIN - EQ_MIN_GAIN)) * segments))
  );
  return FILLED.repeat(filledCount) + BLANK.repeat(segments - filledCount);
}

function buildEqEmbed(equalizerBands) {
  const gains = EQ_BANDS.map((b) => equalizerBands?.[b.band]?.gain ?? 0);
  const lines = EQ_BANDS.map((b, i) => {
    const gain = gains[i];
    // Every row gets exactly one sign emoji (zero defaults to the plus one)
    // so every row's prefix is still the same width before the bar --
    // dropping to bold text means no more guaranteed monospace, so this is
    // what keeps the bars lined up now instead of the old padStart trick.
    const signEmoji = gain < 0 ? "<:MinusEQ:1542028196067807332>" : "<:PlusEQ:1542028193106493510>";
    const gainText  = `**${Math.abs(gain).toFixed(2)}**`;
    return `\`${String(b.band).padStart(2)} ${b.freq.padEnd(8)}\` ${signEmoji}${gainText} ${gainBar(gain)}`;
  });

  return new EmbedBuilder()
    .setTitle("<:MusicNote:1537804149012299786> 15-Band Equalizer")
    .setDescription(lines.join("\n"))
    .setFooter({ text: `Gain range: ${EQ_MIN_GAIN.toFixed(2)} to +${EQ_MAX_GAIN.toFixed(2)} · 0 = flat` });
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("eq")
    .setDescription("Fine-tune the 15-band equalizer, Spotify-style")
    .addSubcommand((sub) => sub.setName("set").setDescription("Pick a band and enter its gain interactively"))
    .addSubcommand((sub) => sub.setName("view").setDescription("Show the current EQ curve"))
    .addSubcommand((sub) => sub.setName("reset").setDescription("Reset the EQ to flat"))
    .addSubcommand((sub) =>
      sub
        .setName("preset")
        .setDescription("Apply a ready-made EQ curve")
        .addStringOption((o) => o.setName("name").setDescription("Preset").setRequired(true).addChoices(...PRESET_CHOICES))
    ),

  async execute(interaction, client) {
    await interaction.deferReply();

    const player = client.lavalink.getPlayer(interaction.guildId);
    if (!player) return interaction.editReply("No active player.");

    const fm = player.filterManager;
    const sub = interaction.options.getSubcommand();

    try {
      if (sub === "set") {
        const selectRow = () =>
          new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("eq_band_select")
              .setPlaceholder("Choose a band to adjust…")
              .addOptions(
                EQ_BANDS.map((b) => ({
                  label: `${b.freq} — ${b.short}`,
                  description: b.label.length > 100 ? b.label.slice(0, 100) : b.label,
                  value: String(b.band),
                }))
              )
          );

        const panelMsg = await interaction.editReply({
          embeds: [buildEqEmbed(fm.equalizerBands)],
          components: [selectRow()],
        });

        const collector = panelMsg.createMessageComponentCollector({
          componentType: ComponentType.StringSelect,
          time: 180_000, // 3 min — generous since each pick involves opening/filling a modal
          filter: (sel) => sel.user.id === interaction.user.id,
        });

        collector.on("collect", async (sel) => {
          const band = Number(sel.values[0]);
          const meta = EQ_BANDS[band];
          const currentGain = fm.equalizerBands?.[band]?.gain ?? 0;
          const modalId = `eq_modal_${band}_${Date.now()}`;

          const modal = new ModalBuilder()
            .setCustomId(modalId)
            .setTitle(`Set ${meta.freq} gain`)
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId("gain")
                  .setLabel(`${meta.short} level (${EQ_MIN_GAIN}-${EQ_MAX_GAIN})`)
                  .setStyle(TextInputStyle.Short)
                  .setValue(currentGain.toFixed(2))
                  .setPlaceholder(`e.g. 0.25 (range ${EQ_MIN_GAIN} to ${EQ_MAX_GAIN})`)
                  .setRequired(true)
                  .setMaxLength(6)
              )
            );

          try {
            await sel.showModal(modal);
            const submitted = await sel.awaitModalSubmit({
              time: 60_000,
              filter: (m) => m.customId === modalId && m.user.id === interaction.user.id,
            });

            const raw = submitted.fields.getTextInputValue("gain").trim();
            const parsed = parseFloat(raw);
            if (Number.isNaN(parsed)) {
              await submitted.reply({ content: `<:Fail:1537804179777650778> "${raw}" isn't a valid number.`, ephemeral: true });
              return;
            }

            const gain = clampGain(parsed);
            await fm.setEQ({ band, gain });
            const sign = gain > 0 ? "+" : "";
            const clampedNote = gain !== parsed ? ` (clamped from ${parsed})` : "";

            await submitted.reply({
              content: `<:Success:1537804182206160936> **${meta.freq} (${meta.short})** set to **${sign}${gain.toFixed(2)}**${clampedNote}.`,
              ephemeral: true,
            });
            await interaction.editReply({ embeds: [buildEqEmbed(fm.equalizerBands)], components: [selectRow()] });
          } catch {
            // Modal timed out or was dismissed — nothing to do, panel stays as-is.
          }
        });

        collector.on("end", () => {
          interaction.editReply({ components: [] }).catch(() => {});
        });

        return;
      }

      if (sub === "reset") {
        await fm.clearEQ();
        return interaction.editReply({
          content: "<:Success:1537804182206160936> Equalizer reset to **flat**.",
          embeds: [buildEqEmbed(fm.equalizerBands)],
        });
      }

      if (sub === "preset") {
        const name = interaction.options.getString("name");
        const preset = EQ_PRESETS[name];
        if (!preset) return interaction.editReply("<:Fail:1537804179777650778> Unknown preset.");

        const bands = preset.gains.map((gain, band) => ({ band, gain: clampGain(gain) }));
        await fm.setEQ(bands);
        return interaction.editReply({
          content: `<:Success:1537804182206160936> Applied preset **${preset.label}**.`,
          embeds: [buildEqEmbed(fm.equalizerBands)],
        });
      }

      // view
      return interaction.editReply({ embeds: [buildEqEmbed(fm.equalizerBands)] });
    } catch (err) {
      console.error("[EQ] filterManager error:", err.message);
      return interaction.editReply(`<:Fail:1537804179777650778> Failed to update equalizer: ${err.message}`);
    }
  },
};