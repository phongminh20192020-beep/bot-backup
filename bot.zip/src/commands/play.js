"use strict";

const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, ComponentType } = require("discord.js");
const { formatDuration, resolveSpotify, pickBestTrackMatch } = require("../utils/helpers");
const { loadQueue, deleteQueue }         = require("../utils/queueStore");
const { leaveAfkChannel, isInAfkVoice }  = require("../utils/afkVoice");
const { autocompleteSearch, diagnoseBadResponse, isNonJsonError } = require("../utils/safeSearch");
const { buildControlRow } = require("../utils/musicPanel");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("play")
    .setDescription("Search or play a track, YouTube URL, or Spotify link")
    .addStringOption(o =>
      o.setName("query").setDescription("Song name, YouTube URL, or Spotify URL").setRequired(true).setAutocomplete(true)
    ),

  // Live search-as-you-type suggestions. Selecting one submits its `value`
  // (the track's own URL) as the final query string -- execute() already
  // treats a URL query as a direct URL load (isUrl check below), so picking
  // a suggestion plays exactly that track instead of re-searching the title
  // as text and possibly landing on a different upload/result.
  async autocomplete(interaction, client) {
    return autocompleteSearch(client, interaction, "play");
  },

  async execute(interaction, client) {
    await interaction.deferReply();

    const voiceChannel = interaction.member.voice?.channel;
    if (!voiceChannel)
      return interaction.editReply("You must be in a voice channel.");

    const perms = voiceChannel.permissionsFor(interaction.guild.members.me);
    if (!perms.has("Connect") || !perms.has("Speak"))
      return interaction.editReply("I need permission to join and speak in your channel.");

    // AFK mode uses a raw @discordjs/voice connection with no Lavalink
    // player involved -- leave that first so it doesn't fight with Lavalink
    // over the same voice session.
    if (isInAfkVoice(interaction.guildId)) leaveAfkChannel(interaction.guildId);

    let player  = client.lavalink.getPlayer(interaction.guildId);
    const isNew = !player;

    if (!player) {
      player = client.lavalink.createPlayer({
        guildId:        interaction.guildId,
        voiceChannelId: voiceChannel.id,
        textChannelId:  interaction.channelId,
        selfDeaf:       true,
        selfMute:       false,
      });
    }

    if (!player.connected) {
      await player.connect();
      if (isNew) await new Promise(r => setTimeout(r, 1000));
    }

    if (isNew) {
      const saved = loadQueue(interaction.guildId);
      if (saved) {
        const totalTracks = (saved.current ? 1 : 0) + saved.tracks.length;
        const savedDate   = new Date(saved.savedAt).toLocaleString();

        const yesBtn = new ButtonBuilder().setCustomId("restore_yes").setLabel("Restore").setEmoji({ id: "1537804182206160936", name: "Success" }).setStyle(ButtonStyle.Secondary);
        const noBtn  = new ButtonBuilder().setCustomId("restore_no").setLabel("Start Fresh").setEmoji({ id: "1537804179777650778", name: "Fail" }).setStyle(ButtonStyle.Secondary);
        const row    = new ActionRowBuilder().addComponents(yesBtn, noBtn);

        const prompt = await interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setTitle("<:MusicNote:1537804149012299786> Restore Previous Queue?")
              .setDescription(
                `Found a saved queue from **${savedDate}**.\n` +
                `**${totalTracks}** track${totalTracks !== 1 ? "s" : ""} — starting with **${saved.current?.info?.title || saved.tracks[0]?.info?.title || "Unknown"}**`
              )
              .setFooter({ text: "This prompt expires in 30 seconds." }),
          ],
          components: [row],
        });

        try {
          const btn = await prompt.awaitMessageComponent({
            componentType: ComponentType.Button,
            filter: b => b.user.id === interaction.user.id,
            time:   30_000,
          });

          await btn.deferUpdate();

          if (btn.customId === "restore_yes") {
            // Restore volume + repeat mode
            if (saved.volume    !== undefined) await player.setVolume(saved.volume).catch(() => {});
            if (saved.repeatMode !== undefined) await player.setRepeatMode(saved.repeatMode).catch(() => {});

            // Add current track first, then the rest
            const allTracks = [
              ...(saved.current ? [saved.current] : []),
              ...saved.tracks,
            ];
            for (const t of allTracks) player.queue.add(t);

            deleteQueue(interaction.guildId);
            await player.play().catch(err => console.error("[Restore] play() error:", err.message));

            await interaction.editReply({
              embeds: [
                new EmbedBuilder()
                  .setTitle("<:Success:1537804182206160936> Queue Restored")
                  .setDescription(`Restored **${allTracks.length}** track${allTracks.length !== 1 ? "s" : ""}. Enjoy! <:MusicNote:1537804149012299786>`),
              ],
              components: [buildControlRow(player)],
            });
            return;
          }

          // User chose Start Fresh — delete saved queue and fall through to normal /play
          deleteQueue(interaction.guildId);
          await interaction.editReply({ embeds: [], components: [], content: "Starting fresh! Loading your track..." });

        } catch {
          // Timed out — delete and fall through
          deleteQueue(interaction.guildId);
          await interaction.editReply({ embeds: [], components: [], content: "Restore prompt expired — starting fresh." });
        }
      }
    }

    const query      = interaction.options.getString("query");
    const isSpotify  = /spotify\.com\/(track|playlist|album)\//.test(query);
    const isUrl      = /^https?:\/\//.test(query);

    // ── Detect if the node has LavaSrc (Spotify native support) ──────────────
    const nodeInfo  = player.node?.info;
    const hasLavaSrc = nodeInfo?.plugins?.some(p =>
      p.name?.toLowerCase().includes("lavasrc") ||
      p.name?.toLowerCase().includes("spotify")
    ) ?? false;

    // ── Spotify ───────────────────────────────────────────────────────────────
    if (isSpotify) {

      // ── Node has LavaSrc — pass URL directly, let the node handle everything
      if (hasLavaSrc) {
        const res = await player
          .search({ query, source: "spsearch" }, interaction.user)
          .catch(err => { console.error("[Play] LavaSrc search error:", err.message); return null; });

        if (!res || res.loadType === "empty" || res.loadType === "error")
          return interaction.editReply("<:Fail:1537804179777650778> No results found for that Spotify link.");

        if (res.loadType === "playlist") {
          for (const track of res.tracks) player.queue.add(track);

          if (!player.playing && !player.paused)
            await player.play().catch(err => console.error("[Play] play() error:", err.message));

          return interaction.editReply({
            embeds: [
              new EmbedBuilder()
                .setTitle("Spotify Playlist Added")
                .setDescription(`Added **${res.tracks.length}** tracks from **${res.playlist?.name || "playlist"}** to the queue.`),
            ],
            components: [buildControlRow(player)],
          });
        }

        // Single track via LavaSrc
        const track = res.tracks[0];
        player.queue.add(track);

        if (!player.playing && !player.paused)
          await player.play().catch(err => console.error("[Play] play() error:", err.message));

        return interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setTitle("Added to Queue (Spotify)")
              .setDescription(`**[${track.info.title}](${track.info.uri})**`)
              .addFields(
                { name: "Author",   value: track.info.author || "Unknown",                                             inline: true },
                { name: "Duration", value: track.info.isStream ? "<:Live:1537804170961096714> LIVE" : formatDuration(track.info.duration),     inline: true }
              )
              .setThumbnail(
                track.info.artworkUrl?.trim() ||
                (track.info.identifier ? `https://img.youtube.com/vi/${track.info.identifier}/mqdefault.jpg` : null)
              ),
          ],
          components: [buildControlRow(player)],
        });
      }

      // ── No LavaSrc — resolve via our sidecar service and search YouTube ────
      if (!process.env.SPOTIFY_SERVICE_URL)
        return interaction.editReply("<:Fail:1537804179777650778> Spotify service is not configured. Set `SPOTIFY_SERVICE_URL` (and `SERVICE_API_KEY` if the service requires it).");

      let spotifyData;
      try {
        spotifyData = await resolveSpotify(query);
      } catch (err) {
        console.error("[Play] Spotify resolve error:", err.message);
        if (err.unsupported)
          return interaction.editReply("<:Fail:1537804179777650778> Only Spotify tracks and albums are supported right now — not playlists.");
        return interaction.editReply("<:Fail:1537804179777650778> Failed to fetch Spotify data. Try again later.");
      }

      if (!spotifyData?.tracks?.length)
        return interaction.editReply("<:Fail:1537804179777650778> No tracks found in that Spotify link.");

      // Single track
      if (spotifyData.type === "track") {
        const { query: ytQuery, title, artist, duration } = spotifyData.tracks[0];
        const res = await player
          .search({ query: ytQuery, source: "ytmsearch" }, interaction.user)
          .catch(() => null);

        if (!res?.tracks?.length)
          return interaction.editReply(`<:Fail:1537804179777650778> Couldn't find **${title}** on YouTube Music.`);

        const track = pickBestTrackMatch(res.tracks, duration);
        player.queue.add(track);

        if (!player.playing && !player.paused)
          await player.play().catch(err => console.error("[Play] play() error:", err.message));

        return interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setTitle("Added to Queue (via Spotify)")
              .setDescription(`**[${track.info.title}](${track.info.uri})**`)
              .addFields(
                { name: "Author",   value: track.info.author || artist || "Unknown",                               inline: true },
                { name: "Duration", value: track.info.isStream ? "<:Live:1537804170961096714> LIVE" : formatDuration(track.info.duration), inline: true }
              )
              .setThumbnail(
                track.info.artworkUrl?.trim() ||
                (track.info.identifier ? `https://img.youtube.com/vi/${track.info.identifier}/mqdefault.jpg` : null)
              ),
          ],
          components: [buildControlRow(player)],
        });
      }

      // Playlist / album — background queue
      const { name, tracks } = spotifyData;

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle("<:Sandclock:1537804160211361874> Loading Spotify Playlist...")
            .setDescription(`Found **${tracks.length}** tracks in **${name}**.\nSearching and queuing — playback starts as soon as the first track is ready.`),
        ],
      });

      (async () => {
        let added = 0;
        for (const { query: ytQuery, title, duration } of tracks) {
          try {
            const res = await player.search({ query: ytQuery, source: "ytsearch" }, interaction.user);
            const match = pickBestTrackMatch(res?.tracks, duration);
            if (match) {
              player.queue.add(match);
              added++;
              if (added === 1 && !player.playing && !player.paused)
                await player.play().catch(err => console.error("[Play] initial play() error:", err.message));
            }
          } catch (err) {
            console.warn(`[Play] Skipped "${title}":`, err.message);
          }
        }

        console.log(`[Play] Spotify playlist "${name}": queued ${added}/${tracks.length}`);

        interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setTitle("<:Success:1537804182206160936> Playlist Queued")
              .setDescription(`Added **${added}/${tracks.length}** tracks from **${name}** to the queue.`),
          ],
          components: [buildControlRow(player)],
        }).catch(() => {});
      })();

      return;
    }

    // ── Normal search / URL ───────────────────────────────────────────────────
    const res = await player
      .search(isUrl ? { query } : { query, source: "ytmsearch" }, interaction.user)
      .catch(err => {
        console.error("[Play] search error:", err.message);
        if (isNonJsonError(err)) diagnoseBadResponse(player.node, query, "ytmsearch").catch(() => {});
        return null;
      });

    if (!res || res.loadType === "empty" || res.loadType === "error")
      return interaction.editReply(`<:Fail:1537804179777650778> No results found for \`${query}\`.`);

    if (res.loadType === "playlist") {
      for (const track of res.tracks) player.queue.add(track);

      if (!player.playing && !player.paused)
        await player.play().catch(err => console.error("[Play] play() error:", err.message));

      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle("Playlist Added")
            .setDescription(`Added **${res.tracks.length}** tracks from **${res.playlist?.name || "playlist"}** to the queue.`),
        ],
        components: [buildControlRow(player)],
      });
    }

    // Single track
    const track = res.tracks[0];
    player.queue.add(track);

    if (!player.playing && !player.paused)
      await player.play().catch(err => console.error("[Play] play() error:", err.message));

    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setTitle("Added to Queue")
          .setDescription(`**[${track.info.title}](${track.info.uri})**`)
          .addFields(
            { name: "Author",   value: track.info.author || "Unknown",                                             inline: true },
            { name: "Duration", value: track.info.isStream ? "<:Live:1537804170961096714> LIVE" : formatDuration(track.info.duration),     inline: true }
          )
          .setThumbnail(
                track.info.artworkUrl?.trim() ||
                (track.info.identifier ? `https://img.youtube.com/vi/${track.info.identifier}/mqdefault.jpg` : null)
              ),
      ],
      components: [buildControlRow(player)],
    });
  },
};