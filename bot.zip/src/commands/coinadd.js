"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { isOwner } = require("../utils/owners");
const { addCoins } = require("../utils/economy");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("coinadd")
    .setDescription("[Owner only] Add coins to a user's balance")
    .addUserOption(o =>
      o.setName("user")
        .setDescription("Who to give coins to")
        .setRequired(true)
    )
    .addIntegerOption(o =>
      o.setName("amount")
        .setDescription("How many coins to add")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1_000_000_000)
    ),

  async execute(interaction) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const target    = interaction.options.getUser("user", true);
    const amount    = interaction.options.getInteger("amount", true);
    const newBalance = addCoins(target.id, amount);

    const embed = new EmbedBuilder()
      .setTitle("💰 Coins added")
      .setDescription(
        `Gave **${amount.toLocaleString()}** coins to ${target}.\n` +
        `Their new balance: **${newBalance.toLocaleString()}** coins.`
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
