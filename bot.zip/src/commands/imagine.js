"use strict";

const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { generateImage } = require("../utils/imagegen");

// Per-user cooldown: userId -> timestamp (ms) when they can use /imagine again.
// In-memory, so it resets on restart like the rest of the bot's state.
const COOLDOWN_MS = 30_000;
const cooldowns = new Map();

// Global lock: only one generation at a time across the whole bot. `current`
// is { userId, since } while someone is generating. If a generation hangs
// and never releases, the lock is treated as stale after LOCK_TIMEOUT_MS so
// /imagine can't get stuck "busy" forever.
const LOCK_TIMEOUT_MS = 2 * 60_000;
let current = null;

const SIZE_CHOICES = [
  { name: "Square (1:1)", value: "1:1" },
  { name: "Portrait (3:4)", value: "3:4" },
  { name: "Landscape (4:3)", value: "4:3" },
  { name: "Widescreen (16:9)", value: "16:9" },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName("imagine")
    .setDescription("Generate an image from a text prompt")
    .addStringOption(opt =>
      opt
        .setName("prompt")
        .setDescription("Describe what you want to see")
        .setRequired(true)
        .setMaxLength(500)
    )
    .addStringOption(opt =>
      opt
        .setName("size")
        .setDescription("Image shape (default: square)")
        .addChoices(...SIZE_CHOICES)
    ),

  async execute(interaction) {
    const prompt      = interaction.options.getString("prompt", true);
    const aspectRatio = interaction.options.getString("size") || "1:1";

    // 1) Someone else is mid-generation -- make them wait for it to finish.
    //    Checked before the cooldown so this doesn't start (or cost) a cooldown.
    if (current && Date.now() - current.since > LOCK_TIMEOUT_MS) current = null; // stale
    if (current) {
      return interaction.reply({
        content: current.userId === interaction.user.id
          ? "⏳ Your image is still generating — wait for it to finish first."
          : `⏳ <@${current.userId}> is generating an image right now — wait for it to finish, then run /imagine again.`,
        ephemeral: true,
      });
    }

    // 2) Per-user cooldown.
    const now = Date.now();
    const readyAt = cooldowns.get(interaction.user.id) || 0;
    if (now < readyAt) {
      return interaction.reply({
        content: `⏳ Slow down — you can use /imagine again <t:${Math.ceil(readyAt / 1000)}:R>.`,
        ephemeral: true,
      });
    }

    // Take the lock + start the cooldown as soon as generation starts (not
    // when it finishes) so requests can't be stacked to dodge either one.
    const myLock = { userId: interaction.user.id, since: now };
    current = myLock;
    cooldowns.set(interaction.user.id, now + COOLDOWN_MS);
    setTimeout(() => {
      if ((cooldowns.get(interaction.user.id) || 0) <= Date.now()) cooldowns.delete(interaction.user.id);
    }, COOLDOWN_MS + 1000).unref();

    let result;
    try {
      await interaction.deferReply();
      result = await generateImage(prompt, { aspectRatio });
    } catch (err) {
      cooldowns.delete(interaction.user.id); // failed/blocked -- don't make them wait
      if (
        err.message === "BLOCKED_PROMPT" ||
        err.message.startsWith("BLOCKED_BY_MODERATION") ||
        err.message.startsWith("BLOCKED_BY_API")
      ) {
        return interaction.editReply("Can't generate that one — try a different prompt.");
      }
      console.error("[Imagine] Failed:", err.message);
      return interaction.editReply("Couldn't reach the image generator right now — try again in a moment.");
    } finally {
      // Free the slot the moment generation is done (only if it's still ours --
      // a stale-lock takeover shouldn't get released by the old run).
      if (current === myLock) current = null;
    }

    const ext  = result.contentType.includes("png") ? "png" : "jpg";
    const file = new AttachmentBuilder(result.buffer, { name: `imagine.${ext}` });

    const embed = new EmbedBuilder()
      .setTitle("🎨 Imagined")
      .setDescription(prompt.slice(0, 1024))
      .setImage(`attachment://imagine.${ext}`)
      .setFooter({ text: `Requested by ${interaction.user.username}` });

    await interaction.editReply({ embeds: [embed], files: [file] });
  },
};