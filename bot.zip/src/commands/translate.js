"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { translateText } = require("../utils/googleTranslate");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("translate")
    .setDescription("Translate text to English — the source language is auto-detected")
    .addStringOption(opt =>
      opt
        .setName("text")
        .setDescription("The text to translate")
        .setRequired(true)
        .setMaxLength(1000)
    ),

  async execute(interaction) {
    const text = interaction.options.getString("text", true);
    await interaction.deferReply();

    let result;
    try {
      result = await translateText(text);
    } catch (err) {
      console.error("[Translate] Failed:", err.message);
      return interaction.editReply("Couldn't reach the translation service right now — try again in a moment.");
    }

    const embed = new EmbedBuilder()
      .setTitle("🌐 Translation")
      .addFields(
        { name: `Original (${result.detected_language})`, value: text.slice(0, 1024) },
        { name: "English", value: result.translation.slice(0, 1024) },
      );

    await interaction.editReply({ embeds: [embed] });
  },
};