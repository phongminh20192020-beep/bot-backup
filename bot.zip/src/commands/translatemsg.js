"use strict";

const { ContextMenuCommandBuilder, ApplicationCommandType, EmbedBuilder } = require("discord.js");
const { translateText } = require("../utils/googleTranslate");

// Message > Apps > Translate -- same translation engine as the /translate
// slash command, just triggered by right-clicking an existing message
// instead of retyping its text into a slash command option.
module.exports = {
  data: new ContextMenuCommandBuilder()
    .setName("Translate")
    .setType(ApplicationCommandType.Message),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const message = interaction.targetMessage;
    const text = message?.content?.trim();

    if (!text) {
      return interaction.editReply("That message doesn't have any text to translate (attachment/embed only?).");
    }

    let result;
    try {
      result = await translateText(text);
    } catch (err) {
      console.error("[Translate] Failed:", err.message);
      return interaction.editReply("Couldn't reach the translation service right now — try again in a moment.");
    }

    const embed = new EmbedBuilder()
      .setTitle("🌐 Translation")
      .addFields(
        { name: `Original (${result.detected_language})`, value: text.slice(0, 1024) },
        { name: "English", value: result.translation.slice(0, 1024) },
      )
      .setFooter({ text: `Message by ${message.author?.username ?? "unknown"}` });

    await interaction.editReply({ embeds: [embed] });
  },
};
