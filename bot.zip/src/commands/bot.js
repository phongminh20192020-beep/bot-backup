"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { isOwner } = require("../utils/owners");
const { snapshotActiveSessions } = require("../utils/sessionRecovery");

// NOTE on "stop": the host is configured with an auto-restart policy
// (Dockerfile/docker-compose `restart: unless-stopped`, or the platform's
// own crash-detection restart if hosted elsewhere -- see the watchdog
// comment in index.js). That policy restarts the container on ANY process
// exit unless someone runs `docker stop`/`docker-compose stop` (or the
// platform equivalent) from outside the bot -- which the bot has no way to
// trigger on itself. So `type:stop` can't guarantee the bot stays down; it
// just exits cleanly and is upfront with the owner that it'll likely come
// back up on its own unless the host-level restart policy is turned off.
module.exports = {
  data: new SlashCommandBuilder()
    .setName("bot")
    .setDescription("[Owner only] Restart or stop the bot process")
    .addStringOption(o =>
      o.setName("type")
        .setDescription("What to do")
        .setRequired(true)
        .addChoices(
          { name: "restart", value: "restart" },
          { name: "stop",    value: "stop" },
        )
    ),

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const type = interaction.options.getString("type", true);

    const embed = new EmbedBuilder()
      .setTitle(type === "restart" ? "🔄 Restarting" : "🛑 Stopping")
      .setDescription(
        type === "restart"
          ? "Snapshotting any active sessions and restarting now. I'll be back in a few seconds."
          : "Snapshotting any active sessions and shutting down.\n" +
            "-# Heads up: this host auto-restarts the bot process, so I may come back online shortly unless that's disabled outside of me."
      );

    // Reply BEFORE exiting -- await it so the response actually reaches
    // Discord before the process goes away.
    await interaction.reply({ embeds: [embed] });

    console.log(`[Bot] /bot type:${type} run by ${interaction.user.tag} (${interaction.user.id}).`);
    snapshotActiveSessions(client, `Bot ${type} via /bot command (by ${interaction.user.tag})`);

    // Give the reply a moment to fully flush before tearing the process down.
    setTimeout(() => process.exit(0), 250);
  },
};
