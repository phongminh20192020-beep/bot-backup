"use strict";

const { SlashCommandBuilder } = require("discord.js");
const coder = require("../utils/coder");

// /code -- the coding AI. Describe what you want (and optionally attach files
// to change), and the finished work comes back as file attachments instead of
// a wall of chat text: one file as-is, a few files side by side, or a
// project.zip when there are folders / lots of files.
//
// The AI itself lives in utils/coder.js (GLM-5.3 via NVIDIA, key in
// .env as NVIDIA_API_KEY). Typing "write me ..." / "noname write me ..." in
// chat runs the same coder (see handleWriteMe in index.js), and both share the
// same cooldown / concurrency limits.

module.exports = {
  data: new SlashCommandBuilder()
    .setName("code")
    .setDescription("Have the coding AI write or change code — you get the result as file(s)")
    .addStringOption(o =>
      o.setName("prompt")
        .setDescription("What should it build or change?")
        .setRequired(true)
        .setMaxLength(4000)
    )
    .addAttachmentOption(o =>
      o.setName("file")
        .setDescription("A code/text file for it to read or modify")
    )
    .addAttachmentOption(o =>
      o.setName("file2")
        .setDescription("A second file")
    )
    .addAttachmentOption(o =>
      o.setName("file3")
        .setDescription("A third file")
    ),

  async execute(interaction) {
    if (!coder.isConfigured()) {
      return interaction.reply({
        content: "The coding AI isn't set up yet — the bot owner needs to add `NVIDIA_API_KEY` to the `.env` file.",
        ephemeral: true,
      });
    }

    // Cooldown / concurrency check happens BEFORE deferring so a refusal can
    // be a private (ephemeral) message instead of a public one.
    let release;
    try {
      release = coder.beginRun(interaction.user.id);
    } catch (err) {
      if (err instanceof coder.CoderUserError) {
        return interaction.reply({ content: `⏳ ${err.message}`, ephemeral: true });
      }
      throw err;
    }

    let ticker = null;
    try {
      await interaction.deferReply();

      const prompt = interaction.options.getString("prompt", true);
      const attachments = ["file", "file2", "file3"]
        .map(n => interaction.options.getAttachment(n))
        .filter(Boolean)
        .map(a => ({ name: a.name, url: a.url, size: a.size, contentType: a.contentType }));

      const { files: inputFiles, skipped } = await coder.fetchTextAttachments(attachments);

      // Live status line: current step + elapsed seconds, refreshed every few seconds
      // so a slow model never looks frozen (cosmetic; edit errors are ignored).
      ticker = coder.startProgressDisplay(text => {
        interaction.editReply({ content: text, allowedMentions: { parse: [] } }).catch(() => {});
      });
      const onProgress = ticker.update;

      const result = await coder.runCoder({ task: prompt, inputFiles, onProgress, memoryKey: `${interaction.channelId}:${interaction.user.id}` });
      ticker.stop(); // stop before the final edit so a late tick can't overwrite the answer

      const notes = [];
      if (skipped) notes.push(`_${skipped} attachment${skipped > 1 ? "s were" : " was"} skipped (not readable text, or too big)._`);

      const header = result.files.length
        ? `📎 **${result.files.map(f => f.name).join(", ")}**`
        : "";
      const footer = coder.formatUsage(result);
      const body = [header, result.summary, ...notes].filter(Boolean).join("\n\n");
      const content = footer ? `${body.slice(0, 2000 - footer.length - 2)}\n\n${footer}` : body.slice(0, 2000);

      try {
        await interaction.editReply({
          content,
          files: result.files.map(f => ({ attachment: f.buffer, name: f.name })),
          allowedMentions: { parse: [] }, // model text must never be able to ping @everyone
        });
      } catch (err) {
        // Usually a missing "Attach Files" permission or an oversized upload.
        console.error("[Code] Couldn't attach the result:", err.message);
        await interaction.editReply({
          content: "❌ I made the files but couldn't upload them here — check that I have the **Attach Files** permission in this channel.",
          allowedMentions: { parse: [] },
        });
      }
    } catch (err) {
      console.error("[Code] Failed:", err.message);
      const msg = err instanceof coder.CoderUserError
        ? err.message
        : "Couldn't reach the coding AI right now — try again in a moment.";
      await interaction.editReply({ content: `❌ ${msg}`, allowedMentions: { parse: [] } }).catch(() => {});
    } finally {
      ticker?.stop();
      release();
    }
  },
};