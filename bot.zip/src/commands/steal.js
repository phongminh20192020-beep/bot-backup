"use strict";

const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");

// Matches a custom emoji as Discord renders it in a message: <:name:id> or
// the animated form <a:name:id>.
const CUSTOM_EMOJI_REGEX = /<(a)?:(\w{2,32}):(\d{17,20})>/;

module.exports = {
  data: new SlashCommandBuilder()
    .setName("steal")
    .setDescription("Steal a custom emoji from another server and add it to this one")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageEmojisAndStickers)
    .addStringOption(o =>
      o.setName("emoji")
        .setDescription("Paste the custom emoji itself, e.g. <:name:123456789012345678>")
        .setRequired(true)
    )
    .addStringOption(o =>
      o.setName("name")
        .setDescription("Custom name for the new emoji (defaults to the original name)")
        .setRequired(false)
    ),

  async execute(interaction, client) {
    await interaction.deferReply();

    if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageEmojisAndStickers))
      return interaction.editReply("<:Fail:1537804179777650778> I need the **Manage Expressions** permission in this server to add emojis.");

    const raw = interaction.options.getString("emoji", true).trim();
    const match = raw.match(CUSTOM_EMOJI_REGEX);
    if (!match)
      return interaction.editReply(
        "<:Fail:1537804179777650778> That doesn't look like a custom emoji. Paste the emoji itself (e.g. `<:name:123456789012345678>`) — not a link, a name, or a default Discord emoji."
      );

    const [, animatedFlag, sourceName, id] = match;
    const animated = Boolean(animatedFlag);
    const url = `https://cdn.discordapp.com/emojis/${id}.${animated ? "gif" : "png"}`;

    let name = (interaction.options.getString("name") || sourceName)
      .replace(/[^a-zA-Z0-9_]/g, "_")
      .slice(0, 32);
    if (name.length < 2) name = `emoji_${id.slice(-6)}`;

    try {
      const created = await interaction.guild.emojis.create({ attachment: url, name, reason: `Stolen by ${interaction.user.tag}` });

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle("<:Success:1537804182206160936> Emoji Stolen")
            .setDescription(`Added ${created.toString()} as \`:${created.name}:\``)
            .setThumbnail(url),
        ],
      });
    } catch (err) {
      console.error("[Steal] emoji create error:", err.message);

      if (err.code === 30008)
        return interaction.editReply("<:Fail:1537804179777650778> This server is out of emoji slots (static and animated slots are tracked separately).");
      if (err.code === 50035)
        return interaction.editReply("<:Fail:1537804179777650778> Invalid emoji name — use 2–32 letters, numbers, or underscores.");

      return interaction.editReply(`<:Fail:1537804179777650778> Failed to add that emoji: ${err.message}`);
    }
  },
};
