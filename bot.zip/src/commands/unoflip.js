"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const {
  flipStartGame,
  flipPlayCard,
  flipDrawOnTurn,
  flipChooseBotMove,
  flipCanPlayFace,
  flipCanPlayWildDraw,
  flipPlayableIndices,
  flipCardLabel,
  flipColorsFor,
  face,
} = require("../utils/unoVariants");
const { advanceTurn } = require("../utils/unoEngine");
const { renderHandImage, renderTableImage } = require("../utils/unoRender");

const DEFAULT_WAIT_SEC = 20;
const TURN_TIMEOUT_MS  = 90_000;
const sleep = ms => new Promise(r => setTimeout(r, ms));

const RULES_TEXT =
  "**UNO Flip — house rules**\n" +
  "• Every card has a light side and a dark side. The whole table plays the same side at once.\n" +
  "• 🔆 Light side: Skip, Reverse, Draw One — like classic UNO.\n" +
  "• 🌑 Dark side: **Skip Everyone** (all other players lose their turn), Reverse, **Draw Five** — much harsher.\n" +
  "• 🔄 **Flip** cards exist on both sides — playing one flips the deck, discard pile and every hand to the other side for the rest of the game.\n" +
  "• Wild Draw Two (light) becomes **Wild Draw Color** (dark): the victim draws one card at a time until they draw the chosen color.";

// A duo {light, dark} card only exposes color/type/value once resolved to
// the table's active side, so the shared uno renderer (which expects flat
// cards) needs a resolved view of the hand and discard pile.
function resolvedHand(hand, side) { return hand.map(c => face(c, side)); }
function resolvedState(state) {
  return { ...state, discard: state.discard.map(c => face(c, state.side)) };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unoflip")
    .setDescription("Start a game of UNO Flip — two-sided cards, light & dark rules")
    .addIntegerOption(o =>
      o.setName("size")
        .setDescription("Total number of seats at the table")
        .setRequired(true)
        .addChoices(
          { name: "2 players", value: 2 },
          { name: "3 players", value: 3 },
          { name: "4 players", value: 4 }
        )
    )
    .addIntegerOption(o =>
      o.setName("wait")
        .setDescription(`Seconds to wait for others to join (default ${DEFAULT_WAIT_SEC})`)
        .setMinValue(10)
        .setMaxValue(60)
    ),

  async execute(interaction) {
    const size    = interaction.options.getInteger("size", true);
    const waitSec = interaction.options.getInteger("wait") ?? DEFAULT_WAIT_SEC;

    const seats = [{ id: interaction.user.id, user: interaction.user, isBot: false }];
    let started = false;
    let state   = null;
    let gameCollector = null;

    const renderLobbyEmbed = () =>
      new EmbedBuilder()
        .setTitle("🔄 UNO Flip Table — Open")
        .setDescription(
          `${seats.map(s => `• ${s.user.username}`).join("\n")}\n\n` +
          `Seats: **${seats.length}/${size}**\n` +
          `Starts in **${waitSec}s** (or when the host clicks Start Now). Empty seats fill with bots.\n\n${RULES_TEXT}`
        );

    const renderLobbyRow = () =>
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("unoflip_join").setLabel("Join").setStyle(ButtonStyle.Success).setDisabled(seats.length >= size),
        new ButtonBuilder().setCustomId("unoflip_start").setLabel("Start Now").setStyle(ButtonStyle.Primary)
      );

    const msg = await interaction.reply({ embeds: [renderLobbyEmbed()], components: [renderLobbyRow()], fetchReply: true });

    const refreshPublicTable = async logLine => {
      const current = state.players[state.turnIndex];
      const unoFlag = current.hand.length === 1 ? `\n🔥 **${current.username} has UNO!**` : "";
      const sideFlag = `\n${state.side === "light" ? "🔆 Light side" : "🌑 Dark side"} is active.`;
      const embed = new EmbedBuilder()
        .setTitle("🔄 UNO Flip Table")
        .setDescription(`${logLine ? logLine + "\n\n" : ""}It's **${current.username}**'s turn.${unoFlag}${sideFlag}`)
        .setImage("attachment://table.png");
      const attachment = new AttachmentBuilder(renderTableImage(resolvedState(state)), { name: "table.png" });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("unoflip_hand").setLabel("🖐️ My Hand").setStyle(ButtonStyle.Primary)
      );
      await msg.edit({ embeds: [embed], files: [attachment], components: [row] }).catch(() => {});
    };

    const announceWinner = async winner => {
      const attachment = new AttachmentBuilder(renderTableImage(resolvedState(state)), { name: "table.png" });
      const embed = new EmbedBuilder()
        .setTitle("🎉 UNO Flip — Game Over!")
        .setDescription(`**${winner.username}** wins the game!`)
        .setImage("attachment://table.png");
      await msg.edit({ embeds: [embed], files: [attachment], components: [] }).catch(() => {});
      gameCollector?.stop("finished");
    };

    const pickBotColor = (bot, cardIdx) => {
      const palette = flipColorsFor(state.side);
      const counts = Object.fromEntries(palette.map(c => [c, 0]));
      bot.hand.forEach((c, i) => { const cf = face(c, state.side); if (i !== cardIdx && cf.color !== "wild") counts[cf.color]++; });
      const best = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
      return best[1] > 0 ? best[0] : palette[Math.floor(Math.random() * palette.length)];
    };

    const runBotLoop = async () => {
      while (!state.winnerId && state.players[state.turnIndex].isBot) {
        await sleep(1200);
        const botIdx = state.turnIndex;
        const bot    = state.players[botIdx];
        const move   = flipChooseBotMove(state, botIdx);

        if (move.action === "draw") {
          const drawn = flipDrawOnTurn(state, botIdx);
          if (drawn) {
            const cardIdx = bot.hand.length - 1;
            const topFace = face(state.discard[state.discard.length - 1], state.side);
            const df = face(drawn, state.side);
            const playable = flipCanPlayFace(df, state.currentColor, topFace) &&
              !((df.type === "wilddraw2" || df.type === "wilddrawcolor") && !flipCanPlayWildDraw(bot.hand, cardIdx, state.currentColor, state.side));
            if (playable) {
              const chosenColor = df.color === "wild" ? pickBotColor(bot, cardIdx) : null;
              const beforeSide = state.side;
              const result = flipPlayCard(state, botIdx, cardIdx, chosenColor);
              await refreshPublicTable(`${bot.username} drew and played **${flipCardLabel(drawn, beforeSide)}**${chosenColor ? ` (chose ${chosenColor})` : ""}.${result.effect === "flip" ? `\n🔄 Flipped to **${state.side.toUpperCase()}**!` : ""}`);
              if (result.effect === "win") return announceWinner(bot);
              continue;
            }
          }
          advanceTurn(state);
          await refreshPublicTable(`${bot.username} drew a card.`);
          continue;
        }

        const card = bot.hand[move.cardIdx];
        const beforeSide = state.side;
        const result = flipPlayCard(state, botIdx, move.cardIdx, move.chosenColor);
        let line = `${bot.username} played **${flipCardLabel(card, beforeSide)}**${move.chosenColor ? ` (chose ${move.chosenColor})` : ""}.`;
        if (result.effect === "flip") line += `\n🔄 Flipped to **${state.side.toUpperCase()}**!`;
        if (result.effect === "skipall") line += "\n⛔ Everyone else is skipped!";
        if (["draw1", "draw5", "wilddraw2", "wilddrawcolor"].includes(result.effect)) {
          const victim = state.players.find(p => p.id === result.drawnBy);
          line += `\n${victim.username} drew ${result.drawnCount} card(s) and was skipped.`;
        }
        await refreshPublicTable(line);
        if (result.effect === "win") return announceWinner(bot);
      }
    };

    const afterHumanMove = async (player, result, lineExtra) => {
      if (result.effect === "win") return announceWinner(player);
      await refreshPublicTable(lineExtra || `${player.username} played a card.`);
      await runBotLoop();
    };

    const handleHandButton = async btn => {
      const player = state.players.find(p => p.id === btn.user.id && !p.isBot);
      if (!player) return btn.reply({ content: "You're not seated at this table.", ephemeral: true });

      const idx = state.players.findIndex(p => p.id === player.id);
      const isMyTurn = state.turnIndex === idx;
      const handAttachment = () => new AttachmentBuilder(renderHandImage(resolvedHand(player.hand, state.side)), { name: "hand.png" });

      if (!isMyTurn) {
        return btn.reply({
          content: `Your hand (${state.side} side) — waiting for **${state.players[state.turnIndex].username}**'s turn.`,
          files: [handAttachment()],
          ephemeral: true,
        });
      }

      const buildTurnUI = () => {
        const legal = flipPlayableIndices(player.hand, state);
        const options = player.hand.slice(0, 24).map((c, i) => ({
          label: flipCardLabel(c, state.side).slice(0, 100),
          value: String(i),
          description: legal.includes(i) ? "Playable" : "Not playable right now",
        }));
        options.push({ label: "Draw a card", value: "draw", description: "Draw from the deck" });
        const menu = new StringSelectMenuBuilder()
          .setCustomId("unoflip_action")
          .setPlaceholder("Choose a card to play, or draw")
          .addOptions(options.slice(0, 25));
        return [new ActionRowBuilder().addComponents(menu)];
      };

      const colorRow = cardIdx =>
        new ActionRowBuilder().addComponents(
          flipColorsFor(state.side).map(c =>
            new ButtonBuilder()
              .setCustomId(`unoflip_color_${c}_${cardIdx}`)
              .setLabel(c[0].toUpperCase() + c.slice(1))
              .setStyle(ButtonStyle.Secondary)
          )
        );

      const ephemeral = await btn.reply({
        content: `It's your turn! (${state.side === "light" ? "🔆 Light" : "🌑 Dark"} side) Pick a card to play, or draw.`,
        files: [handAttachment()],
        components: buildTurnUI(),
        ephemeral: true,
        fetchReply: true,
      });

      let resolved = false;
      const turnCollector = ephemeral.createMessageComponentCollector({ time: TURN_TIMEOUT_MS });

      const doPlay = async (i, cardIdx, chosenColor, card) => {
        const beforeSide = state.side;
        const result = flipPlayCard(state, idx, cardIdx, chosenColor);
        resolved = true;
        turnCollector.stop("done");
        let line = `You played **${flipCardLabel(card, beforeSide)}**${chosenColor ? ` (chose ${chosenColor})` : ""}.`;
        await i.update({ content: line, files: [], components: [] });
        let extra = `${player.username} played **${flipCardLabel(card, beforeSide)}**${chosenColor ? ` (chose ${chosenColor})` : ""}.`;
        if (result.effect === "flip") extra += `\n🔄 The table flipped to the **${state.side.toUpperCase()}** side!`;
        if (result.effect === "skipall") extra += "\n⛔ Everyone else is skipped — you'd go again if it were still your turn to act.";
        if (["draw1", "draw5", "wilddraw2", "wilddrawcolor"].includes(result.effect)) {
          const victim = state.players.find(p => p.id === result.drawnBy);
          extra += `\n${victim.username} drew ${result.drawnCount} card(s) and was skipped.`;
        }
        return afterHumanMove(player, result, extra);
      };

      turnCollector.on("collect", async i => {
        if (i.user.id !== player.id) return i.reply({ content: "This isn't your turn.", ephemeral: true });

        if (i.isStringSelectMenu() && i.customId === "unoflip_action") {
          const value = i.values[0];

          if (value === "draw") {
            const drawn = flipDrawOnTurn(state, idx);
            if (!drawn) {
              resolved = true;
              turnCollector.stop("done");
              await i.update({ content: "The deck is empty — turn passed.", files: [], components: [] });
              advanceTurn(state);
              await refreshPublicTable(`${player.username} tried to draw, but the deck is empty.`);
              return runBotLoop();
            }

            const drawnIdx = player.hand.length - 1;
            const topFace = face(state.discard[state.discard.length - 1], state.side);
            const df = face(drawn, state.side);
            const playable = flipCanPlayFace(df, state.currentColor, topFace) &&
              !((df.type === "wilddraw2" || df.type === "wilddrawcolor") && !flipCanPlayWildDraw(player.hand, drawnIdx, state.currentColor, state.side));

            if (!playable) {
              resolved = true;
              turnCollector.stop("done");
              await i.update({ content: `You drew **${flipCardLabel(drawn, state.side)}** — no valid play, turn passed.`, files: [], components: [] });
              advanceTurn(state);
              await refreshPublicTable(`${player.username} drew a card.`);
              return runBotLoop();
            }

            const yesNo = new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId("unoflip_playdrawn_yes").setLabel(`Play ${flipCardLabel(drawn, state.side)}`).setStyle(ButtonStyle.Success),
              new ButtonBuilder().setCustomId("unoflip_playdrawn_no").setLabel("Keep it, pass turn").setStyle(ButtonStyle.Secondary)
            );
            return i.update({ content: `You drew **${flipCardLabel(drawn, state.side)}** — play it now or keep it?`, files: [], components: [yesNo] });
          }

          const cardIdx = parseInt(value, 10);
          const card = player.hand[cardIdx];
          if (!card) return i.reply({ content: "That card isn't there anymore.", ephemeral: true });
          const cf = face(card, state.side);

          if (cf.color === "wild") {
            return i.update({ content: `Playing **${flipCardLabel(card, state.side)}** — choose a color:`, files: [], components: [colorRow(cardIdx)] });
          }

          try {
            return await doPlay(i, cardIdx, undefined, card);
          } catch (err) {
            return i.reply({ content: err.message, ephemeral: true });
          }
        }

        if (i.isButton() && i.customId === "unoflip_playdrawn_yes") {
          const drawnIdx = player.hand.length - 1;
          const drawnCard = player.hand[drawnIdx];
          const cf = face(drawnCard, state.side);
          if (cf.color === "wild") {
            return i.update({ content: `Playing **${flipCardLabel(drawnCard, state.side)}** — choose a color:`, components: [colorRow(drawnIdx)] });
          }
          return doPlay(i, drawnIdx, undefined, drawnCard);
        }

        if (i.isButton() && i.customId === "unoflip_playdrawn_no") {
          resolved = true;
          turnCollector.stop("done");
          advanceTurn(state);
          await i.update({ content: "Kept the card — turn passed.", components: [] });
          await refreshPublicTable(`${player.username} drew and kept a card.`);
          return runBotLoop();
        }

        if (i.isButton() && i.customId.startsWith("unoflip_color_")) {
          const [, , color, idxStr] = i.customId.split("_");
          const cardIdx = parseInt(idxStr, 10);
          const card = player.hand[cardIdx];
          try {
            return await doPlay(i, cardIdx, color, card);
          } catch (err) {
            return i.update({ content: err.message, components: [] });
          }
        }
      });

      turnCollector.on("end", async (_c, reason) => {
        if (resolved || reason !== "time") return;
        const drawn = flipDrawOnTurn(state, idx);
        advanceTurn(state);
        await ephemeral.edit({
          content: drawn
            ? `⌛ Timed out — drew **${flipCardLabel(drawn, state.side)}** and passed your turn.`
            : "⌛ Timed out — turn passed.",
          files: [], components: [],
        }).catch(() => {});
        await refreshPublicTable(`${player.username} took too long and their turn was passed.`);
        await runBotLoop();
      });
    };

    const beginGame = async () => {
      if (started) return;
      started = true;
      lobbyCollector.stop("start");

      let botCount = 0;
      while (seats.length < size) {
        botCount++;
        seats.push({ id: `bot_${botCount}`, user: null, isBot: true, username: `Bot ${botCount}` });
      }

      const playerInfos = seats.map(s => ({ id: s.id, isBot: s.isBot, username: s.isBot ? s.username : s.user.username }));
      state = flipStartGame(playerInfos);

      for (const s of seats) {
        if (s.isBot) continue;
        const hand = state.players.find(p => p.id === s.id).hand;
        const attachment = new AttachmentBuilder(renderHandImage(resolvedHand(hand, state.side)), { name: "hand.png" });
        try {
          await s.user.send({
            content: `🔄 Your UNO Flip hand for the game in **${interaction.guild?.name ?? "this server"}**! Use the table message's "My Hand" button any time for an updated view and to take your turn.`,
            files: [attachment],
          });
        } catch {
          await msg.channel.send({
            content: `${s.user} — I couldn't DM you your hand (check that DMs from server members are allowed). You can still play using the "🖐️ My Hand" button on the table below.`,
          }).catch(() => {});
        }
      }

      await refreshPublicTable("Game started! Cards have been dealt. Starting on the 🔆 Light side.");

      gameCollector = msg.createMessageComponentCollector({
        componentType: ComponentType.Button,
        filter: i => i.customId === "unoflip_hand",
      });
      gameCollector.on("collect", handleHandButton);

      await runBotLoop();
    };

    const lobbyCollector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      filter: i => i.customId === "unoflip_join" || i.customId === "unoflip_start",
    });

    lobbyCollector.on("collect", async btn => {
      if (started) return;

      if (btn.customId === "unoflip_start") {
        if (btn.user.id !== interaction.user.id) {
          return btn.reply({ content: "Only the host can start early.", ephemeral: true });
        }
        await btn.deferUpdate();
        return beginGame();
      }

      if (btn.user.bot) return btn.reply({ content: "Bots fill empty seats automatically — no need to add one.", ephemeral: true });
      if (seats.find(s => s.id === btn.user.id)) return btn.reply({ content: "You're already seated.", ephemeral: true });
      if (seats.length >= size) return btn.reply({ content: "This table is full.", ephemeral: true });

      seats.push({ id: btn.user.id, user: btn.user, isBot: false });
      await btn.update({ embeds: [renderLobbyEmbed()], components: [renderLobbyRow()] });
      if (seats.length === size) await beginGame();
    });

    setTimeout(() => { if (!started) beginGame(); }, waitSec * 1000);
  },
};
