"use strict";

const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { getBalance, addCoins, removeCoins } = require("../utils/economy");
const { renderWheel } = require("../utils/wheelRender");

const IMAGE_NAME = "wheel.png";

// 20 segments total. EV per bet choice (exact, since these are simple
// fractions of a known segment count):
//   red/black: 9/20 * 2x  = 0.90
//   green:     1/20 * 9x  = 0.45
//   gold:      1/20 * 18x = 0.90
// Green pays a smaller share back because hitting it happens as rarely as
// gold but pays half as much -- same "safe vs. long-shot" spread you'd see
// on a real wheel, not a mistake.
const SEGMENTS = [
  ...Array(9).fill({ color: "red",   hex: "#e0503f", payout: 2 }),
  ...Array(9).fill({ color: "black", hex: "#2b2d31", payout: 2 }),
  { color: "green", hex: "#4caf50", payout: 9 },
  { color: "gold",  hex: "#e6b800", payout: 18 },
];

// Shuffle once per require so red/black/green/gold aren't grouped together
// on the rendered wheel.
const ORDERED_SEGMENTS = (() => {
  const arr = [...SEGMENTS];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
})();

module.exports = {
  data: new SlashCommandBuilder()
    .setName("wheel")
    .setDescription("Bet on a color and spin the wheel, wagering coins")
    .addStringOption(o =>
      o.setName("color")
        .setDescription("Which color to bet on")
        .setRequired(true)
        .addChoices(
          { name: "Red (2x, 9/20 slots)",    value: "red" },
          { name: "Black (2x, 9/20 slots)",  value: "black" },
          { name: "Green (9x, 1/20 slots)",  value: "green" },
          { name: "Gold (18x, 1/20 slots)",  value: "gold" },
        )
    )
    .addIntegerOption(o =>
      o.setName("bet")
        .setDescription("How many coins to wager")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1_000_000)
    ),

  async execute(interaction) {
    const choice  = interaction.options.getString("color", true);
    const bet     = interaction.options.getInteger("bet", true);
    const balance = getBalance(interaction.user.id);

    if (balance < bet) {
      return interaction.reply({
        content: `You don't have enough coins for that bet — your balance is **${balance.toLocaleString()}** coins.`,
        ephemeral: true,
      });
    }

    removeCoins(interaction.user.id, bet);

    const landingIndex = Math.floor(Math.random() * ORDERED_SEGMENTS.length);
    const landing = ORDERED_SEGMENTS[landingIndex];
    const won = landing.color === choice;
    const multiplier = won ? landing.payout : 0;

    const winnings = Math.floor(bet * multiplier);
    if (winnings > 0) addCoins(interaction.user.id, winnings);
    const newBalance = getBalance(interaction.user.id);

    const image = renderWheel({ segments: ORDERED_SEGMENTS, landingIndex });
    const attachment = new AttachmentBuilder(image, { name: IMAGE_NAME });

    const status = won
      ? `Landed on **${landing.color.toUpperCase()}**! You win **${winnings.toLocaleString()}** coins (${multiplier}x). Balance: **${newBalance.toLocaleString()}**.`
      : `Landed on **${landing.color.toUpperCase()}**. You lose your **${bet.toLocaleString()}** coin bet. Balance: **${newBalance.toLocaleString()}**.`;

    const embed = new EmbedBuilder()
      .setTitle("🎡 Wheel Spin")
      .setDescription(`You bet on **${choice.toUpperCase()}**.\n\n${status}`)
      .setImage(`attachment://${IMAGE_NAME}`)
      .setFooter({ text: `Bet: ${bet.toLocaleString()} coins` });

    await interaction.reply({ embeds: [embed], files: [attachment] });
  },
};
