"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { isOwner } = require("../utils/owners");
const { getInboxChannelId } = require("../utils/inboxStore");

/** Best-effort copy of an outgoing attachment reply into the inbox channel. Never throws. */
async function logToInbox(client, { sentBy, target, message, attachments }) {
  const channelId = getInboxChannelId();
  if (!channelId) return;
  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased?.()) return;

  const embed = new EmbedBuilder()
    .setAuthor({ name: `📎 Attachment reply to ${target.tag} (${target.id})`, iconURL: target.displayAvatarURL() })
    .setDescription(message || "*(no message text)*")
    .setFooter({ text: `Sent by ${sentBy.tag}` })
    .setTimestamp();

  const firstImage = attachments.find(a => a.contentType?.startsWith("image/"));
  if (firstImage) embed.setImage(firstImage.url);
  embed.addFields({
    name: `Attachment${attachments.length > 1 ? "s" : ""}`,
    value: attachments.map(a => `[${a.name}](${a.url})`).join("\n").slice(0, 1024),
  });

  await channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("attachmentsend")
    .setDescription("[Owner only] Reply to a person with one or more attachments")
    .addUserOption(o =>
      o.setName("user")
        .setDescription("Who to send to")
        .setRequired(true)
    )
    .addAttachmentOption(o =>
      o.setName("attachment")
        .setDescription("The file to send")
        .setRequired(true)
    )
    .addStringOption(o =>
      o.setName("message")
        .setDescription("Optional message to send alongside it")
        .setMaxLength(2000)
    )
    .addAttachmentOption(o =>
      o.setName("attachment2")
        .setDescription("A second file to send")
    )
    .addAttachmentOption(o =>
      o.setName("attachment3")
        .setDescription("A third file to send")
    ),

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const target  = interaction.options.getUser("user", true);
    const message = interaction.options.getString("message");
    const attachments = ["attachment", "attachment2", "attachment3"]
      .map(name => interaction.options.getAttachment(name))
      .filter(Boolean);

    if (target.bot) {
      return interaction.reply({ content: "Can't send to another bot.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      await target.send({
        content: message || undefined,
        files: attachments.map(a => ({ attachment: a.url, name: a.name })),
      });
    } catch (err) {
      return interaction.editReply({
        content: `❌ Couldn't reach ${target.tag} — they may have DMs closed, or blocked the bot. (${err.message})`,
      });
    }

    await logToInbox(client, { sentBy: interaction.user, target, message, attachments });

    await interaction.editReply({
      content: `✅ Sent ${attachments.length} attachment${attachments.length > 1 ? "s" : ""} to **${target.tag}**.`,
    });
  },
};
