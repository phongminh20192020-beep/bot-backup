"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const { renderTicTacToeImage } = require("../utils/tictactoeRender");

const WIN_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // cols
  [0, 4, 8], [2, 4, 6],            // diagonals
];

const IMAGE_NAME = "tictactoe.png";

function checkWinner(board) {
  for (const [a, b, c] of WIN_LINES) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return board.every(cell => cell) ? "draw" : null;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("tictactoe")
    .setDescription("Play tic-tac-toe against another member")
    .addUserOption(o =>
      o.setName("opponent")
        .setDescription("Who do you want to play against?")
        .setRequired(true)
    ),

  async execute(interaction, client) {
    const p1 = interaction.user;
    const p2 = interaction.options.getUser("opponent", true);

    if (p2.id === p1.id)
      return interaction.reply({ content: "You can't play against yourself.", ephemeral: true });
    if (p2.bot)
      return interaction.reply({ content: "You can't play against a bot.", ephemeral: true });

    // Board cells hold plain "X"/"O" (what the canvas renderer draws);
    // "marks" keeps the ❌/⭕ emoji used purely in embed text.
    const board  = Array(9).fill(null);
    const marks  = { [p1.id]: "❌", [p2.id]: "⭕" };
    const letter = { [p1.id]: "X", [p2.id]: "O" };
    let   turnId = p1.id;

    // The board is now a hand-drawn canvas image (see utils/tictactoeRender.js)
    // attached via setImage(); the buttons underneath stay as the actual
    // click targets but no longer carry the mark as their label.
    const buildPayload = (statusText) => {
      const embed = new EmbedBuilder()
        .setTitle("Tic-Tac-Toe")
        .setDescription(`${marks[p1.id]} ${p1} vs ${marks[p2.id]} ${p2}\n\n${statusText}`)
        .setImage(`attachment://${IMAGE_NAME}`);

      const attachment = new AttachmentBuilder(renderTicTacToeImage(board), { name: IMAGE_NAME });
      return { embeds: [embed], files: [attachment] };
    };

    const buildRows = (disabled = false) => {
      const rows = [];
      for (let r = 0; r < 3; r++) {
        const row = new ActionRowBuilder();
        for (let c = 0; c < 3; c++) {
          const i = r * 3 + c;
          row.addComponents(
            new ButtonBuilder()
              .setCustomId(`ttt_${i}`)
              .setLabel("\u200b")
              .setStyle(
                board[i] === "X" ? ButtonStyle.Danger :
                board[i] === "O" ? ButtonStyle.Success :
                ButtonStyle.Secondary
              )
              .setDisabled(disabled || !!board[i])
          );
        }
        rows.push(row);
      }
      return rows;
    };

    const msg = await interaction.reply({
      ...buildPayload(`It's <@${turnId}>'s turn (${marks[turnId]}).`),
      components: buildRows(),
      fetchReply: true,
    });

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time:          5 * 60 * 1000,
    });

    collector.on("collect", async btn => {
      if (btn.user.id !== p1.id && btn.user.id !== p2.id) {
        return btn.reply({ content: "This isn't your game.", ephemeral: true });
      }
      if (btn.user.id !== turnId) {
        return btn.reply({ content: "It's not your turn.", ephemeral: true });
      }

      const index = parseInt(btn.customId.split("_")[1], 10);
      if (board[index]) {
        return btn.reply({ content: "That square is already taken.", ephemeral: true });
      }

      board[index] = letter[turnId];
      const result = checkWinner(board);

      if (result === "draw") {
        collector.stop("draw");
        return btn.update({ ...buildPayload("It's a **draw**! 🤝"), components: buildRows(true) });
      }
      if (result) {
        const winnerId = result === letter[p1.id] ? p1.id : p2.id;
        collector.stop("win");
        return btn.update({
          ...buildPayload(`${marks[winnerId]} <@${winnerId}> wins! 🎉`),
          components: buildRows(true),
        });
      }

      turnId = turnId === p1.id ? p2.id : p1.id;
      await btn.update({
        ...buildPayload(`It's <@${turnId}>'s turn (${marks[turnId]}).`),
        components: buildRows(),
      });
    });

    collector.on("end", (_collected, reason) => {
      if (reason === "draw" || reason === "win") return;
      interaction.editReply({
        ...buildPayload("Game timed out — nobody moved in time."),
        components: buildRows(true),
      }).catch(() => {});
    });
  },
};