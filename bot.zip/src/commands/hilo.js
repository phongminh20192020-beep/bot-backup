"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const { getBalance, addCoins, removeCoins } = require("../utils/economy");
const { renderCard } = require("../utils/hiloRender");

const IMAGE_NAME = "hilo.png";

const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
const RANK_VALUE = Object.fromEntries(RANKS.map((r, i) => [r, i + 2])); // 2..14, Ace high

// Flat multiplier per correct guess. A tie (next card same rank) counts as
// a loss -- keeps the guess a clean binary bet instead of a 3-way split.
// Simulated against the real deck-draw-without-replacement odds: average
// correct-guess probability across a full deck run is ~0.48, so this lands
// around a 9% house edge on the first guess, growing on each chained guess.
const MULTIPLIER_PER_WIN = 1.9;

function freshDeck() {
  const deck = [];
  for (const s of SUITS) for (const r of RANKS) deck.push({ rank: r, suit: s });
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

const fmt = c => `${c.rank}${c.suit}`;

module.exports = {
  data: new SlashCommandBuilder()
    .setName("hilo")
    .setDescription("Guess if the next card is higher or lower, chain wins for a bigger multiplier")
    .addIntegerOption(o =>
      o.setName("bet")
        .setDescription("How many coins to wager")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1_000_000)
    ),

  async execute(interaction) {
    const bet     = interaction.options.getInteger("bet", true);
    const balance = getBalance(interaction.user.id);

    if (balance < bet) {
      return interaction.reply({
        content: `You don't have enough coins for that bet — your balance is **${balance.toLocaleString()}** coins.`,
        ephemeral: true,
      });
    }

    removeCoins(interaction.user.id, bet);

    const deck = freshDeck();
    let current    = deck.pop();
    let multiplier = 1;
    let streak     = 0;

    const buildPayload = (statusText, { disabled = false } = {}) => {
      const image = renderCard(current);
      const attachment = new AttachmentBuilder(image, { name: IMAGE_NAME });
      return {
        embeds: [
          new EmbedBuilder()
            .setTitle("🎴 Hi-Lo")
            .setDescription(`Streak: **${streak}**  •  Multiplier: **${multiplier.toFixed(2)}x**\n\n${statusText}`)
            .setImage(`attachment://${IMAGE_NAME}`)
            .setFooter({ text: `Bet: ${bet.toLocaleString()} coins  •  Cash out value: ${Math.floor(bet * multiplier).toLocaleString()} coins` }),
        ],
        files: [attachment],
        components: [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("hl_higher").setLabel("Higher").setEmoji("⬆️").setStyle(ButtonStyle.Primary).setDisabled(disabled),
            new ButtonBuilder().setCustomId("hl_lower").setLabel("Lower").setEmoji("⬇️").setStyle(ButtonStyle.Primary).setDisabled(disabled),
            new ButtonBuilder().setCustomId("hl_cashout").setLabel("Cash Out").setEmoji("💰").setStyle(ButtonStyle.Success).setDisabled(disabled || streak === 0)
          ),
        ],
      };
    };

    const msg = await interaction.reply({ ...buildPayload("Higher or lower than this card?"), fetchReply: true });

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 3 * 60 * 1000,
    });

    collector.on("collect", async btn => {
      if (btn.user.id !== interaction.user.id) {
        return btn.reply({ content: "This isn't your game.", ephemeral: true });
      }

      if (btn.customId === "hl_cashout") {
        collector.stop("done");
        const winnings = Math.floor(bet * multiplier);
        addCoins(interaction.user.id, winnings);
        const newBalance = getBalance(interaction.user.id);
        return btn.update(buildPayload(
          `Cashed out after **${streak}** correct guess${streak === 1 ? "" : "es"}! You win **${winnings.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true }
        ));
      }

      if (deck.length === 0) {
        // Deck exhausted (would need a very long streak) -- treat as an
        // automatic cash-out rather than leaving the player stuck.
        collector.stop("done");
        const winnings = Math.floor(bet * multiplier);
        addCoins(interaction.user.id, winnings);
        const newBalance = getBalance(interaction.user.id);
        return btn.update(buildPayload(
          `Deck's out of cards! Auto cashed-out at **${multiplier.toFixed(2)}x** for **${winnings.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true }
        ));
      }

      const guessHigher = btn.customId === "hl_higher";
      const next  = deck.pop();
      const won   = guessHigher
        ? RANK_VALUE[next.rank] > RANK_VALUE[current.rank]
        : RANK_VALUE[next.rank] < RANK_VALUE[current.rank];

      const revealLine = `Next card was **${fmt(next)}**.`;
      current = next;

      if (!won) {
        collector.stop("done");
        const newBalance = getBalance(interaction.user.id);
        return btn.update(buildPayload(
          `${revealLine} You lose your **${bet.toLocaleString()}** coin bet. Balance: **${newBalance.toLocaleString()}**.`,
          { disabled: true }
        ));
      }

      streak++;
      multiplier *= MULTIPLIER_PER_WIN;
      await btn.update(buildPayload(`${revealLine} Correct! Higher or lower than this one?`));
    });

    collector.on("end", (_collected, reason) => {
      if (reason === "done") return;
      const refund = streak > 0 ? Math.floor(bet * multiplier) : bet;
      if (refund > 0) addCoins(interaction.user.id, refund);
      const newBalance = getBalance(interaction.user.id);
      interaction.editReply(buildPayload(
        `Timed out — auto cashed-out at **${multiplier.toFixed(2)}x** for **${refund.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`,
        { disabled: true }
      )).catch(() => {});
    });
  },
};
