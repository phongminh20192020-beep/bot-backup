"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const { getRandomWord } = require("../utils/wordnik");
const { renderHangmanImage } = require("../utils/hangmanRender");

const MAX_WRONG = 6;

// Guesses used to be plain chat messages, collected via a message collector.
// That put them in direct conflict with the "noname" AI chat feature -- a
// swiped mobile reply to the game embed, or any message that happened to
// mention the bot, would get intercepted as a chat prompt instead of a
// guess. Routing guesses through a button + modal instead means they never
// touch messageCreate at all, so there's nothing left for "noname" to
// mistake them for.
const GUESS_BUTTON_ID = "hangman_guess";
const GUESS_MODAL_ID  = "hangman_guess_modal";
const GUESS_INPUT_ID  = "letter";
const IMAGE_NAME       = "hangman.png";

function buildGuessRow(disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(GUESS_BUTTON_ID)
      .setLabel("Guess a letter")
      .setStyle(ButtonStyle.Primary)
      .setDisabled(disabled)
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("hangman")
    .setDescription("Play a game of hangman — guess letters via the button"),

  async execute(interaction) {
    await interaction.deferReply();

    const word = await getRandomWord({ minLength: 5, maxLength: 10 });
    if (!word) {
      return interaction.editReply("Couldn't fetch a word from Wordnik right now — try again in a moment.");
    }

    const letters = new Set(word.split(""));
    const guessed = new Set();
    let   wrong   = 0;

    const maskedWord = () =>
      word.split("").map(ch => (guessed.has(ch) ? ch.toUpperCase() : "\\_")).join(" ");

    // The gallows + figure are now a drawn image (see utils/hangmanRender.js)
    // instead of an emoji grid, attached to the embed via setImage().
    const buildPayload = (status = null) => {
      const embed = new EmbedBuilder()
        .setTitle("Hangman")
        .setDescription(
          `**Word:** ${maskedWord()}\n` +
          `**Wrong guesses:** ${wrong}/${MAX_WRONG}\n` +
          `**Guessed letters:** ${[...guessed].join(", ").toUpperCase() || "none yet"}\n\n` +
          `Click **Guess a letter** below to play.`
        )
        .setImage(`attachment://${IMAGE_NAME}`);
      if (status) embed.addFields({ name: "\u200b", value: status });

      const attachment = new AttachmentBuilder(renderHangmanImage(wrong), { name: IMAGE_NAME });
      return { embeds: [embed], files: [attachment] };
    };

    await interaction.editReply({ ...buildPayload(), components: [buildGuessRow()] });

    const message   = await interaction.fetchReply();
    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 5 * 60 * 1000,
    });

    collector.on("collect", async btn => {
      if (btn.customId !== GUESS_BUTTON_ID) return;

      if (btn.user.id !== interaction.user.id) {
        return btn.reply({ content: "This isn't your game — start your own with `/hangman`.", ephemeral: true }).catch(() => {});
      }

      const modal = new ModalBuilder()
        .setCustomId(GUESS_MODAL_ID)
        .setTitle("Guess a letter")
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId(GUESS_INPUT_ID)
              .setLabel("A single letter (A-Z)")
              .setStyle(TextInputStyle.Short)
              .setMinLength(1)
              .setMaxLength(1)
              .setRequired(true)
          )
        );

      await btn.showModal(modal);

      const submitted = await btn
        .awaitModalSubmit({
          time: 60_000,
          filter: mi => mi.customId === GUESS_MODAL_ID && mi.user.id === interaction.user.id,
        })
        .catch(() => null);
      if (!submitted) return; // modal timed out or was dismissed

      const raw = submitted.fields.getTextInputValue(GUESS_INPUT_ID).trim();

      // Strict syntax check: exactly one A-Z letter, nothing else. Reject
      // anything else (numbers, symbols, multiple characters, blank) with
      // an ephemeral notice instead of touching the game state.
      if (!/^[a-zA-Z]$/.test(raw)) {
        return submitted
          .reply({ content: `❌ "${raw}" isn't a single letter — try again with just one A-Z character.`, ephemeral: true })
          .catch(() => {});
      }

      const letter = raw.toLowerCase();

      if (guessed.has(letter)) {
        return submitted
          .reply({ content: `You already guessed **${letter.toUpperCase()}**.`, ephemeral: true })
          .catch(() => {});
      }

      guessed.add(letter);
      if (!letters.has(letter)) wrong++;

      const won  = [...letters].every(l => guessed.has(l));
      const lost = wrong >= MAX_WRONG;

      if (won) {
        collector.stop("won");
        return submitted.update({
          ...buildPayload(`🎉 You got it! The word was **${word.toUpperCase()}**.`),
          components: [buildGuessRow(true)],
        });
      }
      if (lost) {
        collector.stop("lost");
        return submitted.update({
          ...buildPayload(`💀 Out of guesses! The word was **${word.toUpperCase()}**.`),
          components: [buildGuessRow(true)],
        });
      }

      await submitted.update({ ...buildPayload(), components: [buildGuessRow()] });
    });

    collector.on("end", (_collected, reason) => {
      if (reason === "won" || reason === "lost") return;
      interaction.editReply({
        ...buildPayload(`⌛ Game timed out. The word was **${word.toUpperCase()}**.`),
        components: [buildGuessRow(true)],
      }).catch(() => {});
    });
  },
};