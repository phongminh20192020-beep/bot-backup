"use strict";

const { SlashCommandBuilder } = require("discord.js");
const { startSession, stopSession, isSessionActive } = require("../utils/voiceSession");
const { getVoiceConflict } = require("../utils/voiceConflict");
const { askGroq } = require("../utils/groq");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ttsvoice")
    .setDescription("Join your voice channel for a live spoken conversation (run again to stop)"),

  async execute(interaction) {
    const guildId = interaction.guildId;

    if (isSessionActive(guildId)) {
      stopSession(guildId);
      return interaction.reply("left voice!");
    }

    const conflict = getVoiceConflict(interaction.client, guildId);
    if (conflict) return interaction.reply({ content: conflict, ephemeral: true });

    const voiceChannel = interaction.member.voice?.channel;
    if (!voiceChannel) {
      return interaction.reply({ content: "You need to be in a voice channel first.", ephemeral: true });
    }

    const perms = voiceChannel.permissionsFor(interaction.guild.members.me);
    if (!perms.has("Connect") || !perms.has("Speak")) {
      return interaction.reply({ content: "I need Connect and Speak permissions in that channel.", ephemeral: true });
    }

    await interaction.deferReply();

    try {
      await startSession({
        voiceChannel,
        textChannel: interaction.channel,
        getReply: async transcript => {
          const action = await askGroq({ prompt: transcript });
          return action.messages.map(m => m.text).join(" ");
        },
      });
    } catch (err) {
      return interaction.editReply(`Couldn't join voice: ${err.message}`);
    }

    await interaction.editReply(
      `I'm here to talk with u! use fucking /ttsvoice to kick my dirty ass out`
    );
  },
};