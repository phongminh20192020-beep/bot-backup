"use strict";

const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { getBalance, addCoins, removeCoins } = require("../utils/economy");
const { renderPlinkoBoard } = require("../utils/plinkoRender");

const IMAGE_NAME = "plinko.png";
const ROWS = 10;

// Symmetric payout table for 11 slots (10-row board). Checked against the
// board's true binomial landing distribution (fair 50/50 at every peg,
// house edge lives entirely in this table, not in the drop itself):
// EV = 0.994 -- see repo notes for the calculation.
const MULT_TABLE = [15, 5, 2, 1.2, 0.7, 0.5, 0.7, 1.2, 2, 5, 15];

module.exports = {
  data: new SlashCommandBuilder()
    .setName("plinko")
    .setDescription("Drop a chip down the peg board and see where it lands, wagering coins")
    .addIntegerOption(o =>
      o.setName("bet")
        .setDescription("How many coins to wager")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1_000_000)
    ),

  async execute(interaction) {
    const bet     = interaction.options.getInteger("bet", true);
    const balance = getBalance(interaction.user.id);

    if (balance < bet) {
      return interaction.reply({
        content: `You don't have enough coins for that bet — your balance is **${balance.toLocaleString()}** coins.`,
        ephemeral: true,
      });
    }

    removeCoins(interaction.user.id, bet);

    const moves = Array.from({ length: ROWS }, () => (Math.random() < 0.5 ? "L" : "R"));
    const landingSlot = moves.filter(m => m === "R").length;
    const multiplier = MULT_TABLE[landingSlot];

    const winnings = Math.floor(bet * multiplier);
    if (winnings > 0) addCoins(interaction.user.id, winnings);
    const newBalance = getBalance(interaction.user.id);

    const image = renderPlinkoBoard({ moves, multTable: MULT_TABLE, landingSlot });
    const attachment = new AttachmentBuilder(image, { name: IMAGE_NAME });

    const status = multiplier >= 1
      ? `Landed on **${multiplier}x**! You win **${winnings.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`
      : `Landed on **${multiplier}x**. You get back **${winnings.toLocaleString()}** coins. Balance: **${newBalance.toLocaleString()}**.`;

    const embed = new EmbedBuilder()
      .setTitle("🟣 Plinko")
      .setDescription(status)
      .setImage(`attachment://${IMAGE_NAME}`)
      .setFooter({ text: `Bet: ${bet.toLocaleString()} coins` });

    await interaction.reply({ embeds: [embed], files: [attachment] });
  },
};
