"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { setAfk } = require("../utils/afkStore");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("afkuser")
    .setDescription("Mark yourself as AFK")
    .addStringOption(o =>
      o.setName("reason")
        .setDescription("Why you're AFK (shown to anyone who pings you)")
        .setMaxLength(200)
    ),

  async execute(interaction) {
    const reason = interaction.options.getString("reason") ?? "AFK";
    setAfk(interaction.user.id, reason);

    const embed = new EmbedBuilder()
      .setTitle("💤 You're now AFK")
      .setDescription(`I'll let anyone who pings you know — reason: **${reason}**`);

    await interaction.reply({ embeds: [embed] });
  },
};
