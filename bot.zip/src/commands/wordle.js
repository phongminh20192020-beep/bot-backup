"use strict";

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ComponentType,
  AttachmentBuilder,
} = require("discord.js");
const { getRandomWord, isRealWord } = require("../utils/wordnik");
const { renderWordleImage } = require("../utils/wordleRender");

const MAX_GUESSES = 6;
const WORD_LENGTH = 5;
const IMAGE_NAME  = "wordle.png";

/** Standard Wordle scoring, handles duplicate letters correctly. Returns an
 *  array of "green" | "yellow" | "gray" per position (for the canvas board). */
function scoreGuess(guess, answer) {
  const result     = Array(WORD_LENGTH).fill("gray");
  const answerLeft = answer.split("");

  // First pass: exact matches
  for (let i = 0; i < WORD_LENGTH; i++) {
    if (guess[i] === answer[i]) {
      result[i] = "green";
      answerLeft[i] = null;
    }
  }
  // Second pass: right letter, wrong position
  for (let i = 0; i < WORD_LENGTH; i++) {
    if (result[i] === "green") continue;
    const idx = answerLeft.indexOf(guess[i]);
    if (idx !== -1) {
      result[i] = "yellow";
      answerLeft[idx] = null;
    }
  }
  return result;
}

// Guesses used to be plain chat messages picked up by a message collector --
// which put them in direct conflict with the "noname" AI chat feature (a
// swiped mobile reply, or any regular 5-letter *real* word typed in normal
// conversation, could get silently eaten as a guess or accidentally trigger
// the AI). A button + modal removes both problems: guesses never touch
// messageCreate, and the modal submission is validated for exact syntax
// (exactly 5 A-Z letters) before it's even checked against the dictionary.
const GUESS_BUTTON_ID = "wordle_guess";
const GUESS_MODAL_ID  = "wordle_guess_modal";
const GUESS_INPUT_ID  = "word";

function buildGuessRow(disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(GUESS_BUTTON_ID)
      .setLabel("Guess a word")
      .setStyle(ButtonStyle.Primary)
      .setDisabled(disabled)
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("wordle")
    .setDescription("Play Wordle — guess the 5-letter word in 6 tries via the button"),

  async execute(interaction) {
    await interaction.deferReply();

    const answer = await getRandomWord({ minLength: WORD_LENGTH, maxLength: WORD_LENGTH });
    if (!answer || answer.length !== WORD_LENGTH) {
      return interaction.editReply("Couldn't fetch a 5-letter word from Wordnik right now — try again in a moment.");
    }

    const rows = []; // { letters: string, colors: string[] }

    // The guess grid is now a drawn image (see utils/wordleRender.js)
    // instead of emoji-square + backtick-letter rows.
    const buildPayload = (status = null) => {
      const embed = new EmbedBuilder()
        .setTitle("Wordle")
        .setDescription(
          `**Guesses:** ${rows.length}/${MAX_GUESSES}\n\n` +
          `Click **Guess a word** below to play.`
        )
        .setImage(`attachment://${IMAGE_NAME}`);
      if (status) embed.addFields({ name: "\u200b", value: status });

      const attachment = new AttachmentBuilder(
        renderWordleImage(rows, WORD_LENGTH, MAX_GUESSES),
        { name: IMAGE_NAME }
      );
      return { embeds: [embed], files: [attachment] };
    };

    await interaction.editReply({ ...buildPayload(), components: [buildGuessRow()] });

    const message   = await interaction.fetchReply();
    const collector = message.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 10 * 60 * 1000,
    });

    collector.on("collect", async btn => {
      if (btn.customId !== GUESS_BUTTON_ID) return;

      if (btn.user.id !== interaction.user.id) {
        return btn.reply({ content: "This isn't your game — start your own with `/wordle`.", ephemeral: true }).catch(() => {});
      }

      const modal = new ModalBuilder()
        .setCustomId(GUESS_MODAL_ID)
        .setTitle("Guess a word")
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId(GUESS_INPUT_ID)
              .setLabel("A 5-letter word")
              .setStyle(TextInputStyle.Short)
              .setMinLength(WORD_LENGTH)
              .setMaxLength(WORD_LENGTH)
              .setRequired(true)
          )
        );

      await btn.showModal(modal);

      const submitted = await btn
        .awaitModalSubmit({
          time: 60_000,
          filter: mi => mi.customId === GUESS_MODAL_ID && mi.user.id === interaction.user.id,
        })
        .catch(() => null);
      if (!submitted) return; // modal timed out or was dismissed

      const raw = submitted.fields.getTextInputValue(GUESS_INPUT_ID).trim();

      // Strict syntax check FIRST, before spending a dictionary lookup on
      // it: exactly 5 A-Z letters, nothing else (no numbers, spaces,
      // punctuation, emoji, or wrong-length input).
      if (!/^[a-zA-Z]{5}$/.test(raw)) {
        return submitted
          .reply({ content: `❌ "${raw}" isn't a valid guess — enter exactly 5 letters (A-Z), nothing else.`, ephemeral: true })
          .catch(() => {});
      }

      const guess = raw.toLowerCase();

      const valid = await isRealWord(guess);
      if (!valid) {
        return submitted
          .reply({ content: `❌ **${guess.toUpperCase()}** isn't a word I recognize — try another.`, ephemeral: true })
          .catch(() => {});
      }

      rows.push({ letters: guess.toUpperCase(), colors: scoreGuess(guess, answer) });

      const won  = guess === answer;
      const lost = !won && rows.length >= MAX_GUESSES;

      if (won) {
        collector.stop("won");
        return submitted.update({
          ...buildPayload(`🎉 Solved it in **${rows.length}/${MAX_GUESSES}**!`),
          components: [buildGuessRow(true)],
        });
      }
      if (lost) {
        collector.stop("lost");
        return submitted.update({
          ...buildPayload(`💀 Out of guesses! The word was **${answer.toUpperCase()}**.`),
          components: [buildGuessRow(true)],
        });
      }

      await submitted.update({ ...buildPayload(), components: [buildGuessRow()] });
    });

    collector.on("end", (_collected, reason) => {
      if (reason === "won" || reason === "lost") return;
      interaction.editReply({
        ...buildPayload(`⌛ Game timed out. The word was **${answer.toUpperCase()}**.`),
        components: [buildGuessRow(true)],
      }).catch(() => {});
    });
  },
};