"use strict";

const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { isOwner } = require("../utils/owners");
const { getInboxChannelId } = require("../utils/inboxStore");

/** Best-effort copy of a reply into the inbox channel, for a paper trail. Never throws. */
async function logToInbox(client, { sentBy, target, message }) {
  const channelId = getInboxChannelId();
  if (!channelId) return;
  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased?.()) return;

  const embed = new EmbedBuilder()
    .setAuthor({ name: `↩️ Reply to ${target.tag} (${target.id})`, iconURL: target.displayAvatarURL() })
    .setDescription(message)
    .setFooter({ text: `Sent by ${sentBy.tag}` })
    .setTimestamp();

  await channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("reply")
    .setDescription("[Owner only] Reply to a DMer's message")
    .addUserOption(o =>
      o.setName("user")
        .setDescription("Who to reply to")
        .setRequired(true)
    )
    .addStringOption(o =>
      o.setName("message")
        .setDescription("Your reply")
        .setRequired(true)
        .setMaxLength(2000)
    ),

  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ content: "This command is restricted to the bot owner.", ephemeral: true });
    }

    const target  = interaction.options.getUser("user", true);
    const message = interaction.options.getString("message", true);

    if (target.bot) {
      return interaction.reply({ content: "Can't reply to another bot.", ephemeral: true });
    }

    try {
      await target.send({ content: message });
    } catch (err) {
      return interaction.reply({
        content: `❌ Couldn't reach ${target.tag} — they may have DMs closed, or blocked the bot. (${err.message})`,
        ephemeral: true,
      });
    }

    await logToInbox(client, { sentBy: interaction.user, target, message });

    await interaction.reply({ content: `✅ Reply sent to **${target.tag}**.`, ephemeral: true });
  },
};
