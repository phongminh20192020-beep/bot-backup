"use strict";

// Isolated on purpose: this is the one call that actually reaches out to
// Discord's gateway, and keeping it separate from index.js's setup code
// makes it easy to see exactly what happens around login without scrolling
// past command loading, dashboard startup, etc.
async function loginClient(client) {
  const token = process.env.DISCORD_TOKEN;
  if (!token) {
    throw new Error("DISCORD_TOKEN is not set — check the host's environment variables panel, not just a local .env file.");
  }

  console.log("[Login] Attempting to log in to Discord...");
  try {
    await client.login(token);
  } catch (err) {
    // client.login() rejects fast for a genuinely malformed/revoked token
    // (TokenInvalid, 401) -- that's distinct from a silent connect timeout,
    // which the watchdog in index.js handles separately since login()
    // itself won't reject or resolve if the connection just never completes.
    console.error("[Login] client.login() rejected:", err.message);
    throw err;
  }
}

module.exports = { loginClient };
