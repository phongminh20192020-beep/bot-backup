"use strict";

const { resetPresence }       = require("../utils/helpers");
const { printLoginBanner }    = require("../utils/banner");
const { registerCommands }    = require("../utils/registerCommands");

module.exports = {
  name: "clientReady",
  once: true,
  async execute(client) {
    printLoginBanner(client);
    resetPresence(client);
    try {
      const count = await registerCommands(client);
      console.log(`[Commands] Registered ${count} slash commands.`);
    } catch (err) {
      console.error("[Commands] Auto-registration failed:", err.message);
    }
    await client.lavalink.init({ id: client.user.id, username: client.user.username });
    console.log("[Lavalink] Init called — waiting for node connection...");
  },
};