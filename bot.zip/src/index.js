"use strict";

// Load .env if present. Harmless no-op if the host injects env vars directly
// (e.g. via a panel's Variables tab) instead of a .env file -- dotenv just
// won't find anything to load and process.env is left untouched.
require("dotenv").config();

// Prefer IPv4 for outbound DNS lookups. Some hosts (this Alpine-based
// container included) don't have working outbound IPv6 routing, and
// Node's built-in fetch() tries IPv6 first -- causing every outbound
// fetch() call (Last.fm, MusicBrainz, etc.) to fail with a bare
// "fetch failed" instead of falling back to IPv4.
const dns = require("dns");
dns.setDefaultResultOrder("ipv4first");

// ─── DNS resilience ────────────────────────────────────────────────────────────
// The container's OS resolver occasionally can't complete a lookup at all
// (not "host not found" -- the query itself times out / gets no response),
// which surfaces as `getaddrinfo EAI_AGAIN <host>` from *any* outbound call:
// Lavalink node requests, the Discord REST API, Last.fm, etc. Node has no
// built-in retry or fallback resolver for this, so a single blip on the
// host's local DNS took down whatever request happened to be in flight.
//
// Fix: point lookups at reliable public resolvers, and fall back from
// getaddrinfo (dns.lookup) to a direct DNS query (dns.resolve4/6) against
// those same resolvers when the OS resolver fails. Then swap Node's global
// fetch() for undici's fetch (same fetch, same API) using a custom Agent
// that runs every connection's DNS lookup through this fallback -- since
// @discordjs/rest and lavalink-client both end up calling global fetch()
// under the hood, this one change makes every outbound request in the bot
// resilient to a flaky local resolver, not just one call site.
dns.setServers(["1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4"]);

function resilientDnsLookup(hostname, options, callback) {
  if (typeof options === "function") { callback = options; options = {}; }
  dns.lookup(hostname, options, (err, address, family) => {
    if (!err) return callback(null, address, family);
    if (err.code !== "EAI_AGAIN" && err.code !== "ENOTFOUND") return callback(err);

    console.warn(`[DNS] getaddrinfo failed for "${hostname}" (${err.code}) — retrying via 1.1.1.1/8.8.8.8...`);
    // undici's connector may request either a single address (default) or
    // every address for the family (options.all — used for Happy Eyeballs
    // dual-stack connects), so the fallback has to answer in whichever
    // shape was asked for or undici throws ERR_INVALID_IP_ADDRESS.
    dns.resolve4(hostname, (err4, addrs4) => {
      if (!err4 && addrs4?.length) {
        const results = addrs4.map(a => ({ address: a, family: 4 }));
        return options.all ? callback(null, results) : callback(null, results[0].address, 4);
      }
      dns.resolve6(hostname, (err6, addrs6) => {
        if (!err6 && addrs6?.length) {
          const results = addrs6.map(a => ({ address: a, family: 6 }));
          return options.all ? callback(null, results) : callback(null, results[0].address, 6);
        }
        callback(err); // both fallbacks failed too — surface the original error
      });
    });
  });
}

const { Agent, ProxyAgent, Dispatcher, setGlobalDispatcher, fetch: undiciFetch } = require("undici");

// ─── Optional outbound proxy ────────────────────────────────────────────────
// Set PROXY_URL (e.g. "http://user:pass@host:port") if the host's own
// outbound connection to Discord is being blocked/dropped rather than just
// flaky -- e.g. a silent 60s connect timeout with no auth error, no DNS
// error, nothing (some free/shared hosting IP ranges get soft-blocked or
// rate-limited by Discord because other tenants on the same IPs abused it).
// Leave PROXY_URL unset and nothing here changes -- same Agent/DNS behavior
// as before.
//
// Two separate things need routing through the proxy, since they don't share
// a connection stack:
//   1. REST calls (login, command registration, etc.) go through undici's
//      fetch -- undici ships ProxyAgent for exactly this, used as the global
//      dispatcher in place of the plain Agent.
//   2. The gateway WebSocket does NOT go through undici/fetch at all --
//      @discordjs/ws opens it directly via the 'ws' package, and only ever
//      passes `{ handshakeTimeout }` to its constructor, with no way to
//      supply an agent through any public discord.js/@discordjs/ws option.
//      The only hook available is to patch what 'ws' itself exports before
//      @discordjs/ws requires it, so every WebSocket it constructs picks up
//      an HTTP(S)-proxy-tunneling agent transparently.
const PROXY_URL = process.env.PROXY_URL || process.env.DISCORD_PROXY_URL;

// Only Discord traffic should ever go through PROXY_URL. Everything else --
// the Lavalink nodes (REST *and* websocket), the local dashboard health
// check on 127.0.0.1, Last.fm, etc. -- must connect directly. Previously the
// proxy was installed as the global dispatcher (and patched onto every
// WebSocket), so Lavalink REST calls like /v4/loadtracks were sent to the
// proxy, which answered with an HTML error page. lavalink-client then tried
// to JSON.parse that page: `Unexpected token '<', "<html>..."`.
const DISCORD_HOST_RE = /(^|\.)(discord\.com|discord\.gg|discordapp\.com|discordapp\.net|discord\.media)$/i;

function hostnameOf(target) {
  try {
    return new URL(typeof target === "string" ? target : (target?.href ?? String(target))).hostname;
  } catch {
    return "";
  }
}

// undici dispatcher that picks the proxied or the direct agent per request.
class RoutingDispatcher extends Dispatcher {
  constructor(direct, proxied) {
    super();
    this.direct  = direct;
    this.proxied = proxied;
  }
  dispatch(opts, handler) {
    const agent = DISCORD_HOST_RE.test(hostnameOf(opts.origin)) ? this.proxied : this.direct;
    return agent.dispatch(opts, handler);
  }
  close()   { return Promise.all([this.direct.close(),   this.proxied.close()]); }
  destroy() { return Promise.all([this.direct.destroy(), this.proxied.destroy()]); }
}

if (PROXY_URL) {
  console.log(`[Proxy] PROXY_URL set — routing Discord REST + gateway traffic (only) through ${PROXY_URL.replace(/\/\/.*@/, "//<redacted>@")}`);

  // 1. REST (fetch) — undici's own proxy-aware dispatcher.
  setGlobalDispatcher(new RoutingDispatcher(
    new Agent({ connect: { lookup: resilientDnsLookup } }),
    new ProxyAgent({ uri: PROXY_URL, connect: { lookup: resilientDnsLookup } }),
  ));

  // 2. Gateway WebSocket — patch 'ws' before @discordjs/ws (or anything else)
  // requires it. Node's module cache means whichever code requires('ws')
  // first gets this same patched export.
  const { HttpsProxyAgent } = require("https-proxy-agent");
  const proxyAgent = new HttpsProxyAgent(PROXY_URL);
  const ws = require("ws");
  const OriginalWebSocket = ws.WebSocket;
  class ProxiedWebSocket extends OriginalWebSocket {
    constructor(address, protocols, options) {
      // Lavalink (and any other non-Discord) websocket connects directly.
      const viaProxy = DISCORD_HOST_RE.test(hostnameOf(address));
      super(address, protocols, viaProxy ? { ...options, agent: proxyAgent } : options);
    }
  }
  ws.WebSocket = ProxiedWebSocket;
  // Some import styles (require('ws') directly as the constructor) grab the
  // default export instead of the named one -- patch that path too so it
  // doesn't matter which one @discordjs/ws happens to use.
  if (ws.default) ws.default = ProxiedWebSocket;
} else {
  setGlobalDispatcher(new Agent({ connect: { lookup: resilientDnsLookup } }));
}

globalThis.fetch = undiciFetch;

const { Client, GatewayIntentBits, Partials, Collection, EmbedBuilder, Options } = require("discord.js");
const { LavalinkManager } = require("lavalink-client");
const fs   = require("fs");
const path = require("path");
const { formatDuration, progressBar, resolveSpotify, pickBestTrackMatch, setVoiceStatus, clearVoiceStatus, setListeningPresence, resetPresence } = require("./utils/helpers");
const { purgeExpired } = require("./utils/queueStore");
const { handleMusicButton, buildNowPlayingEmbed, buildControlRow } = require("./utils/musicPanel");
const { snapshotActiveSessions, announceInterruptedSessions } = require("./utils/sessionRecovery");
const { clearAfk, getAfk } = require("./utils/afkStore");
const { getInboxChannelId } = require("./utils/inboxStore");
const { askGroq, transcribeAudio } = require("./utils/groq");
const coder = require("./utils/coder");
const { getMemory, pushMemory } = require("./utils/groqMemory");
const { recordMessage, recordDelete } = require("./utils/snipeCache");
const { isBlocked } = require("./utils/blocklist");
const { isOwner } = require("./utils/owners");

// Purge expired saved queues on startup
purgeExpired();

// ─── Discord client ───────────────────────────────────────────────────────────
// This bot doesn't read message content, react, use threads, stage channels,
// or presences -- discord.js caches all of those by default regardless, which
// adds up fast on a 100MB plan. Capping/zeroing what's genuinely unused here
// is the single biggest lever for staying under that limit.
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // needed to read text after the "hey" prefix for /groq chat
    GatewayIntentBits.DirectMessages, // needed so DMs to the bot fire messageCreate at all (DM inbox)
  ],
  // DM channels are never in the gateway's guild cache, so without the
  // Channel partial, DM messageCreate events get silently dropped instead
  // of firing with a partial channel object. Required for the DM inbox to
  // receive anything at all.
  //
  // Message partial: with MessageManager cache size 0 below, discord.js has
  // nothing cached to look up when a MESSAGE_UPDATE packet comes in for an
  // edit -- and without this partial, its internal getMessage() lookup just
  // gives up and the messageUpdate event never fires AT ALL (not "fires
  // with null oldMessage" -- doesn't fire, silently). This is what was
  // actually breaking the edited-message detection in index.js, not the
  // detection logic itself. With the partial present, discord.js constructs
  // a Message object on the fly for the event instead of requiring a cache
  // hit; the messageUpdate handler already calls .fetch() when it comes
  // back partial, so no other change is needed.
  partials: [Partials.Channel, Partials.Message],
  makeCache: Options.cacheWithLimits({
    MessageManager: 0,        // deliberately kept at 0 -- see the Partials.Message note above for why this doesn't block messageUpdate
    ReactionManager: 0,       // reactions aren't used anywhere in this bot
    ThreadManager: 0,         // no thread features
    StageInstanceManager: 0,  // no stage-channel features
    PresenceManager: 0,       // GuildPresences intent isn't even enabled
    GuildMemberManager: 100,  // still needed for voice channel members, just capped per-guild instead of unbounded
  }),
  sweepers: Options.DefaultSweeperSettings, // periodic archived-thread sweep; harmless baseline, kept as-is
});

// ─── Discord gateway resilience/visibility ───────────────────────────────────
// These were previously unhandled — discord.js auto-reconnects the gateway on
// its own, but silently, so a DNS blip or dropped connection left zero trace
// in the logs. An 'error' event with no listener can also crash the process
// outright (EventEmitter default behavior), so this doubles as a safety net.
client.on("error",           err    => console.error("[Discord] Client error:", err.message));
client.on("shardError",      (err, shardId) => console.error(`[Discord] Shard ${shardId} error:`, err.message));
client.on("shardDisconnect", (event, shardId) => console.warn(`[Discord] Shard ${shardId} disconnected (code ${event?.code}) — reconnecting...`));
client.on("shardReconnecting", shardId => console.log(`[Discord] Shard ${shardId} reconnecting...`));
client.on("shardResume",     (shardId, replayed) => console.log(`[Discord] Shard ${shardId} resumed (${replayed} events replayed)`));

// shardCreate fires the moment a shard is spawned, BEFORE it's even
// attempted to connect -- useful to know the process got at least this far
// (past fetching gateway/session-limit info from Discord's REST API) versus
// never getting past the initial login() call at all.
client.on("shardCreate", shard => console.log(`[Discord] Shard ${shard.id} created — attempting initial connection...`));

// The 'debug' event fires constantly (a heartbeat ack log line roughly every
// 40s alone), so filtering to just the handshake/connection lifecycle
// messages keeps this useful instead of drowning the log. This is what
// tells us WHERE a silent hang is actually stuck: still resolving gateway
// info from Discord's REST API, waiting on a session-start rate limit,
// mid-handshake, or waiting on IDENTIFY/READY.
const GATEWAY_LIFECYCLE_DEBUG_PATTERNS = /Fetching Gateway|Fetched Gateway|Session Limit|Identify|Identifying|identify throttle|Waiting for|Preparing to connect|Opening|Connected to|Invalid Session|Ratelimit|429/i;
client.on("debug", message => {
  if (GATEWAY_LIFECYCLE_DEBUG_PATTERNS.test(message)) {
    console.log(`[Discord/debug] ${message.split("\n")[0]}`);
  }
});

// ─── Connection watchdog: restart the whole process if Discord is unreachable ──
// discord.js retries the gateway connection forever on its own, but "forever"
// isn't always the right answer -- e.g. a bad token never succeeds, and some
// disconnects (host network blip, Discord-side incident) can leave the
// client stuck reconnecting far longer than is useful. Rather than trying to
// out-guess every failure mode from in here, this just gives up and exits
// the process after a timeout, so the host's own restart policy (already
// configured: Dockerfile/docker-compose `restart: unless-stopped`,
// railway.json `ON_FAILURE`, discloud.config `AUTORESTART=true`, and
// Pterodactyl/Wispbyte's built-in crash-detection auto-restart) brings up a
// fresh process and a fresh connection attempt.
const INITIAL_CONNECT_TIMEOUT_MS = parseInt(process.env.CONNECT_TIMEOUT_MS || "60000", 10);   // first login must succeed within this
const RECONNECT_GIVEUP_MS        = parseInt(process.env.RECONNECT_TIMEOUT_MS || "120000", 10); // once connected, a dropped connection must recover within this

let hasConnectedOnce = false;
let disconnectedSince = null;

client.once("clientReady", () => {
  hasConnectedOnce = true;
  disconnectedSince = null;
});
client.on("shardDisconnect", () => { if (disconnectedSince === null) disconnectedSince = Date.now(); });
client.on("shardResume",     () => { disconnectedSince = null; });
client.on("shardReady",      () => { disconnectedSince = null; });

function restartAndExit(reason) {
  console.error(`[Watchdog] ${reason} — exiting so the host restarts the process.`);
  snapshotActiveSessions(client, reason);
  process.exit(1);
}

const processStartedAt = Date.now();

const watchdog = setInterval(() => {
  if (!hasConnectedOnce && Date.now() - processStartedAt > INITIAL_CONNECT_TIMEOUT_MS) {
    restartAndExit(`Never connected to Discord within ${INITIAL_CONNECT_TIMEOUT_MS / 1000}s of starting (check DISCORD_TOKEN and network access to discord.com)`);
    return;
  }
  if (hasConnectedOnce && disconnectedSince !== null && Date.now() - disconnectedSince > RECONNECT_GIVEUP_MS) {
    restartAndExit(`Disconnected from Discord and couldn't reconnect within ${RECONNECT_GIVEUP_MS / 1000}s`);
  }
}, 10000);
watchdog.unref();

client.commands      = new Collection();
client.npIntervals   = new Map();
client.errorCounts   = new Map();
client.retriedTracks = new Map();

// ─── Load commands ────────────────────────────────────────────────────────────
for (const file of fs.readdirSync(path.join(__dirname, "commands")).filter(f => f.endsWith(".js"))) {
  const cmd = require(path.join(__dirname, "commands", file));
  if (cmd.data && cmd.execute) {
    client.commands.set(cmd.data.name, cmd);
  } else {
    console.warn(`[Startup] Skipped loading "${file}" — missing .data or .execute export (has data=${!!cmd.data}, execute=${typeof cmd.execute === "function"}). This command may still be registered with Discord but won't respond.`);
  }
}
console.log(`[Startup] Loaded ${client.commands.size} command(s) into the handler: ${[...client.commands.keys()].join(", ")}`);

// ─── Lavalink reconnect cooldown ──────────────────────────────────────────────
// The node was previously configured to retry every 2.5s, up to 20 times in a
// row (~50s of back-to-back connection attempts). That's fast enough to look
// like abuse to most hosts/reverse proxies, which then start throttling or
// rejecting the connection -- so the "spam" was actively causing the "can't
// connect". Instead of a fixed delay, this grows the wait after every failed
// attempt (5s, 10s, 20s, 40s, capped at 60s) and resets back down to the base
// the moment a connection actually succeeds.
const RECONNECT_BASE_DELAY_MS = 5000;
const RECONNECT_MAX_DELAY_MS  = 60000;

// Some free/shared Lavalink hosts (e.g. Serenetia) close the websocket with
// code 4000 and an explicit "too many connection attempts, try again later"
// reason when a bot has reconnected too often. That's a hard ban from their
// side, not a normal blip -- retrying every 60s just keeps feeding the same
// counter and can extend the ban, so this needs a much longer, separate
// cooldown instead of the regular exponential backoff above.
const RATE_LIMIT_COOLDOWN_MS = 10 * 60 * 1000; // 10 minutes

function isHostRateLimitClose(reason) {
  if (!reason) return false;
  const code = reason.code ?? reason?.closeEventCode;
  const text = typeof reason === "string" ? reason : (reason.reason || reason.message || JSON.stringify(reason));
  return code === 4000 || /too many websocket connection/i.test(text || "");
}

// ─── Lavalink ─────────────────────────────────────────────────────────────────
// Requires LAVALINK_HOST / LAVALINK_PORT / LAVALINK_PASS to be set (see .env.example).
// No hardcoded fallback here on purpose -- a default host/password would silently
// point every deployment at the same Lavalink node.
// LAVALINK_SECURE is optional (defaults to false/non-SSL) -- most free public
// nodes and self-hosted setups (docker-compose, Railway private networking)
// don't use SSL, so this is only needed for nodes that specifically require it.
for (const required of ["LAVALINK_HOST", "LAVALINK_PORT", "LAVALINK_PASS"]) {
  if (!process.env[required]) {
    console.error(`[Startup] Missing required environment variable: ${required}. Set it in your host's environment variables (see .env.example).`);
    process.exit(1);
  }
}
// process.env values are always strings -- "false" is truthy in JS, so this
// has to be compared explicitly rather than used directly as a boolean.
const LAVALINK_SECURE = process.env.LAVALINK_SECURE?.toLowerCase() === "true";

const lavalinkNodes = [
  {
    id:                     "main",
    host:                   process.env.LAVALINK_HOST,
    port:                   parseInt(process.env.LAVALINK_PORT, 10),
    authorization:          process.env.LAVALINK_PASS,
    secure:                 LAVALINK_SECURE,
    retryAmount:            30,
    retryDelay:             RECONNECT_BASE_DELAY_MS, // starting point — grows via the backoff below
    requestSignalTimeoutMS: 30000,
    heartBeatInterval:      30000,
    enablePingOnStatsCheck: true,
  },
];

// Extra nodes are all fully optional -- each one only gets added if its own
// three required env vars are actually set, so a deployment that never
// configures any of them just runs on "main" alone instead of connecting
// with an undefined host/NaN port. LAVALINK_HOST2 was the original "backup"
// node; HOST3..HOST7 are 5 more slots on the same pattern.
const EXTRA_NODE_SUFFIXES = ["2", "3", "4", "5", "6", "7"];

for (const n of EXTRA_NODE_SUFFIXES) {
  const host = process.env[`LAVALINK_HOST${n}`];
  const port = process.env[`LAVALINK_PORT${n}`];
  const pass = process.env[`LAVALINK_PASS${n}`];

  if (!host || !port || !pass) continue;

  lavalinkNodes.push({
    id:                     n === "2" ? "backup" : `node${n}`,
    host,
    port:                   parseInt(port, 10),
    authorization:          pass,
    secure:                 process.env[`LAVALINK_SECURE${n}`]?.toLowerCase() === "true",
    retryAmount:            30,
    retryDelay:             RECONNECT_BASE_DELAY_MS,
    requestSignalTimeoutMS: 30000,
    heartBeatInterval:      30000,
    enablePingOnStatsCheck: true,
  });
}

console.log(`[Lavalink] Running with ${lavalinkNodes.length} node(s): ${lavalinkNodes.map(n => n.id).join(", ")}.`);
if (lavalinkNodes.length < 2) {
  console.log("[Lavalink] Tip: set LAVALINK_HOST2/PORT2/PASS2 (and up through HOST7/PORT7/PASS7) to add more nodes.");
}

client.lavalink = new LavalinkManager({
  nodes: lavalinkNodes,
  sendToShard: (guildId, payload) => {
    const guild = client.guilds.cache.get(guildId);
    if (guild) guild.shard.send(payload);
  },
  client: {
    id:       process.env.CLIENT_ID,
    username: "MusicBot",
  },
  playerOptions: {
    defaultSearchPlatform:             "ytmsearch",
    onDisconnect:                      { autoReconnect: true, destroyPlayer: false },
    onEmptyQueue:                      { destroyAfterMs: 30000 },
    applyVolumeAsFilter:               false,
    clientBasedPositionUpdateInterval: 100,
  },
  queueOptions:    { maxPreviousTracks: 10 },
  advancedOptions: {
    enableDebugEvents:    true,
    maxFilterFixDuration: 600,
    debugOptions:         { noAudio: { toggleSleepOnInactivity: false } },
  },
});

// ─── Push YouTube OAuth token to youtube-source plugin ───────────────────────
async function pushYouTubeOAuth(node) {
  const token = process.env.YOUTUBE_REFRESH_TOKEN;
  if (!token) {
    console.warn("[Lavalink] YOUTUBE_REFRESH_TOKEN not set — YouTube may fall back to unauthenticated requests.");
    return;
  }
  try {
    const protocol = node.options.secure ? "https" : "http";
    const base     = `${protocol}://${node.options.host}:${node.options.port}`;

    const res = await fetch(`${base}/youtube`, {
      method:  "POST",
      headers: {
        "Authorization": node.options.authorization,
        "Content-Type":  "application/json",
      },
      body: JSON.stringify({ refreshToken: token }),
    });

    if (res.status === 204) {
      console.log(`[Lavalink] YouTube OAuth token accepted by node "${node.id}" ✅`);
    } else {
      const text = await res.text();
      console.error(`[Lavalink] YouTube OAuth push failed (${res.status}): ${text}`);
    }
  } catch (err) {
    console.error("[Lavalink] YouTube OAuth push error:", err.message);
  }
}

// ─── Lavalink node events ─────────────────────────────────────────────────────
let hasAnnouncedInterruptedSessions = false;

client.lavalink.nodeManager
  .on("connect", async (node) => {
    console.log(`[Lavalink] Node "${node.id}" connected ✅`);
    node.options.retryDelay = RECONNECT_BASE_DELAY_MS; // back to normal now that it's actually connected
    await pushYouTubeOAuth(node);

    if (!hasAnnouncedInterruptedSessions) {
      hasAnnouncedInterruptedSessions = true;
      await announceInterruptedSessions(client);
    }
  })
  .on("error",        (node, err)    => console.error(`[Lavalink] Node "${node.id}" error:`, err.message))
  .on("disconnect",   (node, reason) => {
    console.warn(`[Lavalink] Node "${node.id}" disconnected:`, JSON.stringify(reason));
    snapshotActiveSessions(client, isHostRateLimitClose(reason) ? "Lavalink connection rate-limited by host" : "Lavalink connection lost");
    if (isHostRateLimitClose(reason)) {
      node.options.retryDelay = RATE_LIMIT_COOLDOWN_MS;
      console.warn(`[Lavalink] Node "${node.id}" was rate-limited by the host for too many connection attempts — backing off ${RATE_LIMIT_COOLDOWN_MS / 60000} minutes instead of the normal retry schedule.`);
    }
  })
  .on("reconnecting", (node)         => {
    console.log(`[Lavalink] Node "${node.id}" reconnecting (next retry in ${node.options.retryDelay}ms)...`);
    // Cooldown: double the wait for the *next* attempt, capped, so a node
    // that's actually down doesn't get hammered with connection attempts.
    node.options.retryDelay = Math.min(node.options.retryDelay * 2, RECONNECT_MAX_DELAY_MS);
  });

// ─── Now-playing embed ────────────────────────────────────────────────────────
// Uses the shared builder from utils/musicPanel.js — same embed + button row
// as /play and /nowplaying, so the auto-announcement on trackStart below
// looks and behaves identically (including working Previous/-10s/Play-Pause
// /+10s/Next buttons) instead of the old buttonless standalone version.

function clearNpInterval(guildId) {
  const iv = client.npIntervals.get(guildId);
  if (iv) { clearInterval(iv); client.npIntervals.delete(guildId); }
}

// ─── Autoplay via YouTube radio mix ───────────────────────────────────────────
async function handleAutoplay(player, lastTrack) {
  try {
    const requester  = lastTrack.requester || client.user;
    const sourceName = lastTrack.info.sourceName || "unknown";
    let   videoId     = lastTrack.info.identifier;

    console.log(`[Autoplay] Seeding from: "${lastTrack.info.title}" source=${sourceName}`);

    // YouTube's radio mix (list=RD{videoId}) only works with a real YouTube
    // video id. A native youtube-sourced track's own identifier already is
    // one -- but anything from a different source (Spotify, SoundCloud,
    // etc.) has some other id shape entirely, so it has to be resolved to
    // an actual YouTube video first via a normal search before a radio mix
    // can be built from it at all.
    if (sourceName !== "youtube") {
      const query = `${lastTrack.info.author || ""} ${lastTrack.info.title}`.trim();
      console.log(`[Autoplay] Non-YouTube source (${sourceName}) — resolving "${query}" to a YouTube video first`);
      const resolveRes = await player.search({ query, source: "ytsearch" }, requester).catch(() => null);
      videoId = resolveRes?.tracks?.[0]?.info?.identifier || null;
      if (!videoId) {
        console.warn(`[Autoplay] Couldn't resolve "${lastTrack.info.title}" to a YouTube video — queue will end.`);
        return;
      }
    }

    console.log(`[Autoplay] Using YouTube radio mix seeded from video ${videoId}`);
    const res = await player.search(
      { query: `https://www.youtube.com/watch?v=${videoId}&list=RD${videoId}`, source: "youtube" },
      requester
    );

    const played = new Set((player.queue.previous || []).map(t => t.info.identifier));
    const recommendations = (res?.tracks || []).filter(t => t.info.identifier !== videoId && !played.has(t.info.identifier));

    if (!recommendations.length) {
      console.warn("[Autoplay] No recommendations found — queue will end.");
      return;
    }

    console.log(`[Autoplay] Adding ${recommendations.length} tracks to queue`);
    await player.queue.add(recommendations.slice(0, 5));
    if (!player.playing) await player.play();
  } catch (err) {
    console.error("[Autoplay] Error:", err.message);
  }
}

// ─── Track error retry helper ─────────────────────────────────────────────────
async function searchReplacement(player, failedTrack, sources) {
  const query          = `${failedTrack.info.title} ${failedTrack.info.author || ""}`.trim();
  const targetDuration = failedTrack.info.duration || 0;

  for (const source of sources) {
    try {
      const res = await player.search({ query, source }, failedTrack.requester);
      if (!res?.tracks?.length) {
        console.log(`[Lavalink] Replacement search on ${source} returned no results for "${query}"`);
        continue;
      }
      console.log(`[Lavalink] Replacement search on ${source} found ${res.tracks.length} result(s) for "${query}"`);
      return pickBestTrackMatch(res.tracks, targetDuration);
    } catch (err) {
      console.error(`[Lavalink] Replacement search failed on ${source}:`, err.message);
    }
  }
  return null;
}

// ─── Lavalink player events ───────────────────────────────────────────────────
client.lavalink

  .on("trackStart", async (player, track) => {
    console.log(`[Lavalink] trackStart: "${track.info.title}" source=${track.info.sourceName} guild=${player.guildId}`);
    clearNpInterval(player.guildId);
    client.errorCounts.set(player.guildId, 0);
    client.retriedTracks.delete(player.guildId);

    await setVoiceStatus(client, player.voiceChannelId, `<:NoName:1529477858307604540> ${track.info.title}`);
    setListeningPresence(client, track.info.title);

    const channel = client.channels.cache.get(player.textChannelId);
    if (!channel) return;

    let npMsg;
    try {
      npMsg = await channel.send({
        embeds:     [buildNowPlayingEmbed(player)],
        components: [buildControlRow(player)],
      });
    }
    catch { return; }

    if (!track.info.isStream) {
      const iv = setInterval(async () => {
        const p = client.lavalink.getPlayer(player.guildId);
        if (!p?.queue.current || p.paused) return;
        try {
          await npMsg.edit({
            embeds:     [buildNowPlayingEmbed(p)],
            components: [buildControlRow(p)],
          });
        }
        catch { clearNpInterval(player.guildId); }
      }, 10_000);
      client.npIntervals.set(player.guildId, iv);
    }
  })

  .on("trackEnd", (player) => {
    clearNpInterval(player.guildId);
  })

  .on("trackError", async (player, track, payload) => {
    const guildId = player.guildId;
    const reason  = payload?.exception?.message || payload?.exception?.cause || "Unknown error";
    console.error(`[Lavalink] trackError guild=${guildId}:`, reason);
    clearNpInterval(guildId);

    const channel      = client.channels.cache.get(player.textChannelId);
    const isLoginError = /sign in|login|requires login|bot|cookie|403|unavailable|not available|restricted|private|removed|blocked|copyright/i.test(reason);

    const failCount = (client.errorCounts.get(guildId) || 0) + 1;
    client.errorCounts.set(guildId, failCount);
    if (failCount >= 5) {
      client.errorCounts.set(guildId, 0);
      channel?.send("<:Warning:1537804174451015791> Too many tracks failed in a row. Stopping playback.").catch(() => {});
      await player.stopPlaying(true).catch(() => {});
      return;
    }

    const trackKey   = track?.info?.identifier || track?.encoded;
    let   retriedSet = client.retriedTracks.get(guildId);
    if (!retriedSet) { retriedSet = new Set(); client.retriedTracks.set(guildId, retriedSet); }

    if (track && trackKey && !retriedSet.has(trackKey)) {
      retriedSet.add(trackKey);

      // Always log/announce the retry attempt — previously this was silent
      // unless the error text matched a narrow "login" regex, which made it
      // look like the bot skipped straight away with no retry at all.
      console.log(`[Lavalink] "${track.info.title}" failed (${reason}) — searching for a replacement...`);
      channel?.send(`<:Warning:1537804174451015791> **${track.info.title}** failed to play (${reason}) — trying another source...`).catch(() => {});

      const sources     = isLoginError ? ["ytsearch", "ytmsearch"] : ["ytmsearch", "ytsearch"];
      const replacement = await searchReplacement(player, track, sources);

      if (replacement) {
        console.log(`[Lavalink] Replacement found via ${replacement.info.sourceName}`);
        player.queue.tracks.unshift(replacement);
        await player.skip(0, false).catch(err => console.error("[Lavalink] skip-to-retry failed:", err.message));
        return;
      }

      console.warn(`[Lavalink] No replacement found for "${track.info.title}" — giving up and skipping.`);
    }

    channel?.send(`<:Warning:1537804174451015791> Couldn't play **${track?.info?.title || "that track"}** — skipping.`).catch(() => {});
    await player.skip(0, false).catch(err => {
      console.error("[Lavalink] skip-after-error failed:", err.message);
      player.stopPlaying(true).catch(() => {});
    });
  })

  .on("trackStuck", (player, track) => {
    console.warn(`[Lavalink] Track stuck guild=${player.guildId}: "${track?.info?.title}"`);
    clearNpInterval(player.guildId);
    client.channels.cache.get(player.textChannelId)
      ?.send(`<:Warning:1537804174451015791> **${track?.info?.title || "Track"}** got stuck and was skipped.`).catch(() => {});
  })

  .on("playerSocketClosed", (player, payload) => {
    console.warn(`[Lavalink] Player socket closed guild=${player.guildId}:`, payload);
  })

  .on("queueEnd", async (player) => {
    clearNpInterval(player.guildId);
    const guildId = player.guildId;
    const textChannelId = player.textChannelId;

    // AFK mode — stay in channel, do nothing
    if (player.get("afk")) {
      console.log(`[Autoplay] Queue ended in guild ${guildId} — staying in channel (AFK mode)`);
      resetPresence(client);
      return;
    }

    // BUILT-IN AUTOPLAY — Always trigger automatically
    const seed = player.queue.previous?.[0];
    console.log(`[Autoplay] queueEnd triggered — seed: "${seed?.info?.title || "NONE"}"`);
    
    if (seed) {
      console.log(`[Autoplay] Starting recommendation generation...`);
      await handleAutoplay(player, seed);
      
      // Wait a moment for queue to populate
      await new Promise(r => setTimeout(r, 500));
      
      // Check if recommendations were added
      if (player.queue.tracks.length > 0) {
        console.log(`[Autoplay] Successfully queued recommendations. Queue size: ${player.queue.tracks.length}`);
        if (!player.get("autoplayAnnounced")) {
          player.set("autoplayAnnounced", true);
          const textChannel = client.channels.cache.get(textChannelId);
          textChannel?.send("<:Sparkle:1537804172714573834> Autoplay activated! Now playing recommended music").catch(() => {});
        }
        return;
      } else {
        console.warn("[Autoplay] No recommendations were generated");
      }
    } else {
      console.warn("[Autoplay] No previous track found to seed recommendations");
    }

    // Fallback: queue has ended, no autoplay possible
    player.set("autoplayAnnounced", false);
    await clearVoiceStatus(client, player.voiceChannelId);
    resetPresence(client);
    client.channels.cache.get(textChannelId)
      ?.send("<:Success:1537804182206160936> Queue finished! Use `/play` to add more tracks for non-stop music.").catch(() => {});
  });


// ─── Load events ──────────────────────────────────────────────────────────────
for (const file of fs.readdirSync(path.join(__dirname, "events")).filter(f => f.endsWith(".js"))) {
  const event = require(path.join(__dirname, "events", file));
  if (!event?.name || typeof event.execute !== "function") {
    console.error(`[Events] "${file}" doesn't export a valid {name, execute} — skipped, NOT registered.`);
    continue;
  }
  if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
  else            client.on(  event.name, (...args) => event.execute(...args, client));
  console.log(`[Events] Registered "${event.name}" from ${file}${event.once ? " (once)" : ""}`);
}
console.log(`[Events] listenerCount("messageDelete") = ${client.listenerCount("messageDelete")}`);

// ─── Forward voice updates to Lavalink ───────────────────────────────────────
client.on("raw", d => {
  if (["VOICE_STATE_UPDATE", "VOICE_SERVER_UPDATE"].includes(d.t)) {
    if (d.d && !d.d.guild_id && d.d.member?.guild_id)
      d.d.guild_id = d.d.member.guild_id;
    console.log(`[Voice] ${d.t} guild=${d.d?.guild_id ?? "UNKNOWN"}`);
  }
  // Snipe delete detection goes straight off the raw gateway packet instead
  // of discord.js's own messageDelete event -- this is the actual payload
  // Discord sends, with no dependency on discord.js's internal channel/
  // message cache resolution or partials handling in between.
  if (d.t === "MESSAGE_DELETE" && d.d?.id && d.d?.channel_id) {
    recordDelete(d.d.id, d.d.channel_id);
  }
  client.lavalink.sendRawData(d);
});

// ─── Slash command handler ────────────────────────────────────────────────────
// Bug fix: commands were crashing (spamming DiscordAPIError[50027] "Invalid
// Webhook Token" in the logs) whenever a reply landed after the interaction's
// 15-minute webhook token had lapsed — e.g. a slow Lavalink round trip, a
// queued/backlogged event after a brief reconnect, or a long Spotify playlist
// import. editReply()/reply()/followUp() would throw, the command's own code
// had no recovery path, and the user never got a response. We now patch those
// three methods per-interaction so an expired/invalid token transparently
// falls back to a normal channel message instead of throwing.
function isExpiredInteractionError(err) {
  return err?.code === 50027 || err?.code === 10062 || err?.status === 401;
}

function attachSafeInteractionReplies(interaction, client) {
  const originalReply     = interaction.reply.bind(interaction);
  const originalEditReply = interaction.editReply.bind(interaction);
  const originalFollowUp  = interaction.followUp.bind(interaction);

  const sendToChannel = async payload => {
    const channel =
      interaction.channel || client.channels.cache.get(interaction.channelId);
    if (!channel?.send) return null;
    const { content, embeds, components } =
      typeof payload === "string" ? { content: payload } : payload || {};
    return channel.send({ content, embeds, components }).catch(() => null);
  };

  const wrap = (name, original) => async payload => {
    try {
      return await original(payload);
    } catch (err) {
      if (isExpiredInteractionError(err)) {
        console.warn(
          `[Interaction] Token expired on ${name} for /${interaction.commandName} — sending a channel message instead.`
        );
        return sendToChannel(payload);
      }
      throw err;
    }
  };

  interaction.reply     = wrap("reply", originalReply);
  interaction.editReply = wrap("editReply", originalEditReply);
  interaction.followUp  = wrap("followUp", originalFollowUp);
}

client.on("interactionCreate", async interaction => {
  if (interaction.isAutocomplete()) {
    const command = client.commands.get(interaction.commandName);
    if (command?.autocomplete) command.autocomplete(interaction, client).catch(() => {});
    else console.warn(`[Interaction] Autocomplete fired for "/${interaction.commandName}" but no autocomplete handler found.`);
    return;
  }
  // Music control panel buttons (from /nowplaying) -- these live as long as
  // the message does, not just for a single collector's lifetime, so they're
  // routed here globally instead of through a per-command collector.
  if (interaction.isButton() && interaction.customId.startsWith("music_")) {
    if (isBlocked(interaction.user.id) && !isOwner(interaction.user.id)) {
      return interaction.reply({ content: "you can't use this bot.", ephemeral: true }).catch(() => {});
    }
    return handleMusicButton(interaction, client).catch(err => {
      console.error(`[MusicPanel/${interaction.customId}]`, err);
    });
  }

  if (!interaction.isChatInputCommand() && !interaction.isMessageContextMenuCommand()) return;

  console.log(`[Interaction] "/${interaction.commandName}" invoked by ${interaction.user?.tag} in guild=${interaction.guildId}`);

  const command = client.commands.get(interaction.commandName);
  if (!command) {
    console.warn(`[Interaction] "/${interaction.commandName}" is registered with Discord but not found in client.commands (known: ${[...client.commands.keys()].join(", ")}). Replying with an error instead of staying silent.`);
    await interaction.reply({ content: "This command isn't available right now — it may need a restart to sync. Try again shortly.", ephemeral: true }).catch(err => console.error("[Interaction] Failed to send unknown-command reply:", err.message));
    return;
  }

  // Same blocklist as messageCreate -- checked here too since slash
  // commands don't go through that handler at all. Owners are exempt so a
  // stale/corrupted blocklist entry can never lock an owner out of their
  // own bot (they're also the only ones who can add entries in the first
  // place via /botban).
  if (isBlocked(interaction.user.id) && !isOwner(interaction.user.id)) {
    return interaction.reply({ content: "you can't use this bot.", ephemeral: true }).catch(() => {});
  }

  attachSafeInteractionReplies(interaction, client);

  try {
    await command.execute(interaction, client);
  } catch (err) {
    console.error(`[Command/${interaction.commandName}]`, err);
    const payload = { content: "An error occurred.", ephemeral: true };
    if (interaction.deferred || interaction.replied) await interaction.editReply(payload).catch(() => {});
    else await interaction.reply(payload).catch(() => {});
  }
});

// ─── AFK system + "noname" Groq chat ──────────────────────────────────────
// Requires the Message Content intent (enabled above) so we can read the
// text after the "noname" prefix -- make sure it's also toggled ON under
// Bot > Privileged Gateway Intents in the Discord Developer Portal, or
// message.content will silently come through empty.
//
// "noname" chat triggers three ways, same as pinging any normal Discord bot:
//   1. Message contains "noname" anywhere in it  -> noname help me out / yo noname sup / hey noname, whats good
//   2. Message @-mentions the bot                 -> @noname sup
//   3. Message is a reply to one of the bot's own msgs -> (reply) fr?
//
// Groq is asked to answer in a strict JSON action format (see utils/groq.js)
// so a single reply can bundle up to 5 chat messages (each with its own
// human-like send delay), an emoji reaction, and a "join my voice channel"
// request all from one model call. Short-term memory (utils/groqMemory.js)
// keeps only the last 3 messages per channel -- enough for the bot to feel
// like it's following along without turning into a full transcript log.
//
// The trigger word itself can sit anywhere in the sentence -- start, middle,
// or end -- not just as a leading prefix. NONAME_WORD (global) is used to
// strip every occurrence of it (plus any trailing punctuation right after
// it, e.g. "noname," / "noname:") out of the prompt sent to Groq, so the
// model isn't stuck re-reading its own name back as part of the question.
// NONAME_TEST (non-global) is the cheap membership check used per message.
const NONAME_WORD = /\bnoname\b[\s,:]*/gi;
const NONAME_TEST = /\bnoname\b/i;

// noname's own last sent message per channel: channelId -> { id, text }. This
// is the ONLY state that lets self_action (edit/delete) work, and it's
// deliberately narrow -- it only ever remembers the message the bot itself
// just sent, so there is no path (via Groq or otherwise) for self_action to
// reach a message that isn't noname's own. In-memory only, same as the
// short-term chat memory in groqMemory.js -- resets on restart, which is
// fine since it's just "what did I say last", not durable state.
const lastBotMessageByChannel = new Map();

// Trigger message ID -> { replyId, originalContent, channelId }. Populated
// only for the FIRST reply of a noname turn (the message.reply() below),
// since that's the one visually tied to the user's original message in
// Discord's UI -- the thing the "ask something, get a reply, then edit the
// question to something else" prank relies on. See the messageUpdate
// listener further down for what actually happens with this.
// TTL-cleaned (NONAME_EDIT_WATCH_MS below) so this doesn't grow forever.
const nonameTriggerReplies = new Map();
const NONAME_EDIT_WATCH_MS = 30 * 60 * 1000; // 30 min

async function handleNonameChat(message, prompt, client) {
  await message.channel.sendTyping().catch(() => {});

  // Pull out any image attachments (photos, screenshots, etc.) so Groq's
  // vision model can actually look at them. Discord attachment URLs are
  // public https links already, so they're passed straight through.
  const imageUrls = [...message.attachments.values()]
    .filter(a => a.contentType?.startsWith("image/"))
    .map(a => a.url);

  // Same idea for voice messages / audio file attachments -- Discord voice
  // messages in particular usually carry NO text at all, so without this
  // the whole point of sending one (talking instead of typing) wouldn't
  // reach the model. Only the first audio attachment is used; a message
  // realistically only ever has one.
  const audioAttachment = [...message.attachments.values()]
    .find(a => a.contentType?.startsWith("audio/"));

  let effectivePrompt = prompt;
  if (audioAttachment) {
    try {
      const transcript = await transcribeAudio(audioAttachment.url, audioAttachment.name);
      const voiceNote = `[voice message: "${transcript}"]`;
      effectivePrompt = (prompt && prompt !== "(no message content)")
        ? `${prompt}\n${voiceNote}`
        : voiceNote;
    } catch (err) {
      console.error("[Groq] Audio transcription failed:", err.message);
      // Fall through with the original text-only prompt rather than failing
      // the whole interaction over a transcription hiccup.
    }
  }

  // What noname itself last sent in this channel, if anything -- captured
  // BEFORE this turn's messages go out, since self_action (below) can only ever refer to a *previous*
  // turn's message, never the one about to be sent. This is also the only
  // piece of state that makes self_action possible at all: the model is
  // never given a raw message ID to act on, it only ever gets told what
  // noname's own last message here said; the caller resolves that against
  // the one message ID it already knows is noname's own.
  const previousOwnMessage = lastBotMessageByChannel.get(message.channel.id) || null;

  // If the message @-mentions any other user(s), fetch their real Discord
  // profile (GET /users/{id}, via client.users.fetch with force so it's an
  // actual live lookup and not a stale cache hit) so noname can talk about
  // them with real info instead of guessing. Capped at 3 -- a message
  // realistically only ever tags a couple people, and this is one REST call
  // per mention. The bot itself is excluded (that's `mentionsBot`/the
  // trigger logic already, not something to re-describe as "a mentioned
  // user"), and so is the author (already covered by `author` below).
  const mentionTargets = [...message.mentions.users.values()]
    .filter(u => u.id !== client.user.id && u.id !== message.author.id)
    .slice(0, 3);

  const mentionedUsers = [];
  for (const u of mentionTargets) {
    try {
      const fresh = await client.users.fetch(u.id, { force: true });
      const member = await message.guild.members.fetch(u.id).catch(() => null);
      mentionedUsers.push({
        id:          fresh.id,
        username:    fresh.username,
        displayName: member?.displayName || fresh.globalName || fresh.username,
        bot:         fresh.bot,
        createdAt:   fresh.createdAt.toISOString().slice(0, 10), // just the date -- exact time isn't useful chat context
      });
    } catch (err) {
      console.error(`[Groq] Failed to fetch mentioned user ${u.id}:`, err.message);
      // Skip this one (e.g. deleted account, rare API hiccup) rather than
      // failing the whole turn over a lookup that isn't essential.
    }
  }

  const author = {
    username:    message.author.username,
    displayName: message.member?.displayName || message.author.globalName || message.author.username,
    id:          message.author.id,
  };

  // askGroq() can run tools mid-turn (web search, image search), so a reply
  // can take longer than one plain completion. Discord's typing indicator only lasts
  // ~10s, so keep refreshing it until the answer is in.
  const typingTimer = setInterval(() => message.channel.sendTyping().catch(() => {}), 8000);
  typingTimer.unref?.();

  let result;
  try {
    result = await askGroq({
      prompt:   effectivePrompt,
      history:  getMemory(message.channel.id),
      imageUrls,
      author,
      mentionedUsers,
      lastOwnMessage: previousOwnMessage,
      richReplies: true,   // text channel: image links work
    });
  } catch (err) {
    console.error("[Groq] Failed to get a response:", err.message);
    await message.reply("bro my brain isnt loading rn, try again in a sec").catch(() => {});
    return;
  } finally {
    clearInterval(typingTimer);
  }

  // Send up to 5 messages, first one as a reply (so it's clear what it's
  // responding to), the rest as normal follow-up messages. Each message
  // (besides the first) can carry its own "delay" in seconds -- picked by
  // Groq -- so a reply can land like "yo!" ... [wait a few secs] ... "so
  // basically..." instead of everything dumping into the channel at once.
  // A typing indicator is kept alive during the wait so it still reads as
  // someone actually composing the next message, not just a dead pause.
  // Kept as a helper (rather than inlined) so `startIndex` can decide which
  // message gets the message.reply() treatment -- only the true first
  // message of the turn is sent as a reply, the rest are plain follow-ups.
  async function sendNonameMessages(messagesArr, startIndex) {
    const texts = [];
    let last = null;
    for (let i = 0; i < messagesArr.length; i++) {
      const { text, delay } = messagesArr[i];
      const globalIndex = startIndex + i;
      try {
        let sent;
        if (globalIndex === 0) {
          sent = await message.reply({ content: text });
          // Snapshot the original content NOW -- if we read message.content
          // later (inside the messageUpdate handler) it'd already be the
          // edited text, defeating the whole point.
          nonameTriggerReplies.set(message.id, {
            replyId:         sent.id,
            originalContent: message.content,
            channelId:       message.channel.id,
          });
          const cleanupTimer = setTimeout(() => nonameTriggerReplies.delete(message.id), NONAME_EDIT_WATCH_MS);
          cleanupTimer.unref?.();
        } else {
          const waitMs = Math.max(0, Number(delay) || 0) * 1000;
          await message.channel.sendTyping().catch(() => {});
          // Discord's typing indicator only lasts ~10s at a time, so keep
          // refreshing it every 8s for waits longer than that.
          let elapsed = 0;
          while (elapsed < waitMs) {
            const chunk = Math.min(8000, waitMs - elapsed);
            await new Promise(r => setTimeout(r, chunk));
            elapsed += chunk;
            if (elapsed < waitMs) await message.channel.sendTyping().catch(() => {});
          }
          sent = await message.channel.send({ content: text });
        }
        texts.push(text);
        last = sent;
      } catch (err) {
        console.error("[Groq] Failed to send a noname message:", err.message);
      }
    }
    return { texts, last };
  }

  let sentTexts = [];
  let lastSentMessage = null;

  const firstBatch = await sendNonameMessages(result.messages, 0);
  sentTexts = firstBatch.texts;
  lastSentMessage = firstBatch.last;

  // Tools already ran inside askGroq(), so this is the model's final answer.
  const finalResult = result;

  // React to the triggering message, if the model wanted to.
  if (finalResult.react) {
    await message.react(finalResult.react).catch(() => {});
  }

  // Apply self_action, if the model wanted to fix/remove something it said
  // last turn. This only ever touches previousOwnMessage -- the one message
  // ID this function tracked as noname's own -- so there's no path for it
  // to reach a user's message even if the model tried. Re-verifying
  // .author.id === client.user.id here as well is redundant given how the
  // map is populated, but costs nothing and keeps the guarantee explicit
  // rather than implicit.
  if (finalResult.self_action) {
    console.log("[Groq] Model returned a self_action, attempting to apply:", finalResult.self_action);
    if (!previousOwnMessage) {
      console.warn("[Groq] self_action requested but there's no tracked own-message for this channel yet (bot restarted, or hasn't spoken here recently) -- nothing to act on:", finalResult.self_action);
    } else {
      try {
        const target = await message.channel.messages.fetch(previousOwnMessage.id).catch(() => null);
        if (!target) {
          console.warn(`[Groq] self_action target message ${previousOwnMessage.id} couldn't be fetched (deleted already? wrong channel?) -- ignoring`);
        } else if (target.author.id !== client.user.id) {
          console.warn(`[Groq] self_action target ${previousOwnMessage.id} isn't actually authored by the bot (tracking/ID mismatch) -- ignoring`);
        } else if (finalResult.self_action.type === "delete") {
          await target.delete();
          lastBotMessageByChannel.delete(message.channel.id);
        } else if (finalResult.self_action.type === "edit") {
          await target.edit({ content: finalResult.self_action.new_text });
          lastBotMessageByChannel.set(message.channel.id, { id: target.id, text: finalResult.self_action.new_text });
        }
      } catch (err) {
        console.error("[Groq] self_action failed:", err.message);
      }
    }
  }

  // Remember the newest message noname actually sent this turn, for next
  // turn's self_action / context line.
  if (lastSentMessage) {
    lastBotMessageByChannel.set(message.channel.id, { id: lastSentMessage.id, text: sentTexts[sentTexts.length - 1] });
  }

  // Join the requester's voice channel, if asked and possible.
  if (finalResult.join_voice) {
    try {
      const voiceChannel = message.member?.voice?.channel;
      if (!voiceChannel) {
        await message.channel.send("bro youre not even in a vc lol").catch(() => {});
      } else {
        const perms = voiceChannel.permissionsFor(message.guild.members.me);
        if (!perms?.has("Connect") || !perms?.has("Speak")) {
          await message.channel.send("bro i dont have perms to join/speak in that vc").catch(() => {});
        } else {
          let player = client.lavalink.getPlayer(message.guildId);
          if (!player) {
            player = client.lavalink.createPlayer({
              guildId:        message.guildId,
              voiceChannelId: voiceChannel.id,
              textChannelId:  message.channelId,
              selfDeaf:       true,
              selfMute:       false,
            });
          }
          if (!player.connected) await player.connect();
        }
      }
    } catch (err) {
      console.error("[Groq] join_voice failed:", err.message);
      await message.channel.send("bro i tried to join but something broke").catch(() => {});
    }
  }

  // Update the channel's rolling 3-message memory. Note that an image/voice
  // message was sent (rather than re-storing the URL or full transcript) --
  // the actual content is only ever sent to Groq on the turn it arrived.
  let memoryPrompt = prompt;
  if (imageUrls.length) memoryPrompt += ` [sent ${imageUrls.length} image(s)]`;
  if (audioAttachment)  memoryPrompt += " [sent a voice message]";
  pushMemory(message.channel.id, "user", memoryPrompt);
  if (sentTexts.length) pushMemory(message.channel.id, "assistant", sentTexts.join(" "));
}

// ─── "write me" coding mode (separate from noname chat) ─────────────────
// Two separate modes, chosen by the start of the message:
//
//   noname sup / yo noname / @noname ...   -> chat persona  (Groq; images -> stepfun-3.7-flash, handleNonameChat)
//   write me a discord bot in python       -> coding mode   (GLM-5.3 via
//   noname write me a discord bot in python                  NVIDIA, handleWriteMe)
//
// Coding mode skips the persona entirely: the request goes straight to the
// coder (utils/coder.js) and the finished work comes back as file attachments
// (one file as-is, a few side by side, or a project.zip). Attach code/text
// files -- or reply to a message that has them -- to have it read/modify them.
// It remembers the conversation (per user per channel): follow-ups like "add a
// login page" edit the earlier files. Just REPLYING to one of its answers (say, with a
// bug report) continues the same coding conversation too. "write me reset" starts fresh. Every answer
// ends with a footer showing the tokens the request used.
//
// Trigger = the message STARTS with "write me" (optionally after "noname",
// "hey/yo", or an @mention of the bot). Set WRITEME_NEEDS_NONAME=true in .env
// to only allow the "noname write me ..." form.
const WRITE_ME_RE = /^\s*(?:(?:hey|yo)\s+)?(?:noname\b[\s,:]*)?write\s+me\b[\s,:]*/i;
const WRITE_ME_NONAME_RE = /^\s*(?:(?:hey|yo)\s+)?noname\b[\s,:]*write\s+me\b[\s,:]*/i;

/** Returns the task text if `content` is a coding request, else null. */
function parseWriteMe(content, botId) {
  let text = (content || "").replace(new RegExp(`^\\s*<@!?${botId}>[\\s,:]*`), "");
  const re = process.env.WRITEME_NEEDS_NONAME === "true" ? WRITE_ME_NONAME_RE : WRITE_ME_RE;
  if (!re.test(text)) return null;
  // Keep the words after "write me" as part of the task ("write me a bot" -> "write a bot").
  return text.replace(re, "").trim() ? "Write me " + text.replace(re, "").trim() : "";
}

// Replying to one of the coder's answers continues the coding conversation (same model,
// same memory), so "it crashes with X" just works without typing "write me" again.
// A coder answer is recognised by its ids (this session) or by the "-# 🧮 tokens" footer
// every answer ends with (survives restarts). Start a reply with "noname" to chat instead.
const coderMessageIds = new Set();
function rememberCoderMessage(id) {
  coderMessageIds.add(id);
  if (coderMessageIds.size > 500) coderMessageIds.delete(coderMessageIds.values().next().value);
}
function isCoderMessage(ref, botId) {
  if (!ref || ref.author?.id !== botId) return false;
  return coderMessageIds.has(ref.id) || /^-# 🧮 /m.test(ref.content || "");
}

async function handleWriteMe(message, task, opts = {}) {
  if (!coder.isConfigured()) {
    return void message.reply("the coding AI isn't set up yet — the bot owner needs to add `NVIDIA_API_KEY` to the `.env` file.").catch(() => {});
  }
  if (!task) {
    return void message.reply("write you what? try `write me a python script that renames files`").catch(() => {});
  }

  // Memory: one conversation per user per channel. "write me reset" wipes it.
  const memoryKey = `${message.channelId}:${message.author.id}`;
  if (/^write me\s+(reset|clear|forget)(\s+(memory|chat|everything))?\s*[.!]?$/i.test(task)) {
    const had = coder.clearMemory(memoryKey);
    return void message.reply({ content: had ? "🧠 forgot our coding chat, fresh start." : "🧠 nothing to forget, we haven't coded here yet.", allowedMentions: { parse: [] } }).catch(() => {});
  }

  // Cooldown / concurrency (shared with /code).
  let release;
  try {
    release = coder.beginRun(message.author.id);
  } catch (err) {
    if (err instanceof coder.CoderUserError) {
      return void message.reply({ content: `⏳ ${err.message}`, allowedMentions: { parse: [] } }).catch(() => {});
    }
    throw err;
  }

  const typingTimer = setInterval(() => message.channel.sendTyping().catch(() => {}), 8000);
  typingTimer.unref?.();
  message.channel.sendTyping().catch(() => {});

  let status = null;
  let ticker = null;
  try {
    // Files from this message, plus files (and text) from the message being replied to.
    const attachments = [...message.attachments.values()];
    let fullTask = task;
    if (message.reference?.messageId) {
      const ref = opts.ref || await message.fetchReference().catch(() => null);
      // Replying to a coder answer whose memory we still have: the files + summary are
      // already remembered, so don't paste them into the prompt a second time.
      const alreadyRemembered = opts.replyToCoder && coder.hasMemory(memoryKey);
      if (ref && !alreadyRemembered) {
        attachments.push(...ref.attachments.values());
        if (ref.content?.trim()) {
          fullTask += `\n\n(The user is replying to this message:)\n${ref.content.trim().slice(0, 8000)}`;
        }
      }
    }
    const { files: inputFiles, skipped } = await coder.fetchTextAttachments(
      attachments
        .filter(a => !a.contentType?.startsWith("image/") && !a.contentType?.startsWith("audio/"))
        .map(a => ({ name: a.name, url: a.url, size: a.size, contentType: a.contentType }))
    );

    // Live status line: shows the current step + elapsed seconds and refreshes every
    // few seconds, so a slow model never looks frozen (purely cosmetic; edit errors ignored).
    status = await message.reply({ content: "⚙️ on it…", allowedMentions: { parse: [] } }).catch(() => null);
    ticker = coder.startProgressDisplay(text => {
      status?.edit({ content: text, allowedMentions: { parse: [] } }).catch(() => {});
    });
    const onProgress = ticker.update;

    const result = await coder.runCoder({ task: fullTask, inputFiles, onProgress, memoryKey });
    ticker.stop(); // stop before the final edit so a late tick can't overwrite the answer

    const notes = [];
    if (skipped) notes.push(`_${skipped} attachment${skipped > 1 ? "s were" : " was"} skipped (not readable text, or too big)._`);
    const header = result.files.length ? `📎 **${result.files.map(f => f.name).join(", ")}**` : "";
    // Token-usage footer always fits: trim the body, never the footer.
    const footer = coder.formatUsage(result);
    const body = [header, result.summary, ...notes].filter(Boolean).join("\n\n");
    const content = footer ? `${body.slice(0, 2000 - footer.length - 2)}\n\n${footer}` : body.slice(0, 2000);
    const payload = {
      content,
      files: result.files.map(f => ({ attachment: f.buffer, name: f.name })),
      allowedMentions: { parse: [] }, // model text must never be able to ping @everyone
    };

    try {
      const sent = status ? await status.edit(payload) : await message.reply(payload);
      if (sent?.id) rememberCoderMessage(sent.id);
    } catch (err) {
      // Usually a missing "Attach Files" permission or an oversized upload.
      console.error("[WriteMe] Couldn't attach the result:", err.message);
      const fallback = { content: "❌ i made the files but couldn't upload them here — check that i have the **Attach Files** permission in this channel.", allowedMentions: { parse: [] } };
      if (status) await status.edit(fallback).catch(() => {}); else await message.reply(fallback).catch(() => {});
    }
  } catch (err) {
    console.error("[WriteMe] Failed:", err.message);
    const msg = err instanceof coder.CoderUserError ? err.message : "couldn't reach the coding AI right now — try again in a moment.";
    const out = { content: `❌ ${msg}`, allowedMentions: { parse: [] } };
    if (status) await status.edit(out).catch(() => {}); else await message.reply(out).catch(() => {});
  } finally {
    ticker?.stop();
    clearInterval(typingTimer);
    release();
  }
}

// ─── DM inbox ───────────────────────────────────────────────────────────
// Any DM sent to the bot gets forwarded into a staff-configured channel (see
// /inboxset) as an embed -- sender, avatar, content, and any attachments
// (first image shown inline, all of them linked). The sender's own DM gets
// a ✅ react so they know it actually went somewhere instead of vanishing
// into a bot with no visible reply. Staff reply back out via /reply or
// /attachmentsend (both take a `user` option -- no threads, no state to
// track beyond "who do I reply to", which the picker/@mention already
// handles).
async function handleIncomingDm(message) {
  try {
    const channelId = getInboxChannelId();
    if (!channelId) {
      console.warn(`[Inbox] DM from ${message.author.tag} (${message.author.id}) received, but no inbox channel is set -- use /inboxset.`);
      return;
    }

    const inboxChannel = await message.client.channels.fetch(channelId).catch(() => null);
    if (!inboxChannel || !inboxChannel.isTextBased() || inboxChannel.isDMBased()) {
      console.warn(`[Inbox] Configured inbox channel (${channelId}) is missing, not text-based, or the bot can no longer see it.`);
      return;
    }

    const attachments = [...message.attachments.values()];
    const firstImage = attachments.find(a => a.contentType?.startsWith("image/"));

    const embed = new EmbedBuilder()
      .setAuthor({
        name: `${message.author.tag} (${message.author.id})`,
        iconURL: message.author.displayAvatarURL(),
      })
      .setDescription(message.content || "*(no text content)*")
      .setFooter({ text: "Reply with /reply or /attachmentsend" })
      .setTimestamp(message.createdAt);

    if (firstImage) embed.setImage(firstImage.url);
    if (attachments.length) {
      embed.addFields({
        name: `Attachment${attachments.length > 1 ? "s" : ""}`,
        value: attachments.map(a => `[${a.name}](${a.url})`).join("\n").slice(0, 1024),
      });
    }

    await inboxChannel.send({ embeds: [embed] });
    await message.react("✅").catch(() => {});
  } catch (err) {
    console.error("[Inbox] Failed to forward a DM:", err.message);
  }
}

client.on("messageCreate", async message => {
  if (message.author.bot) return;
  // Blocked users get zero response from anything -- commands (handled
  // separately in interactionCreate below), DMs, and noname chat all route
  // through this handler, so one check here covers the DM + guild paths at
  // once. Silent return, not an error message -- a "you're blocked"
  // notice just invites them to go find a workaround.
  if (isBlocked(message.author.id)) return;

  // DMs never have a guild -- route them to the inbox instead of falling
  // into the AFK/"noname" logic below, which is guild-only.
  if (!message.guild) {
    return handleIncomingDm(message);
  }

  // Feed the snipe cache before anything else -- needs to see every human
  // guild message, not just ones that go on to trigger AFK/noname logic.
  // Guarded on its own so a failure here (bad message shape, etc.) can
  // never take out AFK/noname handling below it for this message.
  try {
    recordMessage(message);
  } catch (err) {
    console.error("[Snipe] recordMessage threw:", err.message);
  }

  try {
    // If the author was AFK and just spoke, clear it and say welcome back.
    const returning = clearAfk(message.author.id);
    if (returning) {
      const notice = await message.reply({
        content: `👋 Welcome back, ${message.author}! I've removed your AFK status.`,
      }).catch(() => null);
      if (notice) setTimeout(() => notice.delete().catch(() => {}), 10_000);
    }

    // If this message pings anyone who's AFK, say so and clean up after 10s.
    const afkMentions = [...message.mentions.users.values()]
      .filter(u => !u.bot && u.id !== message.author.id)
      .map(u => ({ user: u, entry: getAfk(u.id) }))
      .filter(m => m.entry);

    if (afkMentions.length) {
      const lines = afkMentions.map(({ user, entry }) => {
        const since = Math.floor(entry.since / 1000);
        return `💤 **${user.username}** is AFK: ${entry.reason} (since <t:${since}:R>)`;
      });
      const notice = await message.reply({ content: lines.join("\n") }).catch(() => null);
      if (notice) setTimeout(() => notice.delete().catch(() => {}), 10_000);
    }

    // Mode 1 -- coding: message starts with "write me ..." / "noname write me ..."
    // -> GLM-5.3 (NVIDIA), answer comes back as files. Checked BEFORE
    // the chat trigger so "noname write me ..." never reaches the persona.
    const writeMeTask = parseWriteMe(message.content, client.user.id);
    if (writeMeTask !== null) {
      await handleWriteMe(message, writeMeTask);
      return;
    }

    // Mode 1b -- replying to one of the coder's answers (e.g. with a bug report) keeps
    // using the coder + its memory. Starting the reply with "noname" chats instead.
    if (message.reference?.messageId && !/^\s*(?:(?:hey|yo)\s+)?noname\b/i.test(message.content)) {
      const ref = await message.fetchReference().catch(() => null);
      if (isCoderMessage(ref, client.user.id)) {
        const text = message.content.replace(new RegExp(`^\\s*<@!?${client.user.id}>[\\s,:]*`), "").trim();
        await handleWriteMe(
          message,
          `Follow-up on your previous answer (bug report / change request):\n${text || "Something is broken — find and fix the bug(s) in the files above."}`,
          { ref, replyToCoder: true },
        );
        return;
      }
    }

    // Mode 2 -- chat: "noname" anywhere in the message / @mention / reply-to-bot -> ask Groq (noname persona).
    const mentionsNoname = NONAME_TEST.test(message.content);
    const mentionsBot = message.mentions.has(client.user);

    let repliedToBot = false;
    if (!mentionsNoname && message.reference?.messageId) {
      const referenced = await message.fetchReference().catch(() => null);
      repliedToBot = referenced?.author?.id === client.user.id;
    }

    if (mentionsNoname || mentionsBot || repliedToBot) {
      // Strip every "noname" occurrence and any bot @-mention out of the
      // message before handing it to Groq as the prompt -- the trigger word
      // isn't part of what the person is actually asking/saying.
      let prompt = message.content
        .replace(NONAME_WORD, " ")
        .replace(/<@!?\d+>/g, " ")
        .replace(/\s+/g, " ")
        .trim();

      // Trigger word/mention with nothing else said, or a bare reply --
      // still give Groq *something* to react to instead of silently doing
      // nothing.
      if (!prompt) prompt = message.content.trim() || "(no message content)";

      await handleNonameChat(message, prompt, client);
    }
  } catch (err) {
    console.error("[AFK] messageCreate handler error:", err.message);
  }
});

// ─── Edited-message detection ("ask something, edit the question" prank) ───
// Someone asks noname a leading question engineered to get a specific short
// reply (classically "say yes" -> bot replies "yes"), then edits their own
// message afterward to something unrelated/embarrassing (e.g. "r u gay lol")
// so it LOOKS like the bot answered that instead. Discord doesn't flag edits
// loudly enough for this to be obvious at a glance, so: if a message we
// tracked a reply for (nonameTriggerReplies, populated in handleNonameChat
// above) gets edited with actually-different text, call it out publicly
// with what the message originally said, and mark the bot's own reply with
// a ⚠️ react so it's visible without having to read the thread.
client.on("messageUpdate", async (oldMessage, newMessage) => {
  try {
    const tracked = nonameTriggerReplies.get(newMessage.id);
    if (!tracked) return; // we never replied to this message -- nothing to flag

    // messageUpdate can hand back a partial Message (missing .content) if
    // it wasn't in the client's cache -- fetch the full thing before
    // comparing content. The ORIGINAL text doesn't rely on this at all
    // (that's tracked.originalContent, snapshotted at reply time), only the
    // new/current text does.
    if (newMessage.partial) {
      newMessage = await newMessage.fetch().catch(() => null);
      if (!newMessage) return;
    }

    // Only react to an actual text change -- edits that don't touch content
    // (e.g. Discord silently re-rendering an embed/link unfurl) shouldn't
    // trigger a false "this was edited" callout.
    if (newMessage.content === tracked.originalContent) return;

    // Only ever flag the first edit for a given message, not every
    // subsequent one -- once it's been called out publicly, saying it again
    // on a second edit adds noise without adding information.
    nonameTriggerReplies.delete(newMessage.id);

    const original = tracked.originalContent?.trim();
    const quoted = original
      ? original.slice(0, 300).replace(/\n+/g, " ") + (original.length > 300 ? "…" : "")
      : "*(no text — just an attachment/embed)*";

    await newMessage.reply({
      content: `⚠️ heads up — this message was edited after I replied to it. it originally said:\n> ${quoted}`,
    }).catch(() => {});

    const replyMsg = await newMessage.channel.messages.fetch(tracked.replyId).catch(() => null);
    if (replyMsg) {
      await replyMsg.react("⚠️").catch(() => {});

      // Actually fall for the edit: ask Groq again as if this new text were
      // the real message, but with a note letting it know it's reacting to
      // an edit -- then replace noname's own original reply with that fresh
      // response, so it looks like the bot got fooled by the swap (the
      // public callout above is what gives away that it actually didn't).
      try {
        const editPrompt = `${newMessage.content}\n\n(the user edited the msg to this lol)`;
        const author = {
          username:    newMessage.author.username,
          displayName: newMessage.member?.displayName || newMessage.author.globalName || newMessage.author.username,
          id:          newMessage.author.id,
        };
        const editResult = await askGroq({
          prompt:  editPrompt,
          history: getMemory(newMessage.channel.id),
          author,
          useTools: false, // quick regenerate of a chat line -- no searching/coding here
        });
        const newText = editResult.messages?.[0]?.text;
        if (newText) await replyMsg.edit({ content: newText }).catch(() => {});
      } catch (err) {
        console.error("[Noname] Failed to regenerate edited-message reply:", err.message);
      }
    }
  } catch (err) {
    console.error("[Noname] messageUpdate handler error:", err.message);
  }
});

// ─── Graceful shutdown ─────────────────────────────────────────────────────────
// SIGTERM (host/orchestrator asking the process to stop -- redeploys,
// `docker stop`, Railway restarts) and SIGINT (Ctrl+C) previously had no
// handler at all, so even a routine, expected restart looked identical to a
// crash from the bot's perspective: playback just vanished with nothing
// recorded. This is likely the single most common cause of "it forgot what
// it was doing", since planned restarts happen far more often than crashes.
function gracefulShutdown(signal) {
  console.log(`[Process] Received ${signal} — snapshotting active sessions before exit.`);
  snapshotActiveSessions(client, `Bot restarted (${signal})`);
  process.exit(0);
}
process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT",  () => gracefulShutdown("SIGINT"));

// ─── Process-level error guards ───────────────────────────────────────────────
process.on("unhandledRejection",       reason => console.error("[Process] Unhandled Rejection:", reason));
process.on("uncaughtException",        err    => console.error("[Process] Uncaught Exception:", err));
process.on("uncaughtExceptionMonitor", err    => console.error("[Process] Uncaught Exception Monitor:", err));

const { loginClient } = require("./login");
loginClient(client).catch(() => {
  // Errors are already logged inside loginClient(). A rejected login()
  // (bad/revoked token) won't trigger the "never connected" watchdog on its
  // own since that timer is just checking whether `clientReady` ever fires
  // -- so make sure the process still exits and gets restarted rather than
  // hanging around logged-out.
  process.exit(1);
});