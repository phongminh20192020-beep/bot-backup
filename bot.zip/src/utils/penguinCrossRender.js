"use strict";

const { createCanvas } = require("@napi-rs/canvas");
const { INK, BG } = require("./canvasDoodle");

const MAX_LANES = 15;
const TILE = 32;
const PAD = 20;
const W = MAX_LANES * TILE + PAD * 2;
const H = 140;

function drawIceTile(ctx, x, y, cracked) {
  ctx.fillStyle = cracked ? "#bfe3ef" : "#dff1f7";
  ctx.fillRect(x, y, TILE - 4, TILE - 4);
  ctx.strokeStyle = "#8fc4d6";
  ctx.lineWidth = 1.5;
  ctx.strokeRect(x, y, TILE - 4, TILE - 4);
  if (cracked) {
    ctx.strokeStyle = "#5a90a6";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x + 4, y + 4);
    ctx.lineTo(x + TILE / 2, y + TILE / 2 - 2);
    ctx.lineTo(x + TILE - 8, y + 6);
    ctx.moveTo(x + TILE / 2, y + TILE / 2 - 2);
    ctx.lineTo(x + 8, y + TILE - 8);
    ctx.stroke();
  }
}

function drawPenguin(ctx, cx, cy, splash = false) {
  if (splash) {
    ctx.strokeStyle = "#3fb6d6";
    ctx.lineWidth = 2;
    for (const a of [0, 1, 2, 3]) {
      ctx.beginPath();
      const ang = (a / 4) * Math.PI * 2;
      ctx.moveTo(cx + Math.cos(ang) * 6, cy + Math.sin(ang) * 6);
      ctx.lineTo(cx + Math.cos(ang) * 14, cy + Math.sin(ang) * 14);
      ctx.stroke();
    }
    return;
  }

  // Body
  ctx.fillStyle = "#2b2d31";
  ctx.beginPath();
  ctx.ellipse(cx, cy, 11, 15, 0, 0, Math.PI * 2);
  ctx.fill();
  // Belly
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.ellipse(cx, cy + 2, 6.5, 10, 0, 0, Math.PI * 2);
  ctx.fill();
  // Beak
  ctx.fillStyle = "#e0a828";
  ctx.beginPath();
  ctx.moveTo(cx - 3, cy - 12);
  ctx.lineTo(cx + 3, cy - 12);
  ctx.lineTo(cx, cy - 7);
  ctx.closePath();
  ctx.fill();
  // Feet
  ctx.fillStyle = "#e0a828";
  ctx.beginPath();
  ctx.ellipse(cx - 5, cy + 15, 4, 2.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(cx + 5, cy + 15, 4, 2.5, 0, 0, Math.PI * 2);
  ctx.fill();
}

/**
 * @param {number} hopsDone - how many lanes cleared so far
 * @param {number|null} fellAt - lane index where the penguin fell, if it fell
 * @returns {Buffer} PNG image buffer
 */
function renderPenguinTrack(hopsDone, fellAt = null) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, H);

  const y = H / 2 - TILE / 2;

  for (let i = 0; i < MAX_LANES; i++) {
    const x = PAD + i * TILE;
    drawIceTile(ctx, x, y, fellAt === i);
  }

  const penguinLane = fellAt !== null ? fellAt : hopsDone;
  const px = PAD + penguinLane * TILE + (TILE - 4) / 2;
  const py = y + (TILE - 4) / 2;
  drawPenguin(ctx, px, py, fellAt !== null);

  ctx.fillStyle = INK;
  ctx.font = "12px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(`${hopsDone} / ${MAX_LANES} hops`, PAD, H - 10);

  return canvas.toBuffer("image/png");
}

module.exports = { renderPenguinTrack };
