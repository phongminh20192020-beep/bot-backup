"use strict";

const fs   = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "../../data");
const FILE     = path.join(DATA_DIR, "blocklist.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// Global block, not per-guild -- someone blocked shouldn't be able to just
// dodge it by DMing the bot or catching it in a different server it's in.
// Same load/persist/cache pattern as afkStore.js and inboxStore.js.
let cache = null;

function load() {
  if (cache) return cache;
  try {
    cache = fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE, "utf8")) : {};
  } catch (err) {
    console.error("[Blocklist] Failed to load blocklist.json, starting fresh:", err.message);
    cache = {};
  }
  return cache;
}

function persist() {
  try {
    fs.writeFileSync(FILE, JSON.stringify(cache, null, 2));
  } catch (err) {
    console.error("[Blocklist] Failed to save blocklist.json:", err.message);
  }
}

function blockUser(userId, reason, blockedBy) {
  const data = load();
  data[userId] = { reason: reason || "no reason given", blockedBy, blockedAt: Date.now() };
  persist();
  return data[userId];
}

/** Removes and returns the entry, or null if they weren't blocked. */
function unblockUser(userId) {
  const data = load();
  const entry = data[userId] ?? null;
  if (entry) {
    delete data[userId];
    persist();
  }
  return entry;
}

function isBlocked(userId) {
  return !!load()[userId];
}

function getBlockEntry(userId) {
  return load()[userId] ?? null;
}

/** { userId: { reason, blockedBy, blockedAt } } for everyone currently blocked. */
function listBlocked() {
  return load();
}

module.exports = { blockUser, unblockUser, isBlocked, getBlockEntry, listBlocked };
