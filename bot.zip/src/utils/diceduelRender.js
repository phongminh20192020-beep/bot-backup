"use strict";

const { createCanvas } = require("@napi-rs/canvas");
const { INK, BG, drawDie } = require("./canvasDoodle");

const W = 420;
const H = 200;
const DIE_SIZE = 70;
const DIE_GAP = 14;

function drawPair(ctx, centerX, y, values) {
  const totalW = DIE_SIZE * 2 + DIE_GAP;
  const startX = centerX - totalW / 2;
  drawDie(ctx, startX, y, DIE_SIZE, values[0]);
  drawDie(ctx, startX + DIE_SIZE + DIE_GAP, y, DIE_SIZE, values[1]);
}

/**
 * @param {[number,number]} playerDice
 * @param {[number,number]} dealerDice
 * @returns {Buffer} PNG image buffer
 */
function renderDiceDuel(playerDice, dealerDice) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, H);

  const y = (H - DIE_SIZE) / 2 + 6;

  drawPair(ctx, W * 0.27, y, playerDice);
  drawPair(ctx, W * 0.73, y, dealerDice);

  ctx.fillStyle = INK;
  ctx.font = "13px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("YOU", W * 0.27, y - 12);
  ctx.fillText("DEALER", W * 0.73, y - 12);

  ctx.font = "bold 16px sans-serif";
  ctx.fillText(`${playerDice[0] + playerDice[1]}`, W * 0.27, y + DIE_SIZE + 24);
  ctx.fillText(`${dealerDice[0] + dealerDice[1]}`, W * 0.73, y + DIE_SIZE + 24);

  ctx.strokeStyle = "#d0d0d0";
  ctx.lineWidth = 2;
  ctx.setLineDash([4, 4]);
  ctx.beginPath();
  ctx.moveTo(W / 2, 20);
  ctx.lineTo(W / 2, H - 20);
  ctx.stroke();
  ctx.setLineDash([]);

  return canvas.toBuffer("image/png");
}

module.exports = { renderDiceDuel };
