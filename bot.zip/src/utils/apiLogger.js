"use strict";

// Central in-memory log of outbound calls to third-party APIs (Groq,
// Wordnik, Google Translate, Musixmatch, LRCLIB, lyrics.ovh, Spotify,
// TTS...). Not persisted to disk -- this resets on every restart, same as
// the rest of the bot's in-memory state (sessions, memory, AFK, etc). It
// exists purely so /apilogs can answer "is X actually working right now /
// how slow is it / what broke recently" without digging through the
// process's stdout logs by hand.
const MAX_LOGS = 500;
const logs = []; // newest last; trimmed to MAX_LOGS

/**
 * Records one outbound API call.
 * @param {object} entry
 * @param {string} entry.api      - Short name of the API, e.g. "Groq", "Wordnik".
 * @param {string} entry.action   - What was being done, e.g. "chat completion", "get random word".
 * @param {boolean} entry.ok      - Whether the call succeeded.
 * @param {number} entry.ms       - Round-trip latency in milliseconds.
 * @param {string} [entry.detail] - Optional short extra context (status code, cache hit, etc).
 * @param {string} [entry.error]  - Optional error message, only set when ok is false.
 */
function logApiCall({ api, action, ok, ms, detail, error }) {
  logs.push({
    api,
    action,
    ok: !!ok,
    ms: Math.max(0, Math.round(ms) || 0),
    detail: detail || null,
    error: error || null,
    at: Date.now(),
  });
  if (logs.length > MAX_LOGS) logs.splice(0, logs.length - MAX_LOGS);
}

/**
 * Wraps an async function so every call is automatically timed and logged,
 * without the call site having to hand-roll try/timing/catch itself.
 * The wrapped function's return value and thrown errors pass through
 * unchanged -- this only observes, it never swallows anything.
 *
 * @param {string} api    - Short API name, shown in /apilogs.
 * @param {string} action - What this particular call does.
 * @param {Function} fn   - The async function to wrap.
 * @param {(...args: any[]) => string} [detailFn] - Optional: derive a short
 *   `detail` string from the call's arguments (e.g. the word being looked up).
 */
function withApiLog(api, action, fn, detailFn) {
  return async function wrapped(...args) {
    const start = Date.now();
    try {
      const result = await fn(...args);
      logApiCall({ api, action, ok: true, ms: Date.now() - start, detail: detailFn?.(...args) });
      return result;
    } catch (err) {
      logApiCall({ api, action, ok: false, ms: Date.now() - start, detail: detailFn?.(...args), error: err.message });
      throw err;
    }
  };
}

/** Most recent N log entries, newest first. */
function getRecentLogs(limit = 20) {
  return logs.slice(-limit).reverse();
}

/**
 * Per-API rollup: call count, success/failure counts, average latency, and
 * the timestamp of the most recent call -- what /apilogs shows by default.
 */
function getApiStats() {
  const byApi = new Map();
  for (const entry of logs) {
    if (!byApi.has(entry.api)) {
      byApi.set(entry.api, { api: entry.api, calls: 0, ok: 0, failed: 0, totalMs: 0, lastAt: 0, lastOk: true, lastError: null });
    }
    const s = byApi.get(entry.api);
    s.calls++;
    s.totalMs += entry.ms;
    if (entry.ok) s.ok++;
    else s.failed++;
    if (entry.at >= s.lastAt) {
      s.lastAt = entry.at;
      s.lastOk = entry.ok;
      s.lastError = entry.error;
    }
  }
  return [...byApi.values()]
    .map(s => ({ ...s, avgMs: Math.round(s.totalMs / s.calls) }))
    .sort((a, b) => b.lastAt - a.lastAt);
}

function clearLogs() {
  logs.length = 0;
}

module.exports = { logApiCall, withApiLog, getRecentLogs, getApiStats, clearLogs };
