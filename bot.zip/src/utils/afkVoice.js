"use strict";

// ─── AFK voice (Lavalink-independent) ─────────────────────────────────────────
// /afk previously kept a real Lavalink player alive doing nothing, which
// meant AFK mode's uptime was only as reliable as the Lavalink node's
// connection -- every fix in utils/afk.js was chasing that dependency.
//
// This replaces that: AFK mode now uses @discordjs/voice directly, joining
// the voice channel over the bot's own Discord Gateway connection with no
// Lavalink player involved at all. Lavalink is only needed while music is
// actually playing; AFK "just sit here" has nothing to do with it anymore.
//
// @discordjs/voice's own connection state machine handles reconnects for
// resumable session drops automatically. For the unresumable case (full
// disconnect), the listener below just rejoins from scratch -- forever,
// until leaveAfkChannel() is called (which is the ONLY thing that sets the
// "intentional" flag), same "only leave via /disconnect" guarantee as before.

const { joinVoiceChannel, VoiceConnectionStatus, entersState, getVoiceConnection } = require("@discordjs/voice");

const intentionalLeaves = new Set(); // guildIds currently being deliberately left

function joinAfkChannel(client, guild, voiceChannel) {
  intentionalLeaves.delete(guild.id);

  const connection = joinVoiceChannel({
    channelId:      voiceChannel.id,
    guildId:        guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf:       true,
    selfMute:       false,
  });

  connection.on(VoiceConnectionStatus.Disconnected, async () => {
    if (intentionalLeaves.has(guild.id)) return; // /disconnect is handling this

    try {
      // A resumable drop recovers on its own within a few seconds -- give it
      // a chance before treating this as a real disconnect.
      await Promise.race([
        entersState(connection, VoiceConnectionStatus.Signalling, 5000),
        entersState(connection, VoiceConnectionStatus.Connecting, 5000),
      ]);
    } catch {
      if (intentionalLeaves.has(guild.id)) return;
      console.log(`[AFK] Voice connection dropped guild=${guild.id} — rejoining.`);
      connection.destroy();
      const freshChannel = client.channels.cache.get(voiceChannel.id);
      if (freshChannel) joinAfkChannel(client, guild, freshChannel);
      else console.warn(`[AFK] Can't rejoin guild=${guild.id} — channel no longer exists.`);
    }
  });

  connection.on("error", err => console.error(`[AFK] Voice connection error guild=${guild.id}:`, err.message));

  return connection;
}

function leaveAfkChannel(guildId) {
  intentionalLeaves.add(guildId);
  const connection = getVoiceConnection(guildId);
  connection?.destroy();
  setTimeout(() => intentionalLeaves.delete(guildId), 10_000); // don't leak this Set forever
}

function isInAfkVoice(guildId) {
  const connection = getVoiceConnection(guildId);
  return !!connection && connection.state.status !== VoiceConnectionStatus.Destroyed;
}

module.exports = { joinAfkChannel, leaveAfkChannel, isInAfkVoice };