"use strict";

const { createCanvas } = require("@napi-rs/canvas");

// Canvas-drawn Wordle board, replacing the old emoji-square + backtick-letter
// rows. Transparent background so it sits naturally inside the embed instead
// of carrying its own color block.

const TILE    = 62;
const GAP     = 8;
const PADDING = 14;

const COLORS = {
  green:  "#6aaa64",
  yellow: "#c9b458",
  gray:   "#3a3a3c",
};
const EMPTY_BORDER = "#565758";
const LETTER_COLOR = "#ffffff";

function roundRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y,     x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x,     y + h, r);
  ctx.arcTo(x,     y + h, x,     y,     r);
  ctx.arcTo(x,     y,     x + w, y,     r);
  ctx.closePath();
}

/**
 * @param {{letters: string, colors: ("green"|"yellow"|"gray")[]}[]} rows - guesses made so far, in order.
 * @param {number} wordLength
 * @param {number} maxGuesses
 * @returns {Buffer} PNG image buffer.
 */
function renderWordleImage(rows, wordLength, maxGuesses) {
  const width  = PADDING * 2 + wordLength * TILE + (wordLength - 1) * GAP;
  const height = PADDING * 2 + maxGuesses * TILE + (maxGuesses - 1) * GAP;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, width, height);

  for (let r = 0; r < maxGuesses; r++) {
    const row = rows[r];
    for (let c = 0; c < wordLength; c++) {
      const x = PADDING + c * (TILE + GAP);
      const y = PADDING + r * (TILE + GAP);

      roundRectPath(ctx, x, y, TILE, TILE, 8);
      if (row) {
        ctx.fillStyle = COLORS[row.colors[c]];
        ctx.fill();
      } else {
        ctx.lineWidth = 3;
        ctx.strokeStyle = EMPTY_BORDER;
        ctx.stroke();
      }

      if (row) {
        ctx.fillStyle = LETTER_COLOR;
        ctx.font = "bold 30px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(row.letters[c].toUpperCase(), x + TILE / 2, y + TILE / 2 + 2);
      }
    }
  }

  return canvas.toBuffer("image/png");
}

module.exports = { renderWordleImage };
