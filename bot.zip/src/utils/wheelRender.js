"use strict";

const { createCanvas } = require("@napi-rs/canvas");

const SIZE = 380;
const CX = SIZE / 2;
const CY = SIZE / 2;
const RADIUS = 165;

const INK = "#1b1b1f";
const BG  = "#ffffff";

/**
 * @param {{ color: string, hex: string }[]} segments - one entry per wedge, in order
 * @param {number} landingIndex - which segment the pointer lands on
 * @returns {Buffer} PNG image buffer
 */
function renderWheel({ segments, landingIndex }) {
  const canvas = createCanvas(SIZE, SIZE);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, SIZE, SIZE);

  const n = segments.length;
  const anglePer = (Math.PI * 2) / n;

  // Rotate so the landing segment's center sits under the pointer (top, -90deg)
  const rotation = -Math.PI / 2 - (landingIndex + 0.5) * anglePer;

  for (let i = 0; i < n; i++) {
    const start = rotation + i * anglePer;
    const end = start + anglePer;
    ctx.beginPath();
    ctx.moveTo(CX, CY);
    ctx.arc(CX, CY, RADIUS, start, end);
    ctx.closePath();
    ctx.fillStyle = segments[i].hex;
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  // Hub
  ctx.beginPath();
  ctx.arc(CX, CY, 14, 0, Math.PI * 2);
  ctx.fillStyle = INK;
  ctx.fill();

  // Pointer (fixed at top)
  ctx.beginPath();
  ctx.moveTo(CX - 12, CY - RADIUS - 6);
  ctx.lineTo(CX + 12, CY - RADIUS - 6);
  ctx.lineTo(CX, CY - RADIUS + 16);
  ctx.closePath();
  ctx.fillStyle = INK;
  ctx.fill();

  // Outer ring
  ctx.beginPath();
  ctx.arc(CX, CY, RADIUS, 0, Math.PI * 2);
  ctx.strokeStyle = INK;
  ctx.lineWidth = 4;
  ctx.stroke();

  return canvas.toBuffer("image/png");
}

module.exports = { renderWheel };
