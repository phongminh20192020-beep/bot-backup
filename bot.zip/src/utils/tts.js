"use strict";

const { spawn } = require("child_process");

const SPEECH_ENDPOINT = "https://api.groq.com/openai/v1/audio/speech";
// canopylabs/orpheus-v1-english is Groq's current English TTS model (their
// "playai-tts" line was decommissioned). The full English voice roster is:
// autumn, diana, hannah (female-leaning), austin, daniel, troy (male-leaning).
// Defaulting to "daniel" here; swap via GROQ_TTS_VOICE in .env if you want a
// different one (e.g. "austin" or "troy" for other male-leaning options).
// See https://console.groq.com/docs/text-to-speech/orpheus for the full voice list.
const TTS_MODEL = "canopylabs/orpheus-v1-english" || "canopylabs/orpheus-v1-english";
const TTS_VOICE = "daniel" || "daniel";

// Groq's speech endpoint hard-caps `input` at 200 characters per request.
// Longer replies get split on sentence boundaries into chunks under this
// limit, synthesized separately, and stitched back into one clip.
const MAX_CHARS_PER_CHUNK = 190;

const PCM_SAMPLE_RATE = 48000; // required by @discordjs/voice
const PCM_CHANNELS    = 2;

/**
 * Split text into chunks that each fit Groq TTS's 200-char limit, breaking
 * on sentence boundaries where possible so chunks don't cut off mid-word.
 */
function chunkTextForSpeech(text, maxLen = MAX_CHARS_PER_CHUNK) {
  const clean = text.trim();
  if (!clean) return [];
  if (clean.length <= maxLen) return [clean];

  const sentences = clean.match(/[^.!?]+[.!?]*\s*/g) || [clean];
  const chunks = [];
  let current = "";

  for (const sentence of sentences) {
    if ((current + sentence).length > maxLen) {
      if (current.trim()) chunks.push(current.trim());
      // A single sentence longer than the whole limit still needs a hard split.
      if (sentence.trim().length > maxLen) {
        for (let i = 0; i < sentence.length; i += maxLen) {
          chunks.push(sentence.slice(i, i + maxLen).trim());
        }
        current = "";
      } else {
        current = sentence;
      }
    } else {
      current += sentence;
    }
  }
  if (current.trim()) chunks.push(current.trim());
  return chunks.filter(Boolean);
}

/** One Groq TTS call for a single chunk (must already be <=200 chars). Returns a WAV Buffer. */
async function synthesizeChunk(text) {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) throw new Error("GROQ_API_KEY is not set — add it to your .env file.");

  const res = await fetch(SPEECH_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type":  "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: TTS_MODEL,
      input: text,
      voice: TTS_VOICE,
      response_format: "wav",
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`Groq TTS error ${res.status}: ${errText.slice(0, 300)}`);
  }

  return Buffer.from(await res.arrayBuffer());
}

/** Decode a WAV buffer to raw PCM (s16le, 48kHz, stereo) via ffmpeg, for Discord playback. */
function wavToPcm(wavBuffer) {
  return new Promise((resolve, reject) => {
    const ff = spawn("ffmpeg", [
      "-hide_banner", "-loglevel", "error",
      "-i", "pipe:0",
      "-f", "s16le",
      "-ar", String(PCM_SAMPLE_RATE),
      "-ac", String(PCM_CHANNELS),
      "pipe:1",
    ]);

    const outChunks = [];
    const errChunks = [];
    ff.stdout.on("data", d => outChunks.push(d));
    ff.stderr.on("data", d => errChunks.push(d));
    ff.on("error", reject);
    ff.on("close", code => {
      if (code !== 0) return reject(new Error(`ffmpeg exited ${code}: ${Buffer.concat(errChunks).toString().slice(0, 300)}`));
      resolve(Buffer.concat(outChunks));
    });

    ff.stdin.write(wavBuffer);
    ff.stdin.end();
  });
}

/**
 * Synthesize speech for arbitrary-length text and return one raw PCM buffer
 * (s16le, 48kHz, stereo) ready to hand to @discordjs/voice's createAudioResource.
 * @param {string} text
 * @returns {Promise<Buffer|null>} null if there was nothing to say
 */
async function synthesizeSpeech(text) {
  const chunks = chunkTextForSpeech(text);
  if (!chunks.length) return null;

  const pcmParts = [];
  for (const chunk of chunks) {
    const wav = await synthesizeChunk(chunk);
    pcmParts.push(await wavToPcm(wav));
  }
  return Buffer.concat(pcmParts);
}

module.exports = { synthesizeSpeech, chunkTextForSpeech, wavToPcm, PCM_SAMPLE_RATE, PCM_CHANNELS };