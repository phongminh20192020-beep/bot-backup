"use strict";

// ─── Coding AI ───────────────────────────────────────────────────────────────
// A tool-using coding agent that delivers its work as FILES instead of chat
// text. It runs GLM-5.3 on the NVIDIA API (build.nvidia.com), using the official
// `openai` SDK (NVIDIA's API is OpenAI-compatible):
//
//   const client = new OpenAI({
//     baseURL: "https://integrate.api.nvidia.com/v1",
//     apiKey:  process.env.NVIDIA_API_KEY,   // <- lives in .env  (starts with nvapi-)
//   });
//
// How a request flows:
//   1. The model is given tools (write_file / read_file / list_files /
//      web_search) and told to put ALL code into files, never into chat. When
//      it writes a file it states the NAME and TAIL (extension) as separate
//      fields -- it never assembles the final filename itself. The output
//      system joins them (name + "." + tail) and is what actually saves the
//      file, e.g. the model says name:"bot", tail:"py" and the system writes
//      bot.py.
//   2. We run its tool calls against a workspace that is backed by a
//      persistent folder on real disk (see OUTPUT_DIR below), so files survive
//      restarts and the model can read_file / edit anything written in an
//      earlier request, then loop until it stops calling tools.
//   3. Files come back as Discord-ready attachments: one file is sent as-is, a
//      few flat files are sent side by side, and anything bigger or with folders
//      is bundled into project.zip. By default everything the model wrote is sent;
//      it can also call send_file to pick EXACTLY which files reach the chat
//      (including binary files it wrote with encoding:"base64", files the user
//      attached, or files from earlier in the conversation).
//
// Used by the "write me ..." / "noname write me ..." text triggers (index.js)
// AND the /code slash command, so both share the same limits and cooldowns.
// The chat persona ("noname ...", on Groq / NaraRouter) does NOT use this -- coding is its
// own separate mode.

const fs = require("fs");
const path = require("path");

const { withApiLog } = require("./apiLogger");
const { searchGoogle } = require("./websearch");
const { isOwner } = require("./owners");
const { buildZip } = require("./zip");

const OpenAIModule = require("openai");
// `openai` ships a CommonJS build; depending on version the constructor is the
// module itself, `.OpenAI`, or `.default`. This handles all of them.
const OpenAI = OpenAIModule.OpenAI || OpenAIModule.default || OpenAIModule;

// ─── Config ─────────────────────────────────────────────────────────────────
const DEFAULT_BASE_URL = "https://integrate.api.nvidia.com/v1";
const DEFAULT_MODEL    = "z-ai/glm-5.3";   // NVIDIA catalog slug is "glm-5-3"; the API id has dots

// NVIDIA's catalog URLs (glm-5-3) differ from the API model ids (z-ai/glm-5.3). Accept
// either spelling in NVIDIA_CODER_MODEL and translate to the real id. Anything not
// listed here is sent exactly as written, so any other model id still works.
const MODEL_ALIASES = {
  "glm-5-3":         "z-ai/glm-5.3",
  "glm-5.3":         "z-ai/glm-5.3",
  "z-ai/glm-5-3":    "z-ai/glm-5.3",
  "glm-5-3-flash":   "z-ai/glm-5.3-flash",
  "glm-5.3-flash":   "z-ai/glm-5.3-flash",
  "z-ai/glm-5-3-flash": "z-ai/glm-5.3-flash",
  "kimi-k3":         "moonshotai/kimi-k3",
};
function resolveModel(name) {
  const trimmed = String(name || "").trim();
  return MODEL_ALIASES[trimmed.toLowerCase()] || trimmed;
}

const MAX_TOOL_ROUNDS     = 10;               // model <-> tool round trips per request
const MAX_RUN_MS          = 4 * 60_000;       // hard wall-clock cap per request
// Output cap per model call. GLM-5.3 thinks before it answers and those reasoning
// tokens count too, so leave plenty of room. Override with NVIDIA_CODER_MAX_TOKENS.
const MAX_OUTPUT_TOKENS   = Number(process.env.NVIDIA_CODER_MAX_TOKENS) || 16_000;
// Thinking level sent as reasoning_effort (low / medium / high / max). "off" = don't send it.
// Lower = faster and less rambling before it writes anything. Override with NVIDIA_CODER_REASONING.
const CODER_REASONING     = () => process.env.NVIDIA_CODER_REASONING || "low";
const MAX_SEARCHES        = 3;                // web_search calls per request

const MAX_FILES           = 25;               // files the model may write
const MAX_FILE_BYTES      = 1_000_000;        // per written file
const MAX_TOTAL_BYTES     = 8_000_000;        // stays under Discord's upload cap
const MAX_SEPARATE_FILES  = 10;               // Discord: 10 attachments per message

const MAX_INPUT_FILES      = 5;               // user-attached files fed in
const MAX_INPUT_FILE_BYTES = 200_000;
const INLINE_INPUT_CHARS   = 30_000;          // bigger inputs are read via read_file

const COOLDOWN_MS    = 20_000;                // per non-owner user
const MAX_CONCURRENT = 2;                     // simultaneous runs, whole bot

// ─── Persistent output folder ──────────────────────────────────────────────
// Every file the coder writes is saved for real here on disk (project root by
// default), not just held in memory for one request. That means:
//   - the model can read_file / edit anything it (or the user) wrote earlier,
//     across separate requests and even bot restarts
//   - the *name* + *tail* the model states are the only things it controls;
//     this code is what joins them into a real filename and writes the file
// Override the location with CODER_OUTPUT_DIR in .env if you want it elsewhere.
const OUTPUT_DIR = path.resolve(process.env.CODER_OUTPUT_DIR || path.join(__dirname, "..", "..", "generated"));
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

function diskPath(scope, relPath) {
  return path.join(OUTPUT_DIR, scope, ...relPath.split("/"));
}

/** Turns a memoryKey ("channelId:userId") into a safe folder name. Falls back to "shared" when there's none. */
function sanitizeScope(key) {
  const s = String(key || "shared").replace(/[^a-zA-Z0-9_-]+/g, "_").slice(0, 120);
  return s || "shared";
}

/** Reads every file already sitting in this scope's folder into a workspace-style Map (path -> content). */
function loadExistingFiles(scope) {
  const files = new Map();
  const base = path.join(OUTPUT_DIR, scope);
  (function walk(dir, prefix) {
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const rel = prefix ? `${prefix}/${e.name}` : e.name;
      if (e.isDirectory()) { walk(path.join(dir, e.name), rel); continue; }
      try {
        const buf = fs.readFileSync(path.join(dir, e.name));
        files.set(rel, buf.includes(0) ? buf : buf.toString("utf8")); // NUL byte => treat as binary
      } catch { /* unreadable file, skip it */ }
    }
  })(base, "");
  return files;
}

/** Writes (or overwrites) one file for real under this scope's folder, creating subfolders as needed. */
function persistToDisk(scope, relPath, data) {
  const full = diskPath(scope, relPath);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, data);
}

/** Error whose message is safe to show directly to the user. */
class CoderUserError extends Error {}
/** Thrown when NVIDIA_API_KEY is missing. */
class CoderConfigError extends Error {
  constructor(msg) { super(msg); this.code = "NO_KEY"; }
}

let _client = null;
let _clientKey = null;
function getClient() {
  const apiKey = process.env.NVIDIA_API_KEY;
  if (!apiKey) throw new CoderConfigError("NVIDIA_API_KEY is not set — add it to your .env file.");
  if (!_client || _clientKey !== apiKey) {
    _client = new OpenAI({
      baseURL: process.env.NVIDIA_BASE_URL || DEFAULT_BASE_URL,
      apiKey,
      timeout: 240_000, // a big reasoning model can think for a while
      maxRetries: 2,
    });
    _clientKey = apiKey;
  }
  return _client;
}

function isConfigured() {
  return !!process.env.NVIDIA_API_KEY;
}

// ─── Access control: cooldown + concurrency (shared by /code and "write me") ──
const cooldowns = new Map(); // userId -> ms timestamp they can run again
let activeRuns = 0;

/**
 * Claim a run slot. Throws CoderUserError (safe to show) if the user isn't
 * allowed or the coder is busy. Returns a release() function -- always call it
 * in a `finally`.
 */
function beginRun(userId) {
  const owner = userId ? isOwner(userId) : false;

  if (process.env.CODER_OWNER_ONLY === "true" && !owner) {
    throw new CoderUserError("the coding tool is owner-only right now.");
  }
  if (!owner && userId) {
    const readyAt = cooldowns.get(userId) || 0;
    if (Date.now() < readyAt) {
      throw new CoderUserError(`slow down — you can use the coder again <t:${Math.ceil(readyAt / 1000)}:R>.`);
    }
  }
  if (activeRuns >= MAX_CONCURRENT) {
    throw new CoderUserError("the coder is busy with other requests right now — try again in a minute.");
  }

  activeRuns++;
  if (!owner && userId) {
    cooldowns.set(userId, Date.now() + COOLDOWN_MS);
    setTimeout(() => {
      if ((cooldowns.get(userId) || 0) <= Date.now()) cooldowns.delete(userId);
    }, COOLDOWN_MS + 1000).unref?.();
  }

  let released = false;
  return function release() {
    if (released) return;
    released = true;
    activeRuns = Math.max(0, activeRuns - 1);
  };
}

// ─── Tool definitions the coding model can call ───────────────────────────────
const CODER_TOOLS = [
  {
    type: "function",
    function: {
      name: "write_file",
      description:
        "Create or overwrite a file. Give its NAME and TAIL (extension) as two separate fields -- you never build the final " +
        "filename yourself. The output system joins them (name + '.' + tail) and saves the real file to disk in the persistent " +
        "output folder, where it will still be there for later requests. Files you write are delivered to the user in the chat " +
        "as attachments (unless you use send_file to choose exactly which ones). Always write the COMPLETE file contents. " +
        "For binary files (png, jpg, pdf, zip, docx, xlsx...) pass the bytes as base64 and set encoding to 'base64'; keep those small.",
      parameters: {
        type: "object",
        properties: {
          name:    { type: "string", description: "File name WITHOUT the extension, e.g. 'bot' or 'src/app'. Can include subfolders. No absolute paths, no '..'." },
          tail:    { type: "string", description: "The file's tail/extension WITHOUT the dot, e.g. 'py', 'js', 'md'." },
          content: { type: "string", description: "The full content of the file (plain text, or base64 when encoding is 'base64')." },
          encoding: { type: "string", enum: ["utf8", "base64"], description: "How 'content' is encoded. Default 'utf8' (plain text)." },
        },
        required: ["name", "tail", "content"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "edit_file",
      description:
        "Make a small change to an EXISTING text file WITHOUT retyping the whole thing -- much cheaper than write_file for a " +
        "one-line fix or a small tweak. Give the exact text to find (old_str) and what to replace it with (new_str). old_str " +
        "must match the file's current content exactly, byte for byte (copy it from read_file/list_files output -- don't " +
        "retype it from memory), and must appear exactly once in the file; add a bit of surrounding context to old_str if it " +
        "isn't unique. For anything bigger than a small, localized change, or for a brand-new file, use write_file instead. " +
        "For PURE insertion (adding new line(s) without replacing anything), use add_line instead -- it doesn't need old_str.",
      parameters: {
        type: "object",
        properties: {
          path:    { type: "string", description: "Path of the existing file to edit, exactly as shown in list_files (e.g. 'bot.py' or 'src/app.js')." },
          old_str: { type: "string", description: "The exact existing text to find and replace. Must appear exactly once in the file." },
          new_str: { type: "string", description: "The text to put in its place. Use an empty string to delete old_str." },
        },
        required: ["path", "old_str", "new_str"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "add_line",
      description:
        "Insert one or more brand-new lines into an EXISTING text file WITHOUT retyping the file and WITHOUT needing to match " +
        "any existing text -- use this for pure additions (a new import, a new function, a new entry) rather than edit_file, " +
        "which is for replacing something that's already there. Cheaper than write_file for the same reason edit_file is.",
      parameters: {
        type: "object",
        properties: {
          path:       { type: "string", description: "Path of the existing file to add to, exactly as shown in list_files." },
          content:    { type: "string", description: "The line (or lines, separated by \\n) to insert." },
          after_line: { type: "integer", description: "1-indexed line number to insert AFTER (0 = insert before the first line). Omit to append at the very end of the file." },
        },
        required: ["path", "content"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "send_file",
      description:
        "Send a workspace file to the chat as an attachment. Call it once per file you want the user to receive. " +
        "Works for files you wrote, files the user attached, and files from earlier in the conversation. " +
        "If you never call send_file, every file you wrote is sent automatically; once you call it, ONLY the files you sent are delivered.",
      parameters: {
        type: "object",
        properties: { path: { type: "string", description: "Path of the workspace file to send, exactly as in list_files." } },
        required: ["path"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "read_file",
      description: "Read a file from the workspace -- files the user attached, files you wrote this run, or files saved in the persistent output folder from an earlier request.",
      parameters: {
        type: "object",
        properties: { path: { type: "string", description: "Path of the file to read." } },
        required: ["path"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "list_files",
      description: "List every file currently in the workspace with its size, including files saved in the persistent output folder from earlier requests.",
      parameters: { type: "object", properties: {} },
    },
  },
  {
    type: "function",
    function: {
      name: "web_search",
      description: "Search the web for current documentation or API details you're unsure about. Use sparingly.",
      parameters: {
        type: "object",
        properties: { query: { type: "string", description: "Short search query." } },
        required: ["query"],
      },
    },
  },
];

const CODER_SYSTEM_PROMPT = `
You are a senior software engineer working inside a Discord bot (people ask you with "write me ..."). People can't easily copy code out of a chat, so you deliver everything as FILES.

Rules:
- Put every piece of code in a file using the write_file tool. NEVER paste code or file contents into your chat reply.
- write_file takes a NAME and a TAIL (extension) as separate fields, not one path string -- e.g. name:"bot", tail:"py". You just state what the name and tail are; the output system is what joins them into the real file (bot.py) and saves it to disk. Pick clear names and real extensions (main/py, src/index/js, README/md). Use the fewest files that make a clean solution; add a README only when setup steps are needed.
- Every file lives in one persistent output folder on real disk, shared across ALL requests -- not just this conversation. It doesn't disappear when the run ends or the bot restarts.
- Files are delivered to the chat as attachments. By default everything you write_file is sent. Call send_file(path) when you want to control what the user receives (skip scratch/helper files, or re-send a file the user attached or an earlier one). Once you use send_file, only the files you sent are delivered.
- For binary files (images, pdf, zip, docx...) use write_file with encoding "base64" (small files only). Prefer plain-text formats when you can.
- Your final chat reply is only a short summary (a few sentences): what you built, how to run it, and any important assumption.
- To edit an existing file (one the user attached, or one already sitting in the output folder from an earlier request): use add_line to insert new line(s) without replacing anything (a new import, a new function, a new entry); use edit_file to replace/change existing text; only fall back to write_file (with the FULL updated content) for a rewrite big enough that those two get impractical. Requests like "add X" or "fix it" refer to files already in the folder -- check list_files.
- Write complete, working code. No placeholders, no "rest of the code here".
- Keep it lean: build exactly what was asked, nothing more. Don't add extra features, config options, error handling, or abstractions the user didn't ask for. Skip comments that just restate the code; only comment on things that are genuinely non-obvious. A short, working file beats a long, defensive one.
- Use web_search only when you truly need current docs or API details.
- If the request isn't about code, answer in one or two sentences and write no files.
`.trim();

// ─── Workspace helpers ──────────────────────────────────────────────────────────
function normalizePath(raw) {
  if (typeof raw !== "string") return null;
  const p = raw.trim().replace(/\\/g, "/").replace(/^(\.\/)+/, "");
  if (!p || p.length > 120 || p.startsWith("/") || /^[a-zA-Z]:/.test(p)) return null;
  if (/[\u0000-\u001f<>:"|?*]/.test(p)) return null;
  const parts = p.split("/");
  if (parts.length > 6 || parts.some(s => s === "" || s === "." || s === "..")) return null;
  return parts.join("/");
}

function byteLen(v) {
  return Buffer.isBuffer(v) ? v.length : Buffer.byteLength(v, "utf8");
}

function parseArgs(raw) {
  if (raw && typeof raw === "object") return raw;
  try { return JSON.parse(raw || "{}"); } catch { return null; }
}

/** Shared bookkeeping for actually saving a new version of a file: size caps, disk persistence, ws state. */
function commitFile(ws, p, data) {
  const size = byteLen(data);
  if (size > MAX_FILE_BYTES) return { error: `ERROR: file too large (${size} bytes, max ${MAX_FILE_BYTES}). Split it up.` };
  if (!ws.files.has(p) && ws.written.size >= MAX_FILES) return { error: `ERROR: too many files (max ${MAX_FILES}). Combine some.` };

  const previous = ws.files.has(p) ? byteLen(ws.files.get(p)) : 0;
  if (ws.totalWritten - (ws.written.has(p) ? previous : 0) + size > MAX_TOTAL_BYTES) {
    return { error: "ERROR: total output too large. Write less code." };
  }

  try {
    persistToDisk(ws.scope, p, data);
  } catch (err) {
    return { error: `ERROR: could not save to the output folder (${err.message}).` };
  }

  if (ws.written.has(p)) ws.totalWritten -= previous;
  ws.files.set(p, data);
  ws.written.add(p);
  ws.totalWritten += size;
  return { size };
}

/** Executes one coding-model tool call against the workspace. Always returns a string. */
async function execCoderTool(name, rawArgs, ws) {
  const args = parseArgs(rawArgs);
  if (!args) {
    return "ERROR: tool arguments were not valid JSON (the file may be too long for one call). Split it into smaller files and try again.";
  }

  switch (name) {
    case "write_file": {
      const rawName = typeof args.name === "string" ? args.name.trim() : "";
      const rawTail = typeof args.tail === "string" ? args.tail.trim().replace(/^\.+/, "") : "";
      if (!rawName) return "ERROR: 'name' is required -- the file name WITHOUT its extension, e.g. 'bot' or 'src/app'.";
      if (!rawTail || !/^[A-Za-z0-9]{1,12}$/.test(rawTail)) {
        return "ERROR: 'tail' is required -- the extension with no dot and no path separators, e.g. 'py', 'js', 'md'.";
      }
      const p = normalizePath(`${rawName}.${rawTail}`);
      if (!p) return "ERROR: invalid name. Use a relative name like 'main' or 'src/app' (no '..', no absolute paths).";
      if (typeof args.content !== "string") return "ERROR: 'content' must be a string with the full file text.";

      let data = args.content;
      if (args.encoding === "base64") {
        const b64 = args.content.replace(/\s+/g, "");
        if (!b64 || !/^[A-Za-z0-9+/]+={0,2}$/.test(b64)) return "ERROR: 'content' is not valid base64.";
        data = Buffer.from(b64, "base64");
      }

      const result = commitFile(ws, p, data);
      if (result.error) return result.error;
      ws.onProgress?.(`name: "${rawName}" · tail: ".${rawTail}" → saved \`${p}\``);
      return `OK: name="${rawName}", tail=".${rawTail}" -> saved ${p} to the output folder (${result.size} bytes)`;
    }

    case "edit_file": {
      const p = normalizePath(args.path);
      if (!p || !ws.files.has(p)) {
        return `ERROR: no such file. Files available: ${[...ws.files.keys()].join(", ") || "(none)"}`;
      }
      const current = ws.files.get(p);
      if (Buffer.isBuffer(current)) return "ERROR: that's a binary file -- use write_file to replace it entirely instead.";
      if (typeof args.old_str !== "string" || !args.old_str) return "ERROR: 'old_str' is required and must be non-empty.";
      if (typeof args.new_str !== "string") return "ERROR: 'new_str' is required (use an empty string to delete old_str).";

      const occurrences = current.split(args.old_str).length - 1;
      if (occurrences === 0) {
        return "ERROR: 'old_str' was not found in the file. Copy it exactly from read_file/list_files, don't retype it from memory.";
      }
      if (occurrences > 1) {
        return `ERROR: 'old_str' appears ${occurrences} times in the file -- it must be unique. Include more surrounding context.`;
      }

      const updated = current.replace(args.old_str, args.new_str);
      const result = commitFile(ws, p, updated);
      if (result.error) return result.error;
      ws.onProgress?.(`editing \`${p}\`…`);
      return `OK: edited ${p} (${result.size} bytes now)`;
    }

    case "add_line": {
      const p = normalizePath(args.path);
      if (!p || !ws.files.has(p)) {
        return `ERROR: no such file. Files available: ${[...ws.files.keys()].join(", ") || "(none)"}`;
      }
      const current = ws.files.get(p);
      if (Buffer.isBuffer(current)) return "ERROR: that's a binary file -- use write_file to replace it entirely instead.";
      if (typeof args.content !== "string" || !args.content) return "ERROR: 'content' is required -- the line(s) to insert.";

      // Split into lines, dropping the single trailing "" a `\n`-terminated file produces,
      // so line numbers line up with what a human (or list_files) would call "line N".
      let lines = current === "" ? [] : current.split("\n");
      if (lines.length && lines[lines.length - 1] === "" && current.endsWith("\n")) lines.pop();

      let afterLine = lines.length; // default: append at the very end
      if (args.after_line !== undefined && args.after_line !== null) {
        afterLine = Number(args.after_line);
        if (!Number.isInteger(afterLine) || afterLine < 0 || afterLine > lines.length) {
          return `ERROR: 'after_line' must be a whole number between 0 and ${lines.length} (the file currently has ${lines.length} lines). Omit it to append at the end.`;
        }
      }

      const newLines = args.content.split("\n");
      lines.splice(afterLine, 0, ...newLines);
      const updated = lines.join("\n") + "\n";

      const result = commitFile(ws, p, updated);
      if (result.error) return result.error;
      ws.onProgress?.(`adding to \`${p}\`…`);
      return `OK: inserted ${newLines.length} line(s) into ${p} after line ${afterLine} (${result.size} bytes now, ${lines.length} lines)`;
    }

    case "read_file": {
      const p = normalizePath(args.path);
      if (!p || !ws.files.has(p)) {
        return `ERROR: no such file. Files available: ${[...ws.files.keys()].join(", ") || "(none)"}`;
      }
      const text = ws.files.get(p);
      if (Buffer.isBuffer(text)) return `(binary file, ${text.length} bytes — can't be shown as text)`;
      return text.length > 60_000 ? text.slice(0, 60_000) + "\n…[truncated]" : text;
    }

    case "list_files": {
      if (!ws.files.size) return "(workspace is empty)";
      return [...ws.files].map(([p, c]) =>
        `${p} (${byteLen(c)} bytes)${ws.written.has(p) ? " [written by you]" : " [from user/earlier]"}${ws.outbox.has(p) ? " [queued to send]" : ""}`
      ).join("\n");
    }

    case "send_file": {
      const p = normalizePath(args.path);
      if (!p || !ws.files.has(p)) {
        return `ERROR: no such file. Files available: ${[...ws.files.keys()].join(", ") || "(none)"}`;
      }
      if (!ws.outbox.has(p) && ws.outbox.size >= MAX_FILES) return `ERROR: too many files to send (max ${MAX_FILES}).`;
      ws.outbox.add(p);
      ws.onProgress?.(`sending \`${p}\`…`);
      return `OK: ${p} will be sent to the chat (${byteLen(ws.files.get(p))} bytes).`;
    }

    case "web_search": {
      const query = typeof args.query === "string" ? args.query.trim().slice(0, 200) : "";
      if (!query) return "ERROR: 'query' is required.";
      if (ws.searches >= MAX_SEARCHES) return "ERROR: search limit reached for this request. Work from what you have.";
      ws.searches++;
      ws.onProgress?.(`searching the web…`);
      try {
        const results = await searchGoogle(query, 5);
        if (!results.length) return "No results.";
        return results.map((r, i) => `${i + 1}. ${r.title} — ${r.snippet || "(no description)"} (${r.link})`).join("\n");
      } catch (err) {
        return `ERROR: the search tool failed (${err.message}). Continue without it.`;
      }
    }

    default:
      return `ERROR: unknown tool "${name}".`;
  }
}

// ─── Fallback: pull fenced code blocks out of plain text into files ────────────────
// Used when the endpoint doesn't support tool calling, or the model ignored its
// instructions and pasted code into the reply anyway.
const LANG_EXT = {
  javascript: "js", js: "js", node: "js", typescript: "ts", ts: "ts", tsx: "tsx", jsx: "jsx",
  python: "py", py: "py", java: "java", c: "c", cpp: "cpp", "c++": "cpp", csharp: "cs", cs: "cs",
  go: "go", rust: "rs", rs: "rs", ruby: "rb", rb: "rb", php: "php", swift: "swift", kotlin: "kt",
  bash: "sh", sh: "sh", shell: "sh", zsh: "sh", powershell: "ps1", sql: "sql", html: "html",
  css: "css", scss: "scss", json: "json", yaml: "yml", yml: "yml", toml: "toml", xml: "xml",
  markdown: "md", md: "md", lua: "lua", dart: "dart", r: "r", dockerfile: "Dockerfile",
};

function salvageCodeBlocks(text) {
  const files = [];
  const used = new Set();
  let counter = 0;

  const stripped = text.replace(/```([^\n`]*)\n([\s\S]*?)```/g, (whole, info, body) => {
    if (body.trim().split("\n").length < 3) return whole; // tiny snippets stay in chat

    let name = null;
    const firstLine = body.split("\n")[0];
    const marker = firstLine.match(/(?:file(?:name)?|path)\s*[:=]\s*([^\s*]+)/i);
    if (marker) {
      name = normalizePath(marker[1]);
      if (name) body = body.split("\n").slice(1).join("\n");
    }
    if (!name) {
      const infoName = info.trim().split(/\s+/).find(t => /\.[A-Za-z0-9]{1,8}$/.test(t));
      if (infoName) name = normalizePath(infoName.replace(/^["']|["']$/g, ""));
    }
    if (!name) {
      const lang = info.trim().split(/\s+/)[0].toLowerCase();
      const ext = LANG_EXT[lang] || "txt";
      counter++;
      name = ext === "Dockerfile" ? "Dockerfile" : `code${counter > 1 ? `_${counter}` : ""}.${ext}`;
    }
    while (used.has(name)) name = `${counter++}_${name}`;
    used.add(name);
    files.push({ path: name, content: body.replace(/\s+$/, "") + "\n" });
    return `(→ ${name})`;
  });

  return { files, text: stripped };
}

// ─── Delivery: workspace -> Discord attachments ───────────────────────────────
function packageFiles(entries) {
  if (!entries.length) return [];
  const total = entries.reduce((n, [, c]) => n + byteLen(c), 0);
  if (total > MAX_TOTAL_BYTES) throw new CoderUserError("the files I made are too big to upload to Discord — ask for something smaller.");
  const list = entries.map(([name, content]) => ({ name, data: Buffer.isBuffer(content) ? content : Buffer.from(content, "utf8") }));

  if (list.length === 1) {
    return [{ name: list[0].name.split("/").pop(), buffer: list[0].data }];
  }
  const flat = list.length <= MAX_SEPARATE_FILES && list.every(f => !f.name.includes("/"));
  if (flat) return list.map(f => ({ name: f.name, buffer: f.data }));

  return [{ name: "project.zip", buffer: buildZip(list) }];
}

// ─── Input attachments from Discord ────────────────────────────────────────────
const TEXT_EXTENSIONS = new Set([
  "js", "mjs", "cjs", "ts", "tsx", "jsx", "json", "py", "java", "c", "h", "cpp", "hpp", "cs", "go", "rs",
  "rb", "php", "swift", "kt", "sh", "bash", "ps1", "sql", "html", "css", "scss", "md", "txt", "yml", "yaml",
  "toml", "ini", "cfg", "xml", "csv", "lua", "r", "dart", "vue", "svelte", "gradle", "lock", "gitignore",
]);

/**
 * Downloads text/code attachments so the coder can read or modify them.
 * Silently skips anything binary, oversized, or secret-looking (.env files are
 * never sent to the model).
 * @param {{name: string, url: string, size?: number, contentType?: string|null}[]} list
 * @returns {Promise<{files: {name: string, content: string}[], skipped: number}>}
 */
async function fetchTextAttachments(list = []) {
  const files = [];
  let skipped = 0;
  const seen = new Set();

  for (const a of list) {
    if (files.length >= MAX_INPUT_FILES) { skipped++; continue; }
    let name = String(a.name || "file").replace(/[^\w.\-]+/g, "_").slice(0, 80) || "file";
    const ext = name.includes(".") ? name.split(".").pop().toLowerCase() : "";
    const type = a.contentType || "";
    const looksText = TEXT_EXTENSIONS.has(ext) || /^text\//.test(type) || /json|xml|javascript|x-sh|yaml/.test(type);

    if (!looksText || /^\.?env(\.|$)/i.test(name) || (a.size && a.size > MAX_INPUT_FILE_BYTES)) { skipped++; continue; }

    try {
      const res = await fetch(a.url);
      if (!res.ok) { skipped++; continue; }
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length > MAX_INPUT_FILE_BYTES || buf.includes(0)) { skipped++; continue; }
      while (seen.has(name)) name = `_${name}`;
      seen.add(name);
      files.push({ name, content: buf.toString("utf8") });
    } catch {
      skipped++;
    }
  }
  return { files, skipped };
}

// ─── Main entry point ─────────────────────────────────────────────────────────────
/**
 * Run the coding agent on a task.
 * @param {Object} opts
 * @param {string} opts.task - what to build / change
 * @param {{name: string, content: string}[]} [opts.inputFiles] - existing files to work from
 * @param {(status: string) => void} [opts.onProgress] - called as it works ("wrote `main.py`")
 * @returns {Promise<{summary: string, files: {name: string, buffer: Buffer}[], fileNames: string[], model: string}>}
 */
// ─── Live progress (streaming) ──────────────────────────────────────────────
// The model call is streamed so the status line can show what's happening RIGHT NOW
// ("thinking…", "writing `app.py` (2,300 chars)…") instead of going quiet until a
// whole reply arrives. A watchdog aborts a stream that goes completely silent.
// NVIDIA_CODER_STREAM=off falls back to plain (non-streamed) calls.
const IDLE_ABORT_MS = (Number(process.env.NVIDIA_CODER_IDLE_SECONDS) || 150) * 1000;

/** Streams one chat completion and returns it in the normal non-streamed shape. */
async function streamCompletion(client, params, onEvent, includeUsage) {
  const controller = new AbortController();
  let idleTimer;
  let timedOut = false;
  const resetIdle = () => {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => { timedOut = true; controller.abort(); }, IDLE_ABORT_MS);
  };

  let content = "";
  let thinkingChars = 0;
  let usage = null;
  const calls = [];

  try {
    resetIdle();
    const stream = await client.chat.completions.create(
      { ...params, stream: true, ...(includeUsage ? { stream_options: { include_usage: true } } : {}) },
      { signal: controller.signal },
    );
    for await (const chunk of stream) {
      resetIdle();
      if (chunk.usage) usage = chunk.usage;
      const d = chunk.choices?.[0]?.delta;
      if (!d) continue;

      const thought = d.reasoning_content ?? d.reasoning;
      if (thought) { thinkingChars += thought.length; onEvent({ type: "thinking", chars: thinkingChars }); }

      if (d.content) { content += d.content; onEvent({ type: "reply", chars: content.length }); }

      for (const tc of d.tool_calls || []) {
        const i = tc.index ?? 0;
        const c = (calls[i] ||= { id: "", type: "function", function: { name: "", arguments: "" } });
        if (tc.id) c.id = tc.id;
        if (tc.function?.name) c.function.name += tc.function.name;
        if (tc.function?.arguments) c.function.arguments += tc.function.arguments;
        if (!c.path) c.path = c.function.arguments.match(/"path"\s*:\s*"([^"]+)"/)?.[1] || "";
        onEvent({ type: "tool", name: c.function.name, path: c.path, chars: c.function.arguments.length });
      }
    }
    // The SDK ends the loop quietly (no throw) when the watchdog aborts, so check here.
    if (timedOut) throw new CoderUserError(`the coding model went silent for ${Math.round(IDLE_ABORT_MS / 1000)}s, so I stopped it — try again.`);
  } catch (err) {
    if (timedOut) {
      throw new CoderUserError(`the coding model went silent for ${Math.round(IDLE_ABORT_MS / 1000)}s, so I stopped it — try again.`);
    }
    throw err;
  } finally {
    clearTimeout(idleTimer);
  }

  calls.forEach((c, i) => { if (!c.id) c.id = `call_${i}`; delete c.path; });
  return {
    choices: [{ message: { role: "assistant", content: content || null, ...(calls.length ? { tool_calls: calls } : {}) } }],
    usage,
    thinkingChars,
  };
}

/**
 * A status line that never goes quiet: re-renders every few seconds with the latest
 * step and elapsed time, so a slow model looks "busy", not "stuck".
 * @param {(text: string) => void} edit - how to show the text (edit a message / reply)
 */
function startProgressDisplay(edit, intervalMs = 4000) {
  const startedAt = Date.now();
  let step = "starting…";
  const render = () => `⚙️ working… ${step} · ${Math.round((Date.now() - startedAt) / 1000)}s`;
  edit(render());
  const timer = setInterval(() => edit(render()), intervalMs);
  timer.unref?.();
  return { update: t => { step = t; }, stop: () => clearInterval(timer) };
}

// ─── Conversation memory ────────────────────────────────────────────────────
// Each memoryKey (index.js/code.js use "<channelId>:<userId>") keeps the last few
// request/answer pairs plus the latest version of every file produced or attached,
// so follow-ups like "now add a login page" or "fix the bug in it" just work.
// Only short summaries are replayed to the model (keeps every request cheap); file
// contents stay in the workspace and the model pulls them in with read_file.
// In-memory only: it resets on restart, after MEMORY_TTL_MS idle, or on "write me reset".
const MEMORY_TURNS     = Number(process.env.CODER_MEMORY_TURNS) || 4;     // request/answer pairs remembered
const MEMORY_TTL_MS    = 2 * 60 * 60_000;                                  // idle time before forgetting
const MEMORY_MAX_CHARS = 300_000;                                          // remembered file text per conversation
const MEMORY_MAX_KEYS  = 200;                                              // conversations kept at once
const memories = new Map(); // key -> { turns: [{task, summary}], files: Map<path, content>, updatedAt }

function getMemory(key) {
  if (!key) return null;
  const m = memories.get(key);
  if (!m) return null;
  if (Date.now() - m.updatedAt > MEMORY_TTL_MS) { memories.delete(key); return null; }
  return m;
}

function hasMemory(key) {
  return !!getMemory(key);
}

function clearMemory(key) {
  return memories.delete(key);
}

function saveMemory(key, task, summary, files) {
  if (!key) return null;
  const m = getMemory(key) || { turns: [], files: new Map(), updatedAt: 0 };
  m.turns.push({ task: task.trim().slice(0, 1500), summary: summary.slice(0, 600) });
  if (m.turns.length > MEMORY_TURNS) m.turns.splice(0, m.turns.length - MEMORY_TURNS);
  for (const [name, content] of files) { m.files.delete(name); m.files.set(name, content); } // re-insert = newest
  // Drop the oldest remembered files once over the size cap.
  let total = 0;
  for (const c of m.files.values()) total += c.length;
  for (const name of [...m.files.keys()]) {
    if (total <= MEMORY_MAX_CHARS) break;
    total -= m.files.get(name).length;
    m.files.delete(name);
  }
  m.updatedAt = Date.now();
  memories.delete(key);      // re-insert so the Map stays in least-recently-used order
  memories.set(key, m);
  while (memories.size > MEMORY_MAX_KEYS) memories.delete(memories.keys().next().value);
  return m;
}

/** "-# 🧮 …" footer line (Discord subtext) with the tokens the whole request used. */
function formatUsage(result) {
  const u = result?.usage;
  if (!u || !u.total) return "";
  const n = x => x.toLocaleString("en-US");
  const parts = [
    `🧮 ${n(u.total)} tokens (in ${n(u.prompt)} · out ${n(u.completion)})`,
    `${u.calls} API call${u.calls === 1 ? "" : "s"}`,
    String(result.model || "").split("/").pop(),
  ];
  // A big thinkingChars number relative to out tokens is the usual sign that "thinking"
  // (not the file itself) is what's making a small request take a long time.
  if (u.thinkingChars) parts.push(`💭 ${n(u.thinkingChars)} thinking chars`);
  if (result.memoryTurns) parts.push(`🧠 ${result.memoryTurns} remembered`);
  return "-# " + parts.filter(Boolean).join(" · ");
}

async function runCoder({ task, inputFiles = [], onProgress = null, memoryKey = null }) {
  if (typeof task !== "string" || !task.trim()) throw new CoderUserError("tell me what to build.");

  const client = getClient();
  const model = resolveModel(process.env.NVIDIA_CODER_MODEL || DEFAULT_MODEL);

  const scope = sanitizeScope(memoryKey);
  const ws = {
    scope,                       // each conversation/user gets its own folder — no cross-user leakage or slowdown
    files: loadExistingFiles(scope),   // only THIS scope's saved files, not everyone's
    written: new Set(),
    outbox: new Set(),        // files the model explicitly chose to send (send_file), in order
    totalWritten: 0,
    searches: 0,
    onProgress,
  };
  const mem = getMemory(memoryKey);
  if (mem) for (const [name, content] of mem.files) ws.files.set(name, content); // read_file/edits see earlier work
  for (const f of inputFiles) ws.files.set(f.name, f.content);                   // fresh attachments win

  let userContent = task.trim();
  if (mem?.files.size) {
    const attached = new Set(inputFiles.map(f => f.name));
    const earlier = [...mem.files].filter(([name]) => !attached.has(name));
    if (earlier.length) {
      userContent += "\n\nFiles from earlier in this conversation (latest versions, use read_file to view):\n" +
        earlier.map(([name, c]) => `- ${name} (${c.length} chars)`).join("\n");
    }
  }
  if (inputFiles.length) {
    userContent += "\n\nFiles the user attached:";
    for (const f of inputFiles) {
      userContent += f.content.length <= INLINE_INPUT_CHARS
        ? `\n\n--- ${f.name} ---\n${f.content}`
        : `\n\n--- ${f.name} (${f.content.length} chars — too long to inline, use read_file) ---`;
    }
  }

  const messages = [
    { role: "system", content: CODER_SYSTEM_PROMPT },
    // Earlier turns of this conversation, as short task -> summary pairs.
    ...(mem ? mem.turns.flatMap(t => [
      { role: "user", content: t.task },
      { role: "assistant", content: t.summary },
    ]) : []),
    { role: "user", content: userContent },
  ];

  const usage = { prompt: 0, completion: 0, total: 0, calls: 0 };

  const startedAt = Date.now();
  let useTools = true;
  let sendEffort = CODER_REASONING() !== "off"; // dropped for the rest of the run if the endpoint rejects it
  let streaming = process.env.NVIDIA_CODER_STREAM !== "off";  // false = plain calls (auto-set if the endpoint refuses streaming)
  let streamUsage = true;                                     // ask for token counts inside the stream

  // Turn stream events into a short human status ("writing `app.py`…").
  const fmt = n => n.toLocaleString("en-US");
  const onEvent = e => {
    if (!onProgress) return;
    if (e.type === "thinking") onProgress(`thinking (${fmt(e.chars)} chars)…`);
    else if (e.type === "reply") onProgress("finishing up…");
    else if (e.type === "tool") {
      if (e.name === "write_file") onProgress(e.path ? `writing \`${e.path}\` (${fmt(e.chars)} chars)…` : "writing a file…");
      else if (e.name === "edit_file") onProgress(e.path ? `editing \`${e.path}\`…` : "editing a file…");
      else if (e.name === "add_line") onProgress(e.path ? `adding to \`${e.path}\`…` : "adding a line…");
      else if (e.name === "send_file") onProgress(e.path ? `sending \`${e.path}\`…` : "sending a file…");
      else if (e.name === "read_file") onProgress(e.path ? `reading \`${e.path}\`…` : "reading a file…");
      else if (e.name === "web_search") onProgress("searching the web…");
      else if (e.name) onProgress(`running ${e.name}…`);
    }
  };
  let finalText = "";

  for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
    const lastChance = round === MAX_TOOL_ROUNDS || Date.now() - startedAt > MAX_RUN_MS;
    const roundStartedAt = Date.now();

    let completion;
    try {
      const params = {
        model,
        messages,
        max_tokens: MAX_OUTPUT_TOKENS,
        ...(sendEffort ? { reasoning_effort: CODER_REASONING() } : {}),
        ...(useTools ? { tools: CODER_TOOLS, tool_choice: lastChance ? "none" : "auto" } : {}),
      };
      if (onProgress && round > 0) onProgress("thinking…");
      completion = streaming
        ? await streamCompletion(client, params, onEvent, streamUsage)
        : await client.chat.completions.create(params);
    } catch (err) {
      // Endpoint/model that rejects tool calling: retry once as plain chat and
      // recover files from code blocks instead of failing the whole request.
      // A 400 about reasoning/effort: retry the same call without that parameter.
      if (sendEffort && err.status === 400 && /reasoning|effort/i.test(err.message || "")) {
        console.warn("[Coder] Endpoint rejected reasoning_effort, retrying without it:", err.message);
        sendEffort = false;
        round--; // this attempt doesn't count
        continue;
      }
      // Endpoint doesn't like stream_options / streaming: degrade step by step instead of failing.
      if (streaming && err.status === 400 && /stream_options|include_usage/i.test(err.message || "") && streamUsage) {
        console.warn("[Coder] Endpoint rejected stream_options, retrying without token counts in the stream:", err.message);
        streamUsage = false;
        round--;
        continue;
      }
      if (streaming && [400, 404, 422].includes(err.status) && /stream/i.test(err.message || "")) {
        console.warn("[Coder] Endpoint rejected streaming, using plain calls:", err.message);
        streaming = false;
        round--;
        continue;
      }
      const rejectedTools = useTools && round === 0 && [400, 404, 422].includes(err.status) && /tool|function/i.test(err.message || "");
      if (rejectedTools) {
        console.warn("[Coder] Endpoint rejected tool calling, falling back to code-block extraction:", err.message);
        useTools = false;
        messages[0] = {
          role: "system",
          content: CODER_SYSTEM_PROMPT + "\n\nTool calling is unavailable. Instead, put each file in its own fenced code block whose FIRST line is a comment like `// file: src/app.js` (or `# file: main.py`). Keep any other prose very short.",
        };
        round--; // this attempt doesn't count
        continue;
      }
      throw err;
    }

    const u = completion.usage;
    if (u) {
      usage.prompt     += u.prompt_tokens     || 0;
      usage.completion += u.completion_tokens || 0;
      usage.total      += u.total_tokens      || ((u.prompt_tokens || 0) + (u.completion_tokens || 0));
    }
    usage.calls++;
    usage.thinkingChars = (usage.thinkingChars || 0) + (completion.thinkingChars || 0);

    // Logged server-side (not shown to the user) so a slow run can actually be diagnosed:
    // is the time going into one model call's "thinking", or into many round trips?
    console.log(
      `[Coder] round ${round} took ${Date.now() - roundStartedAt}ms` +
      (completion.thinkingChars ? ` (${completion.thinkingChars} thinking chars)` : "") +
      (u ? ` — ${u.completion_tokens || 0} completion tokens` : ""),
    );

    const msg = completion.choices?.[0]?.message;
    if (!msg) throw new Error("The coding model returned an empty response.");

    const calls = msg.tool_calls || [];
    if (!useTools || !calls.length) {
      finalText = (msg.content || "").trim();
      break;
    }

    // Echo the assistant turn back exactly as needed for the tool round trip.
    messages.push({ role: "assistant", content: msg.content || null, tool_calls: calls });
    for (const call of calls) {
      const result = await execCoderTool(call.function?.name, call.function?.arguments, ws);
      messages.push({ role: "tool", tool_call_id: call.id, content: String(result).slice(0, 60_000) });
    }
  }

  // Nothing written through tools? Recover files from any code blocks in the reply.
  let summary = finalText;
  if (!ws.written.size && summary) {
    const salvaged = salvageCodeBlocks(summary);
    for (const f of salvaged.files.slice(0, MAX_FILES)) {
      ws.files.set(f.path, f.content);
      ws.written.add(f.path);
    }
    summary = salvaged.text;
  }

  // What reaches the chat: the files the model picked with send_file, or (if it never
  // called it) everything it wrote.
  const sendPaths = ws.outbox.size ? [...ws.outbox] : [...ws.written];
  const entries = sendPaths.filter(p => ws.files.has(p)).map(p => [p, ws.files.get(p)]);
  const files = packageFiles(entries);

  if (!summary) summary = entries.length ? "done — files attached." : "the model didn't produce any files.";

  // Remember this exchange (+ the current version of every file touched) for follow-ups.
  // (Binary files are delivered but not remembered: memory only holds text the model can read_file.)
  const touched = new Map(inputFiles.map(f => [f.name, f.content]));
  for (const p of ws.written) if (typeof ws.files.get(p) === "string") touched.set(p, ws.files.get(p));
  const remembered = saveMemory(
    memoryKey,
    task,
    entries.length ? `${summary} (files sent: ${entries.map(([p]) => p).join(", ")})` : summary,
    touched,
  );

  return {
    summary: summary.slice(0, 1800),
    files,
    fileNames: entries.map(([p]) => p),
    model,
    usage,
    memoryTurns: remembered ? remembered.turns.length : 0,
  };
}

module.exports = {
  runCoder: withApiLog("NVIDIA", "coding agent", runCoder, ({ task } = {}) => task?.slice(0, 60)),
  beginRun,
  clearMemory,
  hasMemory,
  formatUsage,
  startProgressDisplay,
  fetchTextAttachments,
  isConfigured,
  CoderUserError,
  CoderConfigError,
  CODER_TOOLS,
};