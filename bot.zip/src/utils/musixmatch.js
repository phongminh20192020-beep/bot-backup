"use strict";

/**
 * Unofficial Musixmatch client.
 *
 * There's no public/paid API key involved — this calls the same private
 * endpoint Musixmatch's own desktop app uses internally, with the app's
 * embedded client id. As of 2024 Musixmatch stopped requiring an account
 * for this, so it works anonymously.
 *
 * Caveats (why this sits *in front of*, not *instead of*, the existing
 * LRCLIB/lyrics.ovh fallback chain in lyrics.js):
 *   - This is not a public API. Musixmatch can change or lock it down at
 *     any time without notice.
 *   - Their anti-abuse system sometimes rate-limits or feeds junk tokens
 *     to datacenter/cloud IPs (Railway, Discloud, etc. included). If that
 *     happens here, every function below just returns null so the caller
 *     falls through to the next source — nothing crashes.
 *   - Musixmatch's own terms allow lyrics lookups for private use (e.g.
 *     "what song is this" in a Discord server) but not republishing lyrics
 *     publicly or commercially. This bot only ever displays lyrics
 *     ephemerally/in-context, same as it already did with LRCLIB.
 */

const https = require("https");

const HOST = "apic-desktop.musixmatch.com";
const APP_ID = "web-desktop-app-v1.0";
const USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
  "Musixmatch/0.19.4 Chrome/58.0.3029.110 Electron/1.7.6 Safari/537.36";

const TOKEN_TTL_MS = 9 * 60 * 60 * 1000; // tokens are long-lived; refresh well before they go stale
let cachedToken = null;
let cachedTokenAt = 0;

function request(path) {
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        hostname: HOST,
        path,
        method: "GET",
        headers: {
          "User-Agent": USER_AGENT,
          // Musixmatch's desktop client always sends these; some edge nodes
          // reject requests without any AWSELB cookie at all.
          Cookie: "AWSELB=0; AWSELBCORS=0",
        },
      },
      (res) => {
        let data = "";
        res.on("data", (c) => (data += c));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            reject(new Error("Musixmatch: non-JSON response"));
          }
        });
      }
    );
    req.on("error", reject);
    req.setTimeout(8000, () => {
      req.destroy();
      reject(new Error("Musixmatch: timeout"));
    });
    req.end();
  });
}

async function fetchUserToken() {
  const path = `/ws/1.1/token.get?${new URLSearchParams({
    app_id: APP_ID,
    user_language: "en",
    format: "json",
  }).toString()}`;

  const json = await request(path);
  const status = json?.message?.header?.status_code;
  const token = json?.message?.body?.user_token;

  // This sentinel value is what Musixmatch hands back when it's decided
  // (usually based on IP reputation) not to issue a real token.
  if (status !== 200 || !token || token === "UpgradeOnlyUpgradeOnlyUpgradeOnlyUpgradeOnly") {
    throw new Error(`Musixmatch: token.get refused (status ${status ?? "?"})`);
  }
  return token;
}

/** Returns a cached user token, fetching/refreshing it as needed. */
async function getUserToken(forceRefresh = false) {
  if (!forceRefresh && cachedToken && Date.now() - cachedTokenAt < TOKEN_TTL_MS) {
    return cachedToken;
  }
  const token = await fetchUserToken();
  cachedToken = token;
  cachedTokenAt = Date.now();
  return token;
}

function buildSubtitlesPath(token, { artist, title, album, durationSec }) {
  const qs = new URLSearchParams({
    format: "json",
    namespace: "lyrics_richsynched",
    subtitle_format: "lrc", // plain LRC text so lyrics.js's existing parseLrc() can read it directly
    app_id: APP_ID,
    usertoken: token,
    q_track: title || "",
    q_artist: artist || "",
    q_artists: artist || "",
    q_album: album || "",
    track_spotify_id: "",
    q_duration: durationSec ? String(Math.round(durationSec)) : "",
    f_subtitle_length: durationSec ? String(Math.round(durationSec)) : "",
    f_subtitle_length_max_deviation: "40",
  });
  return `/ws/1.1/macro.subtitles.get?${qs.toString()}`;
}

/**
 * Looks up lyrics on Musixmatch for the given artist/title.
 * Returns { synced: string|null, plain: string|null } where `synced` is
 * *raw LRC text* (not yet parsed — pass it through parseLrc() from
 * lyrics.js), or null if nothing usable was found (no match, instrumental,
 * blocked token, network error, etc). Never throws.
 */
async function fetchFromMusixmatch(artist, title, { album, durationSec } = {}, _retried = false) {
  let token;
  try {
    token = await getUserToken();
  } catch {
    return null;
  }

  let json;
  try {
    json = await request(buildSubtitlesPath(token, { artist, title, album, durationSec }));
  } catch {
    return null;
  }

  const calls = json?.message?.body?.macro_calls;
  if (!calls) return null;

  const matchStatus = calls["matcher.track.get"]?.message?.header?.status_code;

  // Token expired/invalid mid-flight — refresh once and retry the lookup.
  if (matchStatus === 401 && !_retried) {
    cachedToken = null;
    return fetchFromMusixmatch(artist, title, { album, durationSec }, true);
  }
  if (matchStatus !== 200) return null; // 404 no match, or other non-success

  const track = calls["matcher.track.get"]?.message?.body?.track;
  if (track?.instrumental) return { synced: null, plain: null };

  const subtitleBody =
    calls["track.subtitles.get"]?.message?.body?.subtitle_list?.[0]?.subtitle?.subtitle_body || null;
  const lyricsBody = calls["track.lyrics.get"]?.message?.body?.lyrics?.lyrics_body || null;

  if (!subtitleBody && !lyricsBody) return null;
  return { synced: subtitleBody, plain: lyricsBody };
}

module.exports = { fetchFromMusixmatch, getUserToken };
