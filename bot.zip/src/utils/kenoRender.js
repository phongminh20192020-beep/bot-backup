"use strict";

const { createCanvas } = require("@napi-rs/canvas");
const { INK, BG } = require("./canvasDoodle");

const COLS = 8;
const ROWS = 5; // 40 numbers
const CELL = 46;
const PAD = 16;
const W = COLS * CELL + PAD * 2;
const H = ROWS * CELL + PAD * 2;

const PICK_COLOR  = "#3fb6d6"; // player's pick, not drawn
const DRAWN_COLOR = "#c7ccd1"; // drawn, not picked
const HIT_COLOR   = "#5cb85c"; // picked AND drawn -- a match

/**
 * @param {number[]} picks - player's chosen numbers
 * @param {number[]} drawn - the 20 numbers that came up
 * @returns {Buffer} PNG image buffer
 */
function renderKenoBoard(picks, drawn) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, H);

  const pickSet = new Set(picks);
  const drawnSet = new Set(drawn);

  for (let n = 1; n <= COLS * ROWS; n++) {
    const idx = n - 1;
    const col = idx % COLS;
    const row = Math.floor(idx / COLS);
    const x = PAD + col * CELL;
    const y = PAD + row * CELL;

    const isPick = pickSet.has(n);
    const isDrawn = drawnSet.has(n);

    let fill = BG, stroke = "#d8d8d8", textColor = "#9aa0a6";
    if (isPick && isDrawn) { fill = HIT_COLOR; stroke = INK; textColor = "#ffffff"; }
    else if (isDrawn)      { fill = DRAWN_COLOR; stroke = INK; textColor = INK; }
    else if (isPick)       { fill = "#ffffff"; stroke = PICK_COLOR; textColor = PICK_COLOR; }

    ctx.fillStyle = fill;
    ctx.fillRect(x + 2, y + 2, CELL - 4, CELL - 4);
    ctx.strokeStyle = stroke;
    ctx.lineWidth = isPick ? 3 : 1.5;
    ctx.strokeRect(x + 2, y + 2, CELL - 4, CELL - 4);

    ctx.fillStyle = textColor;
    ctx.font = "bold 16px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(n), x + CELL / 2, y + CELL / 2);
  }

  return canvas.toBuffer("image/png");
}

module.exports = { renderKenoBoard };
