"use strict";

// ─── Tools for the talking AI ("noname", running on Groq) ──────────────────────────
// These are real OpenAI-style function-calling tools. Previously noname could
// only *ask* for a search by filling in JSON fields (search_query, etc.) and
// index.js ran a second model call afterwards; now the model calls the tool
// itself mid-reply and sees the result right away (see chatWithTools() in
// groq.js for the loop).
//
//   web_search            -> SerpApi (DuckDuckGo)
//   image_search          -> SerpApi (Google Images)
//   reverse_image_search  -> SerpApi (Google Lens) on the attached image
//
// Coding is NOT a tool here any more: it's its own separate mode ("write me ..."
// / "noname write me ..." in index.js -> utils/coder.js on NVIDIA).

const { searchGoogle, searchGoogleImages, searchImageContent } = require("./websearch");

const MAX_SEARCHES_PER_TURN = 2;

const TOOL_DEFS = {
  web_search: {
    type: "function",
    function: {
      name: "web_search",
      description: "Search the web. Only use when the user explicitly asked you to search / look up / check / google something.",
      parameters: {
        type: "object",
        properties: { query: { type: "string", description: "Short search query." } },
        required: ["query"],
      },
    },
  },
  image_search: {
    type: "function",
    function: {
      name: "image_search",
      description: "Find pictures on the web. Returns direct image URLs; put the best one in a message and Discord shows it as an image.",
      parameters: {
        type: "object",
        properties: { query: { type: "string", description: "What the picture should show." } },
        required: ["query"],
      },
    },
  },
  reverse_image_search: {
    type: "function",
    function: {
      name: "reverse_image_search",
      description: "Identify what/where the image attached to the user's message is (Google Lens).",
      parameters: { type: "object", properties: {} },
    },
  },
};

/**
 * Which tools to offer for a given turn.
 * @param {{hasImages: boolean, richReplies: boolean}} opts
 *   richReplies = the reply lands in a Discord text channel, so it can carry
 *   image links. Voice paths (which just speak the text)
 *   only get web_search.
 */
function getNonameTools({ hasImages, richReplies }) {
  const tools = [TOOL_DEFS.web_search];
  if (richReplies) {
    tools.push(TOOL_DEFS.image_search);
    if (hasImages) tools.push(TOOL_DEFS.reverse_image_search);
  }
  return tools;
}

function asResult(obj) {
  return JSON.stringify(obj).slice(0, 12_000);
}

const SEARCH_BROKE = "the search tool itself failed (key/quota/network) -- tell the user the search broke, do NOT claim nothing exists.";

/**
 * Runs one tool call. Never throws -- failures come back as {error} so the
 * model can react to them in character.
 * @param {string} name
 * @param {string|object} rawArgs - the model's JSON arguments
 * @param {{imageUrls: string[], searches: number}} ctx
 * @returns {Promise<string>} JSON string fed back to the model as the tool result
 */
async function runNonameTool(name, rawArgs, ctx) {
  let args;
  try {
    args = typeof rawArgs === "string" ? JSON.parse(rawArgs || "{}") : (rawArgs || {});
  } catch {
    return asResult({ error: "arguments weren't valid JSON" });
  }

  try {
    switch (name) {
      case "web_search":
      case "image_search": {
        const query = typeof args.query === "string" ? args.query.trim().slice(0, 200) : "";
        if (!query) return asResult({ error: "query is required" });
        if (ctx.searches >= MAX_SEARCHES_PER_TURN) return asResult({ error: "search limit reached for this turn -- answer with what you have" });
        ctx.searches++;

        if (name === "web_search") {
          const results = await searchGoogle(query, 5);
          return asResult({ query, results, note: results.length ? undefined : "no results -- the search genuinely came back empty" });
        }
        const results = await searchGoogleImages(query, 5);
        return asResult({
          query,
          results,
          note: results.length ? "put the imageUrl of whichever fits best directly into a message" : "no results -- the search genuinely came back empty",
        });
      }

      case "reverse_image_search": {
        if (!ctx.imageUrls.length) return asResult({ error: "there's no attached image this turn" });
        if (ctx.searches >= MAX_SEARCHES_PER_TURN) return asResult({ error: "search limit reached for this turn -- answer with what you have" });
        ctx.searches++;
        const found = await searchImageContent(ctx.imageUrls[0], 5);
        return asResult({
          identifiedAs: found.knowledgeGraph,
          similarImages: found.visualMatches,
          note: !found.knowledgeGraph && !found.visualMatches.length ? "nothing useful found -- the lookup genuinely came back empty" : undefined,
        });
      }

      default:
        return asResult({ error: `unknown tool "${name}"` });
    }
  } catch (err) {
    console.error(`[Tools] ${name} failed:`, err.message);
    return asResult({ error: SEARCH_BROKE });
  }
}

module.exports = { getNonameTools, runNonameTool };