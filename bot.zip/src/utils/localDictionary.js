"use strict";

// Bundled fallback word list for Wordle guess validation. Wordnik's API
// requires a key and can hiccup, and previously any lookup failure (missing
// key, timeout, rate limit, etc.) silently accepted the guess as valid --
// which is how garbage like "ddddd" and "idkdk" got through. This local list
// means "is this a real word" always has a real answer, key or no key.
//
// Source: https://github.com/tabatkins/wordle-list (public domain), the
// same list Wordle itself ships as valid guesses. ~14.8k words, loaded once
// and cached as a Set for O(1) lookups.
const fs   = require("fs");
const path = require("path");

let wordSet = null;

function loadWordSet() {
  if (wordSet) return wordSet;
  const filePath = path.join(__dirname, "data", "wordle-words.txt");
  const words = fs.readFileSync(filePath, "utf8").split("\n").map(w => w.trim()).filter(Boolean);
  wordSet = new Set(words);
  return wordSet;
}

/** Case-insensitive check against the bundled 5-letter word list. */
function isKnown5LetterWord(word) {
  if (typeof word !== "string" || word.length !== 5) return false;
  return loadWordSet().has(word.toLowerCase());
}

/** Pick a random word from the bundled list, for when Wordnik is unavailable. */
function randomKnown5LetterWord() {
  const words = [...loadWordSet()];
  return words[Math.floor(Math.random() * words.length)];
}

module.exports = { isKnown5LetterWord, randomKnown5LetterWord };
