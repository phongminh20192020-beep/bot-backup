"use strict";

// Rolling short-term memory for the "noname" Groq chat feature.
// In-memory only (not persisted to disk) — this is meant to be a light
// "what did we just talk about" buffer, not a durable chat log, so a
// process restart clearing it is fine and expected.
//
// Keyed per-channel: each guild text channel keeps its own last-10-messages
// buffer, since "noname" is meant to feel like it's following the
// conversation happening in that channel, not one specific user's DMs.
// Every new message pushed past the cap shifts the oldest one out.

const MAX_MEMORY = 10;

/** channelId -> Array<{ role: "user" | "assistant", content: string }> */
const memoryStore = new Map();

function getMemory(channelId) {
  return memoryStore.get(channelId) || [];
}

function pushMemory(channelId, role, content) {
  if (!content || typeof content !== "string") return;

  let arr = memoryStore.get(channelId);
  if (!arr) {
    arr = [];
    memoryStore.set(channelId, arr);
  }

  // Keep entries small — this is short-term conversational context, not a
  // transcript, and Groq's context window shouldn't be spent re-reading a
  // giant wall of text on every single reply.
  arr.push({ role, content: content.slice(0, 500) });

  while (arr.length > MAX_MEMORY) arr.shift();
}

function clearMemory(channelId) {
  memoryStore.delete(channelId);
}

module.exports = { getMemory, pushMemory, clearMemory, MAX_MEMORY };
