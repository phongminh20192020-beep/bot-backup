"use strict";

const { createCanvas } = require("@napi-rs/canvas");

// Classic beveled-gray Windows look, drawn with plain shapes (no emoji/icon
// fonts relied on) so it renders identically regardless of what fonts are
// installed on the host -- same reasoning as the hand-drawn tic-tac-toe
// board elsewhere in this project.
const CELL         = 32;
const HEADER       = 44;
const PANEL_MARGIN = 10;
const BEZEL        = 2;

const GRAY   = "#c0c0c0";
const LIGHT  = "#ffffff";
const DARK   = "#808080";
const DARKER = "#3d3d3d";
const LCD_BG = "#000000";
const LCD_FG = "#ff2020";

const NUMBER_COLORS = {
  1: "#0000ff", 2: "#008000", 3: "#ff0000", 4: "#000080",
  5: "#800000", 6: "#008080", 7: "#000000", 8: "#808080",
};

/** A raised (outward) or sunken (inward) beveled rectangle, classic Win9x/XP style. */
function drawBevel(ctx, x, y, w, h, raised) {
  ctx.fillStyle = GRAY;
  ctx.fillRect(x, y, w, h);

  const outerTop = raised ? LIGHT : DARKER;
  const outerBot = raised ? DARKER : LIGHT;
  const innerTop = raised ? "#dfdfdf" : DARK;
  const innerBot = raised ? DARK : "#dfdfdf";

  for (let i = 0; i < BEZEL; i++) {
    ctx.strokeStyle = i === 0 ? outerTop : innerTop;
    ctx.beginPath();
    ctx.moveTo(x + i + 0.5, y + h - i - 0.5);
    ctx.lineTo(x + i + 0.5, y + i + 0.5);
    ctx.lineTo(x + w - i - 0.5, y + i + 0.5);
    ctx.stroke();

    ctx.strokeStyle = i === 0 ? outerBot : innerBot;
    ctx.beginPath();
    ctx.moveTo(x + w - i - 0.5, y + i + 0.5);
    ctx.lineTo(x + w - i - 0.5, y + h - i - 0.5);
    ctx.lineTo(x + i + 0.5, y + h - i - 0.5);
    ctx.stroke();
  }
}

function drawFlag(ctx, cx, cy) {
  const s = CELL * 0.32;
  ctx.strokeStyle = "#000000";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(cx - s * 0.15, cy + s);
  ctx.lineTo(cx - s * 0.15, cy - s);
  ctx.stroke();

  ctx.fillStyle = "#ff0000";
  ctx.beginPath();
  ctx.moveTo(cx - s * 0.15, cy - s);
  ctx.lineTo(cx + s, cy - s * 0.45);
  ctx.lineTo(cx - s * 0.15, cy);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = "#000000";
  ctx.fillRect(cx - s * 0.55, cy + s - 2, s * 0.9, 3);
}

function drawMine(ctx, cx, cy, exploded) {
  const r = CELL * 0.28;
  if (exploded) {
    ctx.fillStyle = "#ff0000";
    ctx.fillRect(cx - CELL / 2 + 1, cy - CELL / 2 + 1, CELL - 2, CELL - 2);
  }
  ctx.strokeStyle = "#000000";
  ctx.lineWidth = 2;
  for (let a = 0; a < 8; a++) {
    const ang = (Math.PI / 4) * a;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(ang) * r * 1.5, cy + Math.sin(ang) * r * 1.5);
    ctx.stroke();
  }
  ctx.fillStyle = "#000000";
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(cx - r * 0.35, cy - r * 0.35, r * 0.25, 0, Math.PI * 2);
  ctx.fill();
}

function drawWrongFlagX(ctx, cx, cy) {
  const s = CELL * 0.3;
  ctx.strokeStyle = "#ff0000";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(cx - s, cy - s); ctx.lineTo(cx + s, cy + s);
  ctx.moveTo(cx + s, cy - s); ctx.lineTo(cx - s, cy + s);
  ctx.stroke();
}

/** Simple vector smiley face for the header button -- "playing"/"won"/"lost". */
function drawFace(ctx, cx, cy, r, faceState) {
  ctx.fillStyle = "#ffe000";
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#000000";
  ctx.lineWidth = 2;
  ctx.stroke();

  const eyeDx = r * 0.35, eyeDy = r * 0.2;
  if (faceState === "lost") {
    const s = r * 0.18;
    for (const dx of [-eyeDx, eyeDx]) {
      ctx.beginPath();
      ctx.moveTo(cx + dx - s, cy - eyeDy - s); ctx.lineTo(cx + dx + s, cy - eyeDy + s);
      ctx.moveTo(cx + dx + s, cy - eyeDy - s); ctx.lineTo(cx + dx - s, cy - eyeDy + s);
      ctx.stroke();
    }
  } else if (faceState === "won") {
    ctx.fillStyle = "#000000";
    ctx.fillRect(cx - eyeDx - r * 0.22, cy - eyeDy - r * 0.1, r * 0.44, r * 0.2);
    ctx.fillRect(cx + eyeDx - r * 0.22, cy - eyeDy - r * 0.1, r * 0.44, r * 0.2);
  } else {
    ctx.fillStyle = "#000000";
    for (const dx of [-eyeDx, eyeDx]) {
      ctx.beginPath();
      ctx.arc(cx + dx, cy - eyeDy, r * 0.1, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.beginPath();
  ctx.strokeStyle = "#000000";
  ctx.lineWidth = 2;
  if (faceState === "lost") {
    ctx.arc(cx, cy + r * 0.55, r * 0.35, Math.PI, Math.PI * 2);
  } else {
    ctx.arc(cx, cy + r * 0.25, r * 0.35, 0.15 * Math.PI, 0.85 * Math.PI);
  }
  ctx.stroke();
}

function drawLcdNumber(ctx, x, y, w, h, value) {
  ctx.fillStyle = LCD_BG;
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = LCD_FG;
  ctx.font = `bold ${Math.floor(h * 0.7)}px monospace`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const clamped = Math.max(-9, Math.min(999, value));
  let text = String(clamped).padStart(clamped < 0 ? 2 : 3, "0");
  if (clamped < 0) text = "-" + String(-clamped).padStart(2, "0");
  ctx.fillText(text.slice(-3), x + w / 2, y + h / 2 + 1);
}

/**
 * @param {object} game - a minesweeperEngine game object
 * @returns {Buffer} PNG image buffer
 */
function renderMinesweeperImage(game) {
  const { size, cells, state, mineCount, flagsUsed, explodedIndex } = game;
  const boardPx = size * CELL;
  const width  = boardPx + PANEL_MARGIN * 2;
  const height = HEADER + boardPx + PANEL_MARGIN * 3;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = GRAY;
  ctx.fillRect(0, 0, width, height);
  drawBevel(ctx, 0, 0, width, height, true);

  const headerX = PANEL_MARGIN, headerY = PANEL_MARGIN, headerW = boardPx, headerH = HEADER - PANEL_MARGIN;
  drawBevel(ctx, headerX, headerY, headerW, headerH, false);

  const lcdW = 40, lcdH = headerH - 12, lcdY = headerY + 6;
  drawLcdNumber(ctx, headerX + 8, lcdY, lcdW, lcdH, mineCount - flagsUsed);
  drawLcdNumber(ctx, headerX + headerW - lcdW - 8, lcdY, lcdW, lcdH, flagsUsed);

  const faceR = (headerH - 10) / 2;
  drawFace(ctx, headerX + headerW / 2, headerY + headerH / 2, faceR, state === "playing" ? "playing" : state);

  const boardX = PANEL_MARGIN, boardY = HEADER + PANEL_MARGIN;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const i = r * size + c;
      const cell = cells[i];
      const x = boardX + c * CELL, y = boardY + r * CELL;
      const cx = x + CELL / 2, cy = y + CELL / 2;

      if (!cell.revealed) {
        drawBevel(ctx, x, y, CELL, CELL, true);
        if (cell.flagged) {
          drawFlag(ctx, cx, cy);
          if (state === "lost" && !cell.mine) drawWrongFlagX(ctx, cx, cy);
        }
      } else if (cell.mine) {
        drawMine(ctx, cx, cy, i === explodedIndex);
      } else {
        drawBevel(ctx, x, y, CELL, CELL, false);
        if (cell.adjacent > 0) {
          ctx.fillStyle = NUMBER_COLORS[cell.adjacent] || "#000000";
          ctx.font = `bold ${Math.floor(CELL * 0.55)}px sans-serif`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(String(cell.adjacent), cx, cy + 1);
        }
      }
    }
  }

  return canvas.toBuffer("image/png");
}

module.exports = { renderMinesweeperImage };
