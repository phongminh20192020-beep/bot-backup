"use strict";

// ─────────────────────────────────────────────────────────────────────────
// Engine for the two extra UNO game modes: UNO Flip and UNO No Mercy.
//
// This file is intentionally separate from unoEngine.js (which powers the
// original /uno command) so that classic UNO's code path is never touched
// or risked by these additions. A handful of small, shape-agnostic helpers
// (shuffling, drawing, turn order) are reused from unoEngine.js since they
// don't care what a "card" looks like internally.
//
// Both modes are original, self-consistent house-rule adaptations of the
// real-world games they're named after -- the exact card counts/pairings of
// the retail products aren't reproduced verbatim, but the core mechanics
// that make each mode distinct are all here and documented below.
// ─────────────────────────────────────────────────────────────────────────

const { shuffle, drawCards, advanceTurn, nextIndex } = require("./unoEngine");

const LIGHT_COLORS = ["red", "yellow", "green", "blue"];
const DARK_COLORS  = ["teal", "orange", "purple", "pink"]; // paired 1:1 with LIGHT_COLORS by index

// ═══════════════════════════════════════════════════════════════════════
// UNO FLIP
// ═══════════════════════════════════════════════════════════════════════
//
// RULES:
//  • Every card is a physical two-sided card: a "light" face and a "dark"
//    face. Only one side is active for the whole table at any time
//    (state.side, "light" or "dark") -- everyone's hand, the deck, and the
//    discard pile always show that side.
//  • Light side is the gentler ruleset (closer to classic UNO): Skip,
//    Reverse, Draw One.
//  • Dark side is the harsher mirror ruleset: Skip Everyone (skips every
//    other player, not just the next one), Reverse, Draw Five.
//  • The FLIP card exists on both faces of the same physical cards. Playing
//    it flips the *entire table* (deck, discards, every hand) to the other
//    side for the rest of the game (until another Flip is played).
//  • Wild and Wild Draw Two/Wild Draw Color are colorless on both sides;
//    Wild Draw Two (light) becomes Wild Draw Color (dark) -- its victim
//    must keep drawing, one at a time, until they draw the chosen color.

function pairCard(light, dark) {
  return { light, dark };
}

function buildFlipDeck() {
  const deck = [];
  for (let i = 0; i < 4; i++) {
    const lc = LIGHT_COLORS[i];
    const dc = DARK_COLORS[i];

    deck.push(pairCard({ color: lc, type: "number", value: 0 }, { color: dc, type: "number", value: 0 }));
    for (let v = 1; v <= 9; v++) {
      deck.push(pairCard({ color: lc, type: "number", value: v }, { color: dc, type: "number", value: v }));
      deck.push(pairCard({ color: lc, type: "number", value: v }, { color: dc, type: "number", value: v }));
    }
    for (let k = 0; k < 2; k++) {
      deck.push(pairCard({ color: lc, type: "skip" },    { color: dc, type: "skipall" }));
      deck.push(pairCard({ color: lc, type: "reverse" }, { color: dc, type: "reverse" }));
      deck.push(pairCard({ color: lc, type: "draw1" },   { color: dc, type: "draw5" }));
      deck.push(pairCard({ color: lc, type: "flip" },    { color: dc, type: "flip" }));
    }
  }
  for (let k = 0; k < 4; k++) {
    deck.push(pairCard({ color: "wild", type: "wild" },      { color: "wild", type: "wild" }));
    deck.push(pairCard({ color: "wild", type: "wilddraw2" }, { color: "wild", type: "wilddrawcolor" }));
  }
  return deck;
}

/** The currently-visible face of a duo-card, given the table's active side. */
function face(card, side) {
  return card[side];
}

function flipColorsFor(side) {
  return side === "light" ? LIGHT_COLORS : DARK_COLORS;
}

function flipCardLabel(card, side) {
  const f = face(card, side);
  const colorName = f.color === "wild" ? "Wild" : f.color[0].toUpperCase() + f.color.slice(1);
  const names = {
    number: String(f.value), skip: "Skip", skipall: "Skip Everyone", reverse: "Reverse",
    draw1: "Draw One", draw5: "Draw Five", flip: "Flip", wild: "Wild",
    wilddraw2: "Wild Draw Two", wilddrawcolor: "Wild Draw Color",
  };
  return f.color === "wild" ? names[f.type] : `${colorName} ${names[f.type]}`;
}

function flipCanPlayFace(f, currentColor, topFace) {
  if (f.color === "wild") return true;
  if (f.color === currentColor) return true;
  if (f.type === "number" && topFace.type === "number" && f.value === topFace.value) return true;
  if (f.type !== "number" && f.type === topFace.type) return true;
  return false;
}

function flipCanPlayWildDraw(hand, cardIdx, currentColor, side) {
  return !hand.some((c, i) => i !== cardIdx && face(c, side).color === currentColor);
}

function flipPlayableIndices(hand, state) {
  const topFace = face(state.discard[state.discard.length - 1], state.side);
  const indices = [];
  hand.forEach((card, i) => {
    const f = face(card, state.side);
    if (!flipCanPlayFace(f, state.currentColor, topFace)) return;
    if ((f.type === "wilddraw2" || f.type === "wilddrawcolor") &&
        !flipCanPlayWildDraw(hand, i, state.currentColor, state.side)) return;
    indices.push(i);
  });
  return indices;
}

function flipStartGame(playerInfos) {
  const deck = shuffle(buildFlipDeck());
  const state = {
    mode: "flip",
    side: "light",
    players: playerInfos.map(p => ({ ...p, hand: [] })),
    deck, discard: [], currentColor: null,
    turnIndex: 0, direction: 1, winnerId: null, log: [],
  };
  for (const p of state.players) for (let i = 0; i < 7; i++) p.hand.push(deck.pop());

  let starter;
  do {
    if (deck.length === 0) state.deck = shuffle(buildFlipDeck());
    starter = deck.pop();
    if (face(starter, "light").color === "wild" || face(starter, "light").type === "flip") deck.unshift(starter);
  } while (face(starter, "light").color === "wild" || face(starter, "light").type === "flip");

  state.discard.push(starter);
  const startFace = face(starter, "light");
  state.currentColor = startFace.color;

  if (startFace.type === "skip") advanceTurn(state);
  else if (startFace.type === "reverse") { state.direction = -1; if (state.players.length === 2) advanceTurn(state); }
  else if (startFace.type === "draw1") { drawCards(state, state.players[0], 1); advanceTurn(state); }

  return state;
}

function flipPlayCard(state, playerIdx, cardIdx, chosenColor) {
  const player = state.players[playerIdx];
  const card = player.hand[cardIdx];
  if (!card) throw new Error("That card isn't in your hand anymore.");

  const topFace = face(state.discard[state.discard.length - 1], state.side);
  const f = face(card, state.side);
  if (!flipCanPlayFace(f, state.currentColor, topFace)) {
    throw new Error(`${flipCardLabel(card, state.side)} doesn't match the current color/number.`);
  }
  if ((f.type === "wilddraw2" || f.type === "wilddrawcolor") &&
      !flipCanPlayWildDraw(player.hand, cardIdx, state.currentColor, state.side)) {
    throw new Error(`You still have a card matching the current color, so you can't play ${flipCardLabel(card, state.side)}.`);
  }
  if (f.color === "wild" && !flipColorsFor(state.side).includes(chosenColor)) {
    throw new Error("Choose a color for the wild card.");
  }

  player.hand.splice(cardIdx, 1);
  state.discard.push(card);
  state.currentColor = f.color === "wild" ? chosenColor : f.color;

  if (player.hand.length === 0) { state.winnerId = player.id; return { effect: "win" }; }

  let effect = "none", drawnBy = null, drawnCount = 0, flipped = false;

  if (f.type === "skip") { advanceTurn(state); advanceTurn(state); effect = "skip"; }
  else if (f.type === "skipall") { effect = "skipall"; /* same player goes again -- don't advance */ }
  else if (f.type === "reverse") {
    state.direction *= -1;
    if (state.players.length === 2) { advanceTurn(state); advanceTurn(state); } else advanceTurn(state);
    effect = "reverse";
  } else if (f.type === "draw1" || f.type === "draw5" || f.type === "wilddraw2") {
    const n = f.type === "draw5" ? 5 : (f.type === "wilddraw2" ? 2 : 1);
    advanceTurn(state);
    const victim = state.players[state.turnIndex];
    drawCards(state, victim, n);
    drawnBy = victim.id; drawnCount = n;
    advanceTurn(state);
    effect = f.type;
  } else if (f.type === "wilddrawcolor") {
    advanceTurn(state);
    const victim = state.players[state.turnIndex];
    const targetColor = state.currentColor;
    let drawn = 0;
    for (let guard = 0; guard < 15; guard++) {
      const [c] = drawCards(state, victim, 1);
      if (!c) break;
      drawn++;
      if (face(c, state.side).color === targetColor) break;
    }
    drawnBy = victim.id; drawnCount = drawn;
    advanceTurn(state);
    effect = "wilddrawcolor";
  } else if (f.type === "flip") {
    state.side = state.side === "light" ? "dark" : "light";
    flipped = true;
    advanceTurn(state);
    effect = "flip";
  } else {
    advanceTurn(state);
  }

  return { effect, drawnBy, drawnCount, flipped, newSide: state.side };
}

function flipDrawOnTurn(state, playerIdx) {
  const [card] = drawCards(state, state.players[playerIdx], 1);
  return card ?? null;
}

function flipChooseBotMove(state, playerIdx) {
  const player = state.players[playerIdx];
  const legal = flipPlayableIndices(player.hand, state);
  if (legal.length === 0) return { action: "draw" };

  const priority = idx => {
    const f = face(player.hand[idx], state.side);
    if (["skip", "skipall", "reverse", "draw1", "draw5", "wilddraw2", "wilddrawcolor"].includes(f.type)) return 0;
    if (f.type === "number") return 1;
    if (f.type === "flip") return 2;
    return 3; // plain wild
  };
  legal.sort((a, b) => priority(a) - priority(b));
  const cardIdx = legal[0];
  const f = face(player.hand[cardIdx], state.side);

  let chosenColor = null;
  if (f.color === "wild") {
    const palette = flipColorsFor(state.side);
    const counts = Object.fromEntries(palette.map(c => [c, 0]));
    player.hand.forEach((c, i) => { const cf = face(c, state.side); if (i !== cardIdx && cf.color !== "wild") counts[cf.color] = (counts[cf.color] || 0) + 1; });
    const best = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    chosenColor = best && best[1] > 0 ? best[0] : palette[Math.floor(Math.random() * palette.length)];
  }
  return { action: "play", cardIdx, chosenColor };
}

// ═══════════════════════════════════════════════════════════════════════
// UNO NO MERCY
// ═══════════════════════════════════════════════════════════════════════
//
// RULES (classic colors, meaner deck):
//  • Draw Six and Draw Ten join Draw Two / Wild Draw Four as attack cards.
//  • Draw cards STACK: if you're hit with a draw card, you may play any
//    other draw card from your hand (regardless of color) to pass the
//    (now larger) draw total to the next player instead of drawing. The
//    stack only resolves -- forcing a draw of the accumulated total -- once
//    someone can't or won't add to it.
//  • Skip Everyone: every other player is skipped and you go again.
//  • Discard All: when played, you also discard every other card in your
//    hand that matches the color just played -- a huge tempo swing.
//  • Number 0: everyone passes their whole hand to the next player in the
//    current direction of play.
//  • Number 7: the player who plays it swaps their entire hand with a
//    player of their choice.
//  • Reverse acts as a Skip in a 2-player game, as in classic UNO.

const DRAW_TYPES = ["draw2", "draw4", "draw6", "draw10"];
const DRAW_VALUE = { draw2: 2, draw4: 4, draw6: 6, draw10: 10 };

function buildNoMercyDeck() {
  const deck = [];
  for (const color of LIGHT_COLORS) {
    deck.push({ color, type: "number", value: 0 });
    for (let v = 1; v <= 9; v++) {
      deck.push({ color, type: "number", value: v });
      deck.push({ color, type: "number", value: v });
    }
    for (let k = 0; k < 2; k++) {
      deck.push({ color, type: "skip" });
      deck.push({ color, type: "reverse" });
      deck.push({ color, type: "draw2" });
    }
    deck.push({ color, type: "draw6" });
    deck.push({ color, type: "draw10" });
    deck.push({ color, type: "skipall" });
    deck.push({ color, type: "discardall" });
  }
  for (let k = 0; k < 4; k++) {
    deck.push({ color: "wild", type: "wild" });
    deck.push({ color: "wild", type: "draw4" });
  }
  return deck;
}

function nmCardLabel(card) {
  const colorName = card.color === "wild" ? "Wild" : card.color[0].toUpperCase() + card.color.slice(1);
  const names = {
    number: String(card.value), skip: "Skip", reverse: "Reverse", draw2: "Draw Two",
    draw6: "Draw Six", draw10: "Draw Ten", skipall: "Skip Everyone", discardall: "Discard All",
    wild: "Wild", draw4: "Wild Draw Four",
  };
  return card.color === "wild" ? names[card.type] : `${colorName} ${names[card.type]}`;
}

function nmCanPlay(card, state) {
  if (state.pendingDraw) return DRAW_TYPES.includes(card.type); // must stack, color irrelevant
  if (card.color === "wild") return true;
  const topCard = state.discard[state.discard.length - 1];
  if (card.color === state.currentColor) return true;
  if (card.type === "number" && topCard.type === "number" && card.value === topCard.value) return true;
  if (card.type !== "number" && card.type === topCard.type) return true;
  return false;
}

function nmCanPlayWildFour(hand, cardIdx, currentColor) {
  return !hand.some((c, i) => i !== cardIdx && c.color === currentColor);
}

function nmPlayableIndices(hand, state) {
  const indices = [];
  hand.forEach((card, i) => {
    if (!nmCanPlay(card, state)) return;
    if (card.type === "draw4" && !state.pendingDraw && !nmCanPlayWildFour(hand, i, state.currentColor)) return;
    indices.push(i);
  });
  return indices;
}

function noMercyStartGame(playerInfos) {
  const deck = shuffle(buildNoMercyDeck());
  const state = {
    mode: "no_mercy",
    players: playerInfos.map(p => ({ ...p, hand: [] })),
    deck, discard: [], currentColor: null,
    turnIndex: 0, direction: 1, winnerId: null, log: [],
    pendingDraw: null,
  };
  for (const p of state.players) for (let i = 0; i < 7; i++) p.hand.push(deck.pop());

  let starter;
  do {
    if (deck.length === 0) state.deck = shuffle(buildNoMercyDeck());
    starter = deck.pop();
    if (starter.color === "wild") deck.unshift(starter);
  } while (starter.color === "wild");

  state.discard.push(starter);
  state.currentColor = starter.color;

  if (starter.type === "skip") advanceTurn(state);
  else if (starter.type === "reverse") { state.direction = -1; if (state.players.length === 2) advanceTurn(state); }
  else if (starter.type === "draw2") { drawCards(state, state.players[0], 2); advanceTurn(state); }
  else if (starter.type === "draw6") { drawCards(state, state.players[0], 6); advanceTurn(state); }
  else if (starter.type === "draw10") { drawCards(state, state.players[0], 10); advanceTurn(state); }

  return state;
}

function rotateHands(state) {
  const n = state.players.length;
  const hands = state.players.map(p => p.hand);
  // Each seat receives the hand from the player "behind" them in the
  // current direction of play, so hands move forward around the table.
  for (let i = 0; i < n; i++) {
    const fromIdx = (i - state.direction + n) % n;
    state.players[i].hand = hands[fromIdx];
  }
}

/**
 * @returns {{effect, drawnBy?, drawnCount?, pendingDrawCount?, needsSevenTarget?}}
 */
function noMercyPlayCard(state, playerIdx, cardIdx, chosenColor) {
  const player = state.players[playerIdx];
  const card = player.hand[cardIdx];
  if (!card) throw new Error("That card isn't in your hand anymore.");
  if (!nmCanPlay(card, state)) {
    throw new Error(state.pendingDraw
      ? `You must play a Draw card to stack, or draw ${state.pendingDraw.count} cards.`
      : `${nmCardLabel(card)} doesn't match the current color/number.`);
  }
  if (card.type === "draw4" && !state.pendingDraw && !nmCanPlayWildFour(player.hand, cardIdx, state.currentColor)) {
    throw new Error("You still have a card matching the current color, so you can't play Wild Draw Four.");
  }
  if (card.color === "wild" && !LIGHT_COLORS.includes(chosenColor)) {
    throw new Error("Choose a color for the wild card.");
  }

  player.hand.splice(cardIdx, 1);
  state.discard.push(card);
  state.currentColor = card.color === "wild" ? chosenColor : card.color;

  if (player.hand.length === 0) { state.winnerId = player.id; return { effect: "win" }; }

  let effect = "none";

  if (DRAW_TYPES.includes(card.type)) {
    const add = DRAW_VALUE[card.type];
    state.pendingDraw = { count: (state.pendingDraw?.count || 0) + add };
    advanceTurn(state);
    effect = "draw_stack";
  } else if (card.type === "skip") {
    advanceTurn(state); advanceTurn(state);
    effect = "skip";
  } else if (card.type === "skipall") {
    effect = "skipall"; // current player goes again
  } else if (card.type === "reverse") {
    state.direction *= -1;
    if (state.players.length === 2) { advanceTurn(state); advanceTurn(state); } else advanceTurn(state);
    effect = "reverse";
  } else if (card.type === "discardall") {
    const matchColor = card.color;
    const kept = [];
    let discarded = 0;
    for (const c of player.hand) {
      if (c.color === matchColor) { state.discard.push(c); discarded++; } else kept.push(c);
    }
    player.hand = kept;
    if (player.hand.length === 0) { state.winnerId = player.id; return { effect: "win", extraDiscarded: discarded }; }
    advanceTurn(state);
    effect = "discardall";
    return { effect, extraDiscarded: discarded };
  } else if (card.type === "number" && card.value === 0) {
    rotateHands(state);
    advanceTurn(state);
    effect = "zero_rotate";
  } else if (card.type === "number" && card.value === 7) {
    // Turn advance is deferred until the caller resolves the swap target
    // via noMercyResolveSeven(); the acting player has not moved on yet.
    effect = "seven_pending";
    return { effect, needsSevenTarget: true, fromIdx: playerIdx };
  } else {
    advanceTurn(state);
  }

  return { effect };
}

/** Resolve a pending Number-7 swap once a target player has been chosen. */
function noMercyResolveSeven(state, fromIdx, targetIdx) {
  const a = state.players[fromIdx], b = state.players[targetIdx];
  const tmp = a.hand; a.hand = b.hand; b.hand = tmp;
  advanceTurn(state);
}

/** Called when a player facing a pending draw stack draws instead of stacking. */
function noMercyForceDrawStack(state, playerIdx) {
  const count = state.pendingDraw.count;
  drawCards(state, state.players[playerIdx], count);
  state.pendingDraw = null;
  advanceTurn(state);
  return count;
}

function noMercyDrawOnTurn(state, playerIdx) {
  const [card] = drawCards(state, state.players[playerIdx], 1);
  return card ?? null;
}

function noMercyChooseBotMove(state, playerIdx) {
  const player = state.players[playerIdx];
  const legal = nmPlayableIndices(player.hand, state);
  if (legal.length === 0) return { action: "draw" };

  const priority = idx => {
    const c = player.hand[idx];
    if (state.pendingDraw) return -DRAW_VALUE[c.type]; // stack the biggest draw card it has
    if (DRAW_TYPES.includes(c.type) || ["skip", "skipall", "reverse", "discardall"].includes(c.type)) return 0;
    if (c.type === "number") return 1;
    return 2; // plain wild
  };
  legal.sort((a, b) => priority(a) - priority(b));
  const cardIdx = legal[0];
  const card = player.hand[cardIdx];

  let chosenColor = null;
  if (card.color === "wild") {
    const counts = { red: 0, yellow: 0, green: 0, blue: 0 };
    player.hand.forEach((c, i) => { if (i !== cardIdx && c.color !== "wild") counts[c.color]++; });
    const best = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    chosenColor = best[1] > 0 ? best[0] : LIGHT_COLORS[Math.floor(Math.random() * 4)];
  }

  let sevenTargetIdx = null;
  if (card.type === "number" && card.value === 7) {
    // "No mercy": swap with whoever currently has the fewest cards.
    let best = -1, bestLen = Infinity;
    state.players.forEach((p, i) => {
      if (i === playerIdx) return;
      if (p.hand.length < bestLen) { bestLen = p.hand.length; best = i; }
    });
    sevenTargetIdx = best;
  }

  return { action: "play", cardIdx, chosenColor, sevenTargetIdx };
}

module.exports = {
  LIGHT_COLORS, DARK_COLORS,
  // Flip
  buildFlipDeck, face, flipColorsFor, flipCardLabel, flipCanPlayFace,
  flipCanPlayWildDraw, flipPlayableIndices, flipStartGame, flipPlayCard,
  flipDrawOnTurn, flipChooseBotMove,
  // No Mercy
  DRAW_TYPES, buildNoMercyDeck, nmCardLabel, nmCanPlay, nmCanPlayWildFour,
  nmPlayableIndices, noMercyStartGame, noMercyPlayCard, noMercyResolveSeven,
  noMercyForceDrawStack, noMercyDrawOnTurn, noMercyChooseBotMove, rotateHands,
};
