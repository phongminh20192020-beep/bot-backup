"use strict";

/** Every cell index adjacent to `i` on a size x size board (max 8 neighbors). */
function neighborsOf(i, size) {
  const r = Math.floor(i / size), c = i % size;
  const out = [];
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (dr === 0 && dc === 0) continue;
      const nr = r + dr, nc = c + dc;
      if (nr >= 0 && nr < size && nc >= 0 && nc < size) out.push(nr * size + nc);
    }
  }
  return out;
}

/**
 * @param {number} size - board is size x size (8 for classic small XP-style board)
 * @param {number} mineCount
 * @returns {object} a fresh game state
 *
 * Mines are NOT placed here anymore -- they're placed on the first `reveal()`
 * call, excluding the clicked cell and its neighbors, so the very first dig
 * always opens up a safe (usually cascading) area instead of risking an
 * instant single-number reveal or worse, an instant loss.
 */
function createGame(size = 8, mineCount = 10) {
  const total = size * size;

  const cells = Array.from({ length: total }, () => ({
    mine:     false,
    revealed: false,
    flagged:  false,
    adjacent: 0, // filled in once mines are placed
  }));

  return {
    size,
    mineCount,
    cells,
    state:         "playing", // "playing" | "won" | "lost"
    revealedCount: 0,
    flagsUsed:     0,
    explodedIndex: null, // which mine actually got clicked, for the render to highlight
    minesPlaced:   false, // becomes true after the first reveal() call
  };
}

/** Places mines randomly, avoiding `safeIndex` and all of its neighbors, then computes adjacency counts. */
function placeMines(game, safeIndex) {
  const total = game.size * game.size;
  const excluded = new Set([safeIndex, ...neighborsOf(safeIndex, game.size)]);

  // If the exclusion zone is too big for the requested mine count (tiny
  // boards / huge mine counts), fall back to just excluding the clicked
  // cell itself so we don't spin forever.
  const available = total - excluded.size;
  const useExclusion = available >= game.mineCount;
  const forbidden = useExclusion ? excluded : new Set([safeIndex]);

  const mineSet = new Set();
  while (mineSet.size < game.mineCount) {
    const idx = Math.floor(Math.random() * total);
    if (forbidden.has(idx)) continue;
    mineSet.add(idx);
  }

  game.cells.forEach((cell, i) => {
    cell.mine = mineSet.has(i);
  });
  game.cells.forEach((cell, i) => {
    if (cell.mine) return;
    cell.adjacent = neighborsOf(i, game.size).filter(n => game.cells[n].mine).length;
  });

  game.minesPlaced = true;
}

function checkWin(game) {
  const nonMineTotal = game.size * game.size - game.mineCount;
  if (game.revealedCount >= nonMineTotal) {
    game.state = "won";
    // Auto-flag any remaining unflagged mines so the final board reads
    // cleanly -- and keep flagsUsed in sync, since the header LCDs read
    // straight from that counter rather than re-scanning cells.
    game.cells.forEach(c => {
      if (c.mine && !c.flagged) {
        c.flagged = true;
        game.flagsUsed++;
      }
    });
  }
}

/** Reveals cell `i` -- flood-fills outward through any connected zero-adjacent cells. */
function reveal(game, i) {
  if (game.state !== "playing") return;

  if (!game.minesPlaced) {
    placeMines(game, i);
  }

  const cell = game.cells[i];
  if (!cell || cell.revealed || cell.flagged) return;

  if (cell.mine) {
    cell.revealed = true;
    game.state = "lost";
    game.explodedIndex = i;
    game.cells.forEach(c => { if (c.mine) c.revealed = true; }); // reveal all mines on loss
    return;
  }

  // Iterative flood-fill (not recursive) -- an 8x8 board is tiny either way,
  // but there's no reason to risk stack depth for a board size that might
  // get bumped up later.
  const stack = [i];
  while (stack.length) {
    const idx = stack.pop();
    const c = game.cells[idx];
    if (!c || c.revealed || c.flagged) continue;
    c.revealed = true;
    game.revealedCount++;
    if (c.adjacent === 0) {
      for (const n of neighborsOf(idx, game.size)) {
        const nc = game.cells[n];
        if (nc && !nc.revealed && !nc.flagged && !nc.mine) stack.push(n);
      }
    }
  }

  checkWin(game);
}

/** Toggles a flag on cell `i`. No-ops on revealed cells or once the game's over. */
function toggleFlag(game, i) {
  if (game.state !== "playing") return;
  const cell = game.cells[i];
  if (!cell || cell.revealed) return;
  cell.flagged = !cell.flagged;
  game.flagsUsed += cell.flagged ? 1 : -1;
}

module.exports = { createGame, reveal, toggleFlag };