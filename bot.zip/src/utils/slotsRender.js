"use strict";

const { createCanvas } = require("@napi-rs/canvas");
const { INK, BG, roundedRectPath } = require("./canvasDoodle");

const W = 420;
const H = 220;
const REEL_W = 110;
const REEL_H = 140;
const REEL_GAP = 20;

/** Each symbol drawn as a distinct vector icon -- no emoji font dependency. */
function drawSymbol(ctx, key, cx, cy, size) {
  switch (key) {
    case "cherry": {
      ctx.strokeStyle = "#6b3f2a";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy - size * 0.5);
      ctx.lineTo(cx - size * 0.15, cy - size * 0.05);
      ctx.moveTo(cx, cy - size * 0.5);
      ctx.lineTo(cx + size * 0.2, cy + size * 0.05);
      ctx.stroke();
      ctx.fillStyle = "#d1352b";
      for (const dx of [-1, 1]) {
        ctx.beginPath();
        ctx.arc(cx + dx * size * 0.18, cy + (dx < 0 ? -0.05 : 0.05) * size, size * 0.2, 0, Math.PI * 2);
        ctx.fill();
      }
      return;
    }
    case "lemon": {
      ctx.fillStyle = "#e8c93a";
      ctx.beginPath();
      ctx.ellipse(cx, cy, size * 0.32, size * 0.24, Math.PI / 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      return;
    }
    case "grape": {
      ctx.fillStyle = "#7c4dad";
      const pts = [[0, -0.22], [-0.18, -0.02], [0.18, -0.02], [-0.1, 0.2], [0.1, 0.2], [0, 0.35]];
      for (const [dx, dy] of pts) {
        ctx.beginPath();
        ctx.arc(cx + dx * size, cy + dy * size, size * 0.15, 0, Math.PI * 2);
        ctx.fill();
      }
      return;
    }
    case "bell": {
      ctx.fillStyle = "#e0a828";
      ctx.beginPath();
      ctx.moveTo(cx - size * 0.24, cy + size * 0.15);
      ctx.quadraticCurveTo(cx - size * 0.28, cy - size * 0.3, cx, cy - size * 0.35);
      ctx.quadraticCurveTo(cx + size * 0.28, cy - size * 0.3, cx + size * 0.24, cy + size * 0.15);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.fillRect(cx - size * 0.28, cy + size * 0.15, size * 0.56, size * 0.06);
      ctx.beginPath();
      ctx.arc(cx, cy + size * 0.26, size * 0.06, 0, Math.PI * 2);
      ctx.fill();
      return;
    }
    case "diamond": {
      ctx.fillStyle = "#3fb6d6";
      ctx.beginPath();
      ctx.moveTo(cx, cy - size * 0.32);
      ctx.lineTo(cx + size * 0.26, cy);
      ctx.lineTo(cx, cy + size * 0.32);
      ctx.lineTo(cx - size * 0.26, cy);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      return;
    }
    case "seven": {
      ctx.fillStyle = "#d1352b";
      ctx.font = `bold ${Math.floor(size * 0.8)}px sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("7", cx, cy);
      return;
    }
  }
}

/**
 * @param {string[]} symbolKeys - 3 keys: cherry|lemon|grape|bell|diamond|seven
 * @returns {Buffer} PNG image buffer
 */
function renderSlots(symbolKeys) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, H);

  const totalW = REEL_W * 3 + REEL_GAP * 2;
  const startX = (W - totalW) / 2;
  const top = (H - REEL_H) / 2;

  for (let i = 0; i < 3; i++) {
    const x = startX + i * (REEL_W + REEL_GAP);
    roundedRectPath(ctx, x, top, REEL_W, REEL_H, 10);
    ctx.fillStyle = "#f4f4f4";
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    ctx.stroke();

    drawSymbol(ctx, symbolKeys[i], x + REEL_W / 2, top + REEL_H / 2, REEL_H * 0.7);
  }

  return canvas.toBuffer("image/png");
}

module.exports = { renderSlots };
