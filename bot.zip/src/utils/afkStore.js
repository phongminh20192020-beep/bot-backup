"use strict";

const fs   = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "../../data");
const FILE     = path.join(DATA_DIR, "afk.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// Single global AFK status per user (not per-guild), same convention as economy.js.
let cache = null;

function load() {
  if (cache) return cache;
  try {
    cache = fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE, "utf8")) : {};
  } catch (err) {
    console.error("[AFK] Failed to load afk.json, starting fresh:", err.message);
    cache = {};
  }
  return cache;
}

function persist() {
  try {
    fs.writeFileSync(FILE, JSON.stringify(cache, null, 2));
  } catch (err) {
    console.error("[AFK] Failed to save afk.json:", err.message);
  }
}

function setAfk(userId, reason = "AFK") {
  const data = load();
  data[userId] = { reason, since: Date.now() };
  persist();
  return data[userId];
}

/** Removes and returns the user's AFK entry, or null if they weren't AFK. */
function clearAfk(userId) {
  const data = load();
  const entry = data[userId] ?? null;
  if (entry) {
    delete data[userId];
    persist();
  }
  return entry;
}

function getAfk(userId) {
  return load()[userId] ?? null;
}

function isAfk(userId) {
  return !!getAfk(userId);
}

module.exports = { setAfk, clearAfk, getAfk, isAfk };
