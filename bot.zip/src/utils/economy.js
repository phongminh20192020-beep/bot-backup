"use strict";

const fs   = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "../../data");
const FILE     = path.join(DATA_DIR, "economy.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DAILY_AMOUNT      = 1000;
const DAILY_COOLDOWN_MS = 24 * 60 * 60 * 1000;

// Single global wallet per user (not per-guild) — a user's balance is the
// same no matter which server they run commands in, same as most economy
// bots. Loaded once into memory and persisted to disk on every mutation;
// fine at Discord-bot scale, no need for a real DB here.
let cache = null;

function load() {
  if (cache) return cache;
  try {
    cache = fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE, "utf8")) : {};
  } catch (err) {
    console.error("[Economy] Failed to load economy.json, starting fresh:", err.message);
    cache = {};
  }
  return cache;
}

function persist() {
  try {
    fs.writeFileSync(FILE, JSON.stringify(cache, null, 2));
  } catch (err) {
    console.error("[Economy] Failed to save economy.json:", err.message);
  }
}

function getUser(userId) {
  const data = load();
  if (!data[userId]) data[userId] = { balance: 0, lastDaily: 0 };
  return data[userId];
}

function getBalance(userId) {
  return getUser(userId).balance;
}

function addCoins(userId, amount) {
  if (!Number.isFinite(amount) || amount < 0) throw new RangeError("amount must be a non-negative number");
  const user = getUser(userId);
  user.balance += amount;
  persist();
  return user.balance;
}

/**
 * Deduct coins if the user can afford it. Returns false (and makes no
 * change) if their balance is too low -- callers should check this before
 * letting someone place a bet.
 */
function removeCoins(userId, amount) {
  if (!Number.isFinite(amount) || amount < 0) throw new RangeError("amount must be a non-negative number");
  const user = getUser(userId);
  if (user.balance < amount) return false;
  user.balance -= amount;
  persist();
  return true;
}

/**
 * Attempt to claim the daily reward.
 * @returns {{success:true, amount:number, balance:number} | {success:false, remainingMs:number}}
 */
function claimDaily(userId) {
  const user    = getUser(userId);
  const now     = Date.now();
  const elapsed = now - user.lastDaily;

  if (elapsed < DAILY_COOLDOWN_MS) {
    return { success: false, remainingMs: DAILY_COOLDOWN_MS - elapsed };
  }

  user.lastDaily = now;
  user.balance  += DAILY_AMOUNT;
  persist();
  return { success: true, amount: DAILY_AMOUNT, balance: user.balance };
}

module.exports = {
  getBalance,
  addCoins,
  removeCoins,
  claimDaily,
  DAILY_AMOUNT,
  DAILY_COOLDOWN_MS,
};
