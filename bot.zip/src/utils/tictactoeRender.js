"use strict";

const { createCanvas } = require("@napi-rs/canvas");

// Canvas-drawn tic-tac-toe board, matching the same hand-sketched-doodle
// look used for hangman/wordle instead of plain button labels. The buttons
// underneath the image stay as the actual click targets (blank-labeled),
// so gameplay is unchanged -- this just gives the board itself a proper
// drawn look instead of relying on emoji glyphs baked into button text.

const SIZE      = 360;
const CELL      = SIZE / 3;
const INK       = "#1b1b1f"; // grid lines
const X_COLOR   = "#e0503f"; // warm red, hand-drawn
const O_COLOR   = "#3a7bd5"; // blue, hand-drawn
const BG        = "#ffffff";

/** A slightly wobbly line between two points, for a hand-drawn feel. */
function wobblyLine(ctx, x1, y1, x2, y2, bow = 4) {
  const mx = (x1 + x2) / 2 + bow;
  const my = (y1 + y2) / 2 - bow;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(mx, my, x2, y2);
  ctx.stroke();
}

function drawGrid(ctx) {
  ctx.strokeStyle = INK;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";

  wobblyLine(ctx, CELL,     16, CELL,     SIZE - 16, 3);
  wobblyLine(ctx, CELL * 2, 16, CELL * 2, SIZE - 16, -3);
  wobblyLine(ctx, 16,     CELL,     SIZE - 16, CELL,     -3);
  wobblyLine(ctx, 16,     CELL * 2, SIZE - 16, CELL * 2, 3);
}

function drawX(ctx, cx, cy) {
  const r = CELL * 0.3;
  ctx.strokeStyle = X_COLOR;
  ctx.lineWidth = 8;
  ctx.lineCap = "round";
  wobblyLine(ctx, cx - r, cy - r, cx + r, cy + r, 5);
  wobblyLine(ctx, cx + r, cy - r, cx - r, cy + r, -5);
}

function drawO(ctx, cx, cy) {
  const r = CELL * 0.32;
  ctx.strokeStyle = O_COLOR;
  ctx.lineWidth = 8;
  ctx.lineCap = "round";
  ctx.beginPath();
  // Slight rotation + non-perfect radii so it doesn't look computer-drawn.
  ctx.ellipse(cx, cy, r, r * 1.06, 0.08, 0, Math.PI * 2);
  ctx.stroke();
}

/**
 * @param {(("X"|"O"|null))[]} board - 9 cells, row-major, "X"/"O"/null.
 * @returns {Buffer} PNG image buffer.
 */
function renderTicTacToeImage(board) {
  const canvas = createCanvas(SIZE, SIZE);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, SIZE, SIZE);

  drawGrid(ctx);

  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const mark = board[r * 3 + c];
      if (!mark) continue;
      const cx = c * CELL + CELL / 2;
      const cy = r * CELL + CELL / 2;
      if (mark === "X") drawX(ctx, cx, cy);
      else drawO(ctx, cx, cy);
    }
  }

  return canvas.toBuffer("image/png");
}

module.exports = { renderTicTacToeImage };
