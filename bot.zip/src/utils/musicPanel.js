"use strict";

const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js");
const { formatDuration, progressBar } = require("./helpers");

const SEEK_MS = 10_000;

const EMOJI = {
  play:     { id: "1537804167568166963", name: "Play" },
  pause:    { id: "1537804165760426014", name: "Pause" },
  skip:     { id: "1537804163860275210", name: "Skip" },
  previous: { id: "1537804161960378388", name: "Previous" },
  rvSkip:   { id: "1552537766770774136", name: "rv_skip" },
};

// Discord buttons only come in 5 colors (Blurple/Grey/Green/Red/Link) --
// there's no real "brown" option. Both states are set to Secondary (grey)
// here, so the playpause button no longer changes color when toggled.
const ACTIVE_STYLE  = ButtonStyle.Secondary;
const DEFAULT_STYLE = ButtonStyle.Secondary;

function buildNowPlayingEmbed(player) {
  const track = player?.queue?.current;
  if (!track) return null;

  const position = player.position;
  const duration = track.info.duration || 0;
  const bar = track.info.isStream || !duration ? "<:Live:1537804170961096714> LIVE" : progressBar(position, duration);

  return new EmbedBuilder()
    .setTitle("Now Playing")
    .setDescription(`**[${track.info.title}](${track.info.uri})**`)
    .addFields(
      { name: "Author",       value: track.info.author || "Unknown",         inline: true },
      { name: "Requested By", value: track.requester?.username || "Unknown", inline: true },
      {
        name:  "\u200b",
        value: track.info.isStream
          ? `<:Live:1537804170961096714> LIVE  ${bar}`
          : `${formatDuration(position)}  ${bar}`,
      }
    )
    .setThumbnail(
      track.info.artworkUrl?.trim() ||
      (track.info.identifier ? `https://img.youtube.com/vi/${track.info.identifier}/mqdefault.jpg` : null)
    );
}

// Emoji-only buttons: no setLabel() calls at all (empty labels throw in discord.js).
function buildControlRow(player) {
  const isPlaying = !!player?.playing && !player?.paused;

  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("music_previous")
      .setEmoji(EMOJI.previous)
      .setStyle(DEFAULT_STYLE),
    new ButtonBuilder()
      .setCustomId("music_seekback")
      .setEmoji(EMOJI.rvSkip)
      .setStyle(DEFAULT_STYLE),
    new ButtonBuilder()
      .setCustomId("music_playpause")
      .setEmoji(isPlaying ? EMOJI.pause : EMOJI.play)
      .setStyle(isPlaying ? ACTIVE_STYLE : DEFAULT_STYLE),
    new ButtonBuilder()
      .setCustomId("music_seekfwd")
      .setEmoji(EMOJI.skip)
      .setStyle(DEFAULT_STYLE),
    new ButtonBuilder()
      .setCustomId("music_next")
      .setEmoji(EMOJI.play)
      .setStyle(DEFAULT_STYLE),
  );
}

// Plays the last track from queue.previous, putting the track that was
// playing back at the front of the upcoming queue first so it isn't lost --
// player.play({ clientTrack }) replaces queue.current outright and does not
// preserve the old one on its own.
async function playPrevious(player) {
  const prevTrack = await player.queue.shiftPrevious();
  if (!prevTrack) return null;

  const wasPlaying = player.queue.current;
  if (wasPlaying) await player.queue.add(wasPlaying, 0);

  await player.play({ clientTrack: prevTrack });
  return prevTrack;
}

async function handleMusicButton(interaction, client) {
  const player = client.lavalink.getPlayer(interaction.guildId);
  if (!player || !player.queue.current)
    return interaction.reply({ content: "Nothing is currently playing.", ephemeral: true }).catch(() => {});

  const voiceChannel = interaction.member?.voice?.channel;
  if (!voiceChannel || voiceChannel.id !== player.voiceChannelId)
    return interaction.reply({ content: "You need to be in the same voice channel as me to use these controls.", ephemeral: true }).catch(() => {});

  const track = player.queue.current;

  try {
    switch (interaction.customId) {
      case "music_playpause": {
        if (player.paused) await player.resume();
        else                await player.pause(true);
        break;
      }

      case "music_seekback": {
        if (track.info.isStream) return interaction.reply({ content: "Can't seek in a live stream.", ephemeral: true }).catch(() => {});
        if (!track.info.isSeekable) return interaction.reply({ content: "This track doesn't support seeking.", ephemeral: true }).catch(() => {});
        await player.seek(Math.max(0, player.position - SEEK_MS));
        break;
      }

      case "music_seekfwd": {
        if (track.info.isStream) return interaction.reply({ content: "Can't seek in a live stream.", ephemeral: true }).catch(() => {});
        if (!track.info.isSeekable) return interaction.reply({ content: "This track doesn't support seeking.", ephemeral: true }).catch(() => {});
        const max = track.info.duration || Infinity;
        await player.seek(Math.min(Math.max(0, max - 1000), player.position + SEEK_MS));
        break;
      }

      case "music_next": {
        await player.skip();
        break;
      }

      case "music_previous": {
        const prev = await playPrevious(player);
        if (!prev)
          return interaction.reply({ content: "No previous track to go back to.", ephemeral: true }).catch(() => {});
        break;
      }

      default:
        return;
    }
  } catch (err) {
    console.error(`[MusicPanel/${interaction.customId}]`, err.message);
    return interaction.reply({ content: "Couldn't do that — the audio node isn't responding right now. Try again in a moment.", ephemeral: true }).catch(() => {});
  }

  // Give Lavalink a beat to reflect the new state (pause/seek/skip/previous)
  // before re-rendering the panel off of it.
  await new Promise(r => setTimeout(r, 250));

  const freshPlayer = client.lavalink.getPlayer(interaction.guildId);
  if (!freshPlayer?.queue.current)
    return interaction.update({ content: "Playback ended.", embeds: [], components: [] }).catch(() => {});

  await interaction.update({
    embeds:     [buildNowPlayingEmbed(freshPlayer)],
    components: [buildControlRow(freshPlayer)],
  }).catch(() => {});
}

module.exports = { EMOJI, buildNowPlayingEmbed, buildControlRow, playPrevious, handleMusicButton };