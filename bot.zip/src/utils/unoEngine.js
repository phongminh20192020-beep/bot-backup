"use strict";

const COLORS = ["red", "yellow", "green", "blue"];

// ─── Deck ───────────────────────────────────────────────────────────────────
// Standard 108-card UNO deck. No stacking of draw2/draw4 (a common house
// rule) -- a draw card always forces an immediate, fixed draw on the next
// player and ends their turn, which keeps turn resolution simple and
// unambiguous for a bot to referee.
function freshDeck() {
  const deck = [];
  for (const color of COLORS) {
    deck.push({ color, type: "number", value: 0 });
    for (let v = 1; v <= 9; v++) {
      deck.push({ color, type: "number", value: v });
      deck.push({ color, type: "number", value: v });
    }
    for (let i = 0; i < 2; i++) {
      deck.push({ color, type: "skip" });
      deck.push({ color, type: "reverse" });
      deck.push({ color, type: "draw2" });
    }
  }
  for (let i = 0; i < 4; i++) {
    deck.push({ color: "wild", type: "wild" });
    deck.push({ color: "wild", type: "wild4" });
  }
  return deck;
}

function shuffle(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function cardLabel(card) {
  const colorName = card.color === "wild" ? "Wild" : card.color[0].toUpperCase() + card.color.slice(1);
  if (card.type === "number")  return `${colorName} ${card.value}`;
  if (card.type === "skip")    return `${colorName} Skip`;
  if (card.type === "reverse") return `${colorName} Reverse`;
  if (card.type === "draw2")   return `${colorName} Draw Two`;
  if (card.type === "wild")    return "Wild";
  if (card.type === "wild4")   return "Wild Draw Four";
  return colorName;
}

function cardEmoji(card) {
  if (card.color === "wild") return "🎨";
  return { red: "🟥", yellow: "🟨", green: "🟩", blue: "🟦" }[card.color];
}

// ─── Legality ───────────────────────────────────────────────────────────────
function canPlay(card, currentColor, topCard) {
  if (card.color === "wild") return true; // wild4's extra restriction is checked separately
  if (card.color === currentColor) return true;
  if (topCard.type === "number" && card.type === "number" && card.value === topCard.value) return true;
  if (card.type !== "number" && card.type === topCard.type) return true;
  return false;
}

function canPlayWildFour(hand, cardIdx, currentColor) {
  return !hand.some((c, i) => i !== cardIdx && c.color === currentColor);
}

function playableIndices(hand, currentColor, topCard) {
  const indices = [];
  hand.forEach((card, i) => {
    if (!canPlay(card, currentColor, topCard)) return;
    if (card.type === "wild4" && !canPlayWildFour(hand, i, currentColor)) return;
    indices.push(i);
  });
  return indices;
}

// ─── State helpers ──────────────────────────────────────────────────────────
function nextIndex(state) {
  const n = state.players.length;
  return (state.turnIndex + state.direction + n) % n;
}

function advanceTurn(state) {
  state.turnIndex = nextIndex(state);
}

function reshuffleFromDiscard(state) {
  if (state.discard.length <= 1) return; // nothing to reshuffle
  const top  = state.discard.pop();
  const rest = state.discard;
  state.discard = [top];
  state.deck = shuffle(rest);
}

function drawCards(state, player, n) {
  const drawn = [];
  for (let i = 0; i < n; i++) {
    if (state.deck.length === 0) reshuffleFromDiscard(state);
    if (state.deck.length === 0) break; // both deck and discard exhausted -- extremely unlikely
    const card = state.deck.pop();
    player.hand.push(card);
    drawn.push(card);
  }
  return drawn;
}

// ─── Game setup ─────────────────────────────────────────────────────────────
/**
 * @param {Array<{id:string, isBot:boolean, username:string}>} playerInfos - in seating/turn order
 */
function startGame(playerInfos) {
  const deck = shuffle(freshDeck());
  const state = {
    players: playerInfos.map(p => ({ ...p, hand: [] })),
    deck,
    discard: [],
    currentColor: null,
    turnIndex: 0,
    direction: 1,
    winnerId: null,
    log: [],
  };

  for (const p of state.players) {
    for (let i = 0; i < 7; i++) p.hand.push(deck.pop());
  }

  // Flip the starting card; if it's a wild, shuffle it back in and try again.
  let starter;
  do {
    if (deck.length === 0) { state.deck = shuffle(freshDeck().filter(() => true)); }
    starter = deck.pop();
    if (starter.color === "wild") deck.unshift(starter);
  } while (starter.color === "wild");

  state.discard.push(starter);
  state.currentColor = starter.color;

  // The starting card's effect applies before the first player's turn.
  if (starter.type === "skip") {
    advanceTurn(state);
  } else if (starter.type === "reverse") {
    state.direction = -1;
    if (state.players.length === 2) advanceTurn(state);
  } else if (starter.type === "draw2") {
    drawCards(state, state.players[0], 2);
    advanceTurn(state);
  }

  return state;
}

/**
 * Play a card from a player's hand.
 * @returns {{effect: "win"|"skip"|"reverse"|"draw2"|"wild4"|"none", drawnBy?: string, drawnCount?: number}}
 * @throws {Error} with a human-readable message if the move is illegal
 */
function playCard(state, playerIdx, cardIdx, chosenColor) {
  const player = state.players[playerIdx];
  const card = player.hand[cardIdx];
  if (!card) throw new Error("That card isn't in your hand anymore.");

  const topCard = state.discard[state.discard.length - 1];
  if (!canPlay(card, state.currentColor, topCard)) {
    throw new Error(`${cardLabel(card)} doesn't match the current color/number.`);
  }
  if (card.type === "wild4" && !canPlayWildFour(player.hand, cardIdx, state.currentColor)) {
    throw new Error("You still have a card matching the current color, so you can't play Wild Draw Four.");
  }
  if (card.color === "wild" && !COLORS.includes(chosenColor)) {
    throw new Error("Choose a color for the wild card.");
  }

  player.hand.splice(cardIdx, 1);
  state.discard.push(card);
  state.currentColor = card.color === "wild" ? chosenColor : card.color;

  if (player.hand.length === 0) {
    state.winnerId = player.id;
    return { effect: "win" };
  }

  let effect = "none";
  let drawnBy = null, drawnCount = 0;

  if (card.type === "skip") {
    advanceTurn(state);
    advanceTurn(state);
    effect = "skip";
  } else if (card.type === "reverse") {
    state.direction *= -1;
    if (state.players.length === 2) {
      advanceTurn(state);
      advanceTurn(state);
    } else {
      advanceTurn(state);
    }
    effect = "reverse";
  } else if (card.type === "draw2") {
    advanceTurn(state);
    const victim = state.players[state.turnIndex];
    drawCards(state, victim, 2);
    drawnBy = victim.id; drawnCount = 2;
    advanceTurn(state);
    effect = "draw2";
  } else if (card.type === "wild4") {
    advanceTurn(state);
    const victim = state.players[state.turnIndex];
    drawCards(state, victim, 4);
    drawnBy = victim.id; drawnCount = 4;
    advanceTurn(state);
    effect = "wild4";
  } else {
    advanceTurn(state);
  }

  return { effect, drawnBy, drawnCount };
}

/** Voluntary draw on your turn (no playable card, or choosing to draw anyway). */
function drawOnTurn(state, playerIdx) {
  const player = state.players[playerIdx];
  const [card] = drawCards(state, player, 1);
  return card ?? null;
}

// ─── Simple bot AI ──────────────────────────────────────────────────────────
function chooseBotMove(state, playerIdx) {
  const player  = state.players[playerIdx];
  const topCard = state.discard[state.discard.length - 1];
  const legal   = playableIndices(player.hand, state.currentColor, topCard);

  if (legal.length === 0) return { action: "draw" };

  const priority = idx => {
    const c = player.hand[idx];
    if (["skip", "reverse", "draw2"].includes(c.type)) return 0;
    if (c.type === "number") return 1;
    if (c.type === "wild4")  return 2;
    return 3; // plain wild -- saved for last since it's the most flexible card to hold
  };
  legal.sort((a, b) => priority(a) - priority(b));
  const cardIdx = legal[0];
  const card    = player.hand[cardIdx];

  let chosenColor = null;
  if (card.color === "wild") {
    const counts = { red: 0, yellow: 0, green: 0, blue: 0 };
    player.hand.forEach((c, i) => { if (i !== cardIdx && c.color !== "wild") counts[c.color]++; });
    const best = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    chosenColor = best[1] > 0 ? best[0] : COLORS[Math.floor(Math.random() * 4)];
  }

  return { action: "play", cardIdx, chosenColor };
}

module.exports = {
  COLORS,
  freshDeck,
  shuffle,
  cardLabel,
  cardEmoji,
  canPlay,
  canPlayWildFour,
  playableIndices,
  startGame,
  playCard,
  drawOnTurn,
  drawCards,
  chooseBotMove,
  advanceTurn,
  nextIndex,
};
