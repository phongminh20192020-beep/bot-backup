"use strict";

// Search helpers around lavalink-client's node.search().
//
// Why this exists: lavalink-client calls response.json() on the node's REST
// reply without checking the HTTP status. If *anything* answers with an HTML
// page instead of Lavalink's JSON (a proxy, a rate limiter, an error page),
// you get the unhelpful:  Unexpected token '<', "<html>..." is not valid JSON
//
// This module:
//   1. tries every connected node instead of giving up on the first one
//   2. caches autocomplete lookups (autocomplete fires on ~every keystroke and
//      can trip rate limits on shared/public Lavalink hosts)
//   3. when a node returns non-JSON, re-requests the same URL and logs the real
//      HTTP status + start of the body so the actual culprit is visible

const CACHE_TTL_MS   = 60_000;
const CACHE_MAX      = 500;
const DIAG_COOLDOWN  = 30_000;

const cache        = new Map(); // "source:query" -> { at, res }
const lastDiagAt   = new Map(); // node id -> timestamp

function isNonJsonError(err) {
  return /Unexpected token|is not valid JSON|Unexpected end of JSON/i.test(err?.message || "");
}

// Re-issue the request and print what the node/proxy actually answered with.
async function diagnoseBadResponse(node, query, source) {
  const now = Date.now();
  if (now - (lastDiagAt.get(node.id) || 0) < DIAG_COOLDOWN) return;
  lastDiagAt.set(node.id, now);

  try {
    const identifier = `${source}:${query}`;
    const { response } = await node.rawRequest(`loadtracks?identifier=${encodeURIComponent(identifier)}`);
    const body   = (await response.text()).replace(/\s+/g, " ").slice(0, 200);
    const server = response.headers.get("server") || response.headers.get("via") || "unknown";
    console.error(
      `[Search] Node "${node.id}" (${node.options.host}:${node.options.port}) returned ` +
      `HTTP ${response.status} (server: ${server}), content-type: ${response.headers.get("content-type")}. ` +
      `Body starts: ${body}`
    );
    if (process.env.PROXY_URL || process.env.DISCORD_PROXY_URL) {
      console.error("[Search] PROXY_URL is set — make sure Lavalink traffic is not being routed through it (see src/index.js).");
    }
  } catch (e) {
    console.error(`[Search] Diagnostic request to node "${node.id}" failed: ${e.message}`);
  }
}

/**
 * Search on the least-used connected node; fall back to the others on failure.
 * Only for lookups that don't need to be tied to a player (e.g. autocomplete).
 */
async function safeSearch(client, query, user, source = "ytmsearch") {
  const nodes = client.lavalink.nodeManager.leastUsedNodes("players");
  if (!nodes.length) throw new Error("No connected Lavalink nodes");

  let lastErr;
  for (const node of nodes) {
    try {
      return await node.search({ query, source }, user);
    } catch (err) {
      lastErr = err;
      console.warn(`[Search] Node "${node.id}" failed: ${err.message}`);
      if (isNonJsonError(err)) diagnoseBadResponse(node, query, source).catch(() => {});
    }
  }
  throw lastErr;
}

/** safeSearch with a short in-memory cache — use this for autocomplete. */
async function cachedSearch(client, query, user, source = "ytmsearch", ttlMs = CACHE_TTL_MS) {
  const key = `${source}:${query.toLowerCase().trim()}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.res;

  const res = await safeSearch(client, query, user, source);
  cache.set(key, { at: Date.now(), res });
  if (cache.size > CACHE_MAX) cache.delete(cache.keys().next().value);
  return res;
}

// ─── Autocomplete ──────────────────────────────────────────────────────────────
// Discord sends an autocomplete interaction on (nearly) every keystroke. Firing
// a Lavalink search for each one is the fastest way to get rate-limited by a
// shared/public node -- which then answers *every* request (including real
// /play searches) with an HTML error page. So autocomplete here is:
//   * debounced per user (only the last keystroke in a burst actually searches)
//   * cached (repeated prefixes cost nothing)
//   * paused for a while after a node answers with non-JSON, so autocomplete
//     can never starve the real /play request of the node's rate-limit budget
const DEBOUNCE_MS          = 350;
const BACKOFF_MS           = 30_000;
const latestKeystroke      = new Map(); // userId -> token
let   autocompleteBlockedUntil = 0;

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function autocompleteSearch(client, interaction, label = "play") {
  const focused = interaction.options.getFocused();
  if (!focused || focused.trim().length < 2) return interaction.respond([]).catch(() => {});

  // A pasted URL doesn't need search suggestions -- offer it back as-is.
  if (/^https?:\/\//.test(focused)) {
    return interaction.respond([{ name: `Play URL: ${focused.slice(0, 90)}`, value: focused.slice(0, 100) }]).catch(() => {});
  }

  if (Date.now() < autocompleteBlockedUntil) return interaction.respond([]).catch(() => {});

  // Debounce: newer keystroke from the same user supersedes this one.
  const token = Symbol();
  latestKeystroke.set(interaction.user.id, token);
  const key = `ytmsearch:${focused.toLowerCase().trim()}`;
  if (!cache.has(key)) {
    await sleep(DEBOUNCE_MS);
    if (latestKeystroke.get(interaction.user.id) !== token) return; // superseded -- stay silent
  }
  if (latestKeystroke.get(interaction.user.id) === token) latestKeystroke.delete(interaction.user.id);

  try {
    const res = await cachedSearch(client, focused, interaction.user);
    const choices = (res?.tracks || []).slice(0, 25).map(t => ({
      name:  `${t.info.title} — ${t.info.author}`.slice(0, 100),
      value: t.info.uri.slice(0, 100),
    }));
    return interaction.respond(choices).catch(() => {});
  } catch (err) {
    if (isNonJsonError(err)) {
      autocompleteBlockedUntil = Date.now() + BACKOFF_MS;
      console.error(`[Autocomplete] /${label}: node returned non-JSON; pausing autocomplete for ${BACKOFF_MS / 1000}s.`);
    } else {
      console.error(`[Autocomplete] /${label} search failed:`, err.message);
    }
    return interaction.respond([]).catch(() => {});
  }
}

module.exports = { safeSearch, cachedSearch, autocompleteSearch, diagnoseBadResponse, isNonJsonError };
