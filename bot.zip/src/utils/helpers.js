"use strict";

/**
 * Format milliseconds into h:mm:ss or m:ss
 */
function formatDuration(ms) {
  const s   = Math.floor(ms / 1000);
  const h   = Math.floor(s / 3600);
  const m   = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0)
    return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  return `${m}:${String(sec).padStart(2, "0")}`;
}

/**
 * Build a playback progress bar string
 */
function progressBar(position, duration, length = 9) {
  const FILLED       = "<:Filled:1541355008338038875>";       // fully-played segment
  const BLANK        = "<:Blank:1541355002512146432>";        // not-yet-played segment
  const START_CIRCLE = "<:StartCircle:1541355004537995354>";  // playhead dot, left/earlier half of the bar
  const END_CIRCLE   = "<:EndCircle:1541476230468079759>";    // playhead dot, right/later half of the bar

  const dotIndex = Math.min(length - 1, Math.max(0, Math.round((position / duration) * (length - 1))));
  const dotEmoji = dotIndex < length / 2 ? START_CIRCLE : END_CIRCLE;

  let bar = "";
  for (let i = 0; i < length; i++) {
    if (i === dotIndex)   bar += dotEmoji;
    else if (i < dotIndex) bar += FILLED;
    else                    bar += BLANK;
  }
  return bar;
}

// ─── Spotify Client Credentials token ────────────────────────────────────────
// Uses SPOTIFY_CLIENT_ID + SPOTIFY_CLIENT_SECRET env vars (official API).
// Falls back gracefully if credentials are missing.
let _spotifyTokenCache = null;

async function getSpotifyToken() {
  if (_spotifyTokenCache && _spotifyTokenCache.expiresAt > Date.now() + 60_000) {
    return _spotifyTokenCache.token;
  }

  const clientId     = process.env.SPOTIFY_CLIENT_ID;
  const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;
  if (!clientId || !clientSecret)
    throw new Error("SPOTIFY_CLIENT_ID / SPOTIFY_CLIENT_SECRET env vars are not set.");

  const res = await fetch("https://accounts.spotify.com/api/token", {
    method:  "POST",
    headers: {
      "Content-Type":  "application/x-www-form-urlencoded",
      "Authorization": "Basic " + Buffer.from(`${clientId}:${clientSecret}`).toString("base64"),
    },
    body: "grant_type=client_credentials",
  });

  if (!res.ok) throw new Error(`Spotify token request failed (${res.status})`);

  const data = await res.json();
  if (!data.access_token) throw new Error("Spotify returned no access_token");

  _spotifyTokenCache = {
    token:     data.access_token,
    // expires_in is in seconds; subtract 60 s safety margin
    expiresAt: Date.now() + (data.expires_in - 60) * 1000,
  };

  return data.access_token;
}

// ─── Spotify sidecar service (self-hosted, tracks + albums only) ───────────
// Uses SPOTIFY_SERVICE_URL (+ optional SERVICE_API_KEY) instead of the
// official Spotify Web API. No Spotify credentials needed. Playlist links
// are intentionally rejected -- this bot only fetches tracks and albums.

/**
 * Resolve a Spotify URL into { type, name, tracks[] }.
 * Each track is { query, title, artist, duration }.
 * Supports track and album URLs only -- playlists throw a marked error.
 */
async function resolveSpotify(url) {
  const serviceUrl = process.env.SPOTIFY_SERVICE_URL;
  if (!serviceUrl)
    throw new Error("SPOTIFY_SERVICE_URL env var is not set.");

  if (/spotify\.com\/playlist\/|spotify:playlist:/.test(url)) {
    const err = new Error("Playlist links aren't supported -- only tracks and albums.");
    err.unsupported = true;
    throw err;
  }

  const endpoint = `${serviceUrl.replace(/\/$/, "")}/resolve?${new URLSearchParams({ url })}`;
  const headers  = process.env.SERVICE_API_KEY ? { "X-API-Key": process.env.SERVICE_API_KEY } : {};

  const res = await fetch(endpoint, { headers });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`Spotify service request failed (${res.status}): ${body.slice(0, 200)}`);
  }

  const d = await res.json();

  if (d.kind !== "track" && d.kind !== "album") {
    const err = new Error("Only tracks and albums are supported -- not playlists.");
    err.unsupported = true;
    throw err;
  }

  const tracks = (d.tracks ?? []).map(t => ({
    query:    t.query || `${(t.artists ?? []).join(" ")} ${t.name}`.trim(),
    title:    t.name,
    artist:   (t.artists ?? []).join(", "),
    duration: t.duration_ms || 0,
  }));

  return { type: d.kind, name: d.name, tracks };
}

// ─── Spotify Recommendations ──────────────────────────────────────────────
/**
 * Get track recommendations from Spotify based on a seed track.
 * Returns array of recommended tracks with { id, name, artists, uri }.
 *
 * NOTE: this used to call GET /v1/recommendations directly. Spotify
 * permanently deprecated that endpoint (along with /audio-features,
 * /audio-analysis, and /related-artists) for any app created after
 * November 27, 2024 -- it now returns 403/404 for everyone except apps
 * grandfathered in on Extended Quota Mode from before that date. If this
 * app was created after then, that call was *always* failing silently
 * (caught, logged, falls through to the YouTube fallback below it) --
 * which is very likely why autoplay felt broken or inconsistent.
 * See: https://community.spotify.com/t5/Spotify-for-Developers/403-Error-from-v1-audio-features-on-All-Requests
 *
 * Replaced with a working substitute: look up the seed track's own artist,
 * then use GET /v1/search to find more tracks by that artist. Not real
 * collaborative-filtering recommendations, but it's free, it actually
 * works, and it still gives autoplay real same-artist tracks to queue
 * instead of always falling through to the YouTube "Related" fallback.
 */
async function getSpotifyRecommendations(spotifyTrackIds, limit = 5) {
  try {
    const token = await getSpotifyToken();
    const headers = { Authorization: `Bearer ${token}` };

    if (!Array.isArray(spotifyTrackIds)) spotifyTrackIds = [spotifyTrackIds];
    const seedId = spotifyTrackIds[0];
    if (!seedId) return [];

    // /v1/search can't take a track id directly -- need the seed track's
    // own artist name first.
    const trackRes = await fetch(`https://api.spotify.com/v1/tracks/${seedId}`, { headers });
    if (!trackRes.ok) {
      console.error(`[Spotify] Track lookup error (${trackRes.status})`);
      return [];
    }
    const trackData = await trackRes.json();
    const artistName = trackData.artists?.[0]?.name;
    if (!artistName) return [];

    const searchUrl = `https://api.spotify.com/v1/search?q=${encodeURIComponent(`artist:"${artistName}"`)}&type=track&limit=${Math.min(limit * 2, 50)}`;
    const res = await fetch(searchUrl, { headers });

    if (!res.ok) {
      console.error(`[Spotify] Search API error (${res.status})`);
      return [];
    }

    const data   = await res.json();
    const tracks = (data.tracks?.items || []).filter(t => t.id !== seedId);
    return tracks.slice(0, limit);
  } catch (err) {
    console.error("[Spotify] Recommendations (search-based) fetch error:", err.message);
    return [];
  }
}

/**
 * Extract Spotify track ID from URI or URL
 */
function extractSpotifyId(spotifyUri) {
  if (!spotifyUri) return null;
  const match = spotifyUri.match(/spotify:track:([a-zA-Z0-9]+)|\/track\/([a-zA-Z0-9]+)/);
  return match ? (match[1] || match[2]) : null;
}

// ─── Voice channel status ─────────────────────────────────────────────────────

async function setVoiceStatus(client, channelId, status) {
  if (!channelId) return;
  await client.rest
    .put(`/channels/${channelId}/voice-status`, { body: { status } })
    .catch(() => {});
}

async function clearVoiceStatus(client, channelId) {
  if (!channelId) return;
  await client.rest
    .put(`/channels/${channelId}/voice-status`, { body: { status: "" } })
    .catch(() => {});
}

// ─── Bot presence ("Playing Music!") ──────────────────────────────────────────
// This is the bot's own Discord status (shown under its name in the member
// list / profile), NOT the voice channel status text set above.

const IDLE_ACTIVITY = { name: "Watch My stream now!", type: 1, url: "https://youtube.com/watch?v=dQw4w9WgXcQ&list=RDdQw4w9WgXcQ" }; // 1 = ActivityType.Streaming

function setListeningPresence(client, _songName) {
  if (!client.user) return;
  client.user.setActivity(IDLE_ACTIVITY.name, { 
    type: IDLE_ACTIVITY.type, 
    url: IDLE_ACTIVITY.url 
  });
}

function resetPresence(client) {
  if (!client.user) return;
  client.user.setActivity(IDLE_ACTIVITY.name, { 
    type: IDLE_ACTIVITY.type, 
    url: IDLE_ACTIVITY.url 
  });
}

/**
 * Pick the best match from a list of Lavalink search results for a given
 * target duration (ms). Prefers the closest duration within a 5s tolerance;
 * falls back to the top search result if nothing is close enough. This
 * avoids blindly trusting the #1 YouTube Music result, which is frequently
 * a full album, a live version, a sped-up reupload, or otherwise the wrong
 * track — the same duration-matching logic already used for error retries.
 */
function pickBestTrackMatch(tracks, targetDurationMs) {
  if (!tracks?.length) return null;
  if (!targetDurationMs) return tracks[0];

  let best = null;
  let bestDiff = Infinity;
  for (const t of tracks) {
    const diff = Math.abs((t.info?.duration || 0) - targetDurationMs);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = t;
    }
  }

  return bestDiff <= 5000 ? best : tracks[0];
}

module.exports = {
  formatDuration,
  progressBar,
  getSpotifyToken,
  resolveSpotify,
  pickBestTrackMatch,
  getSpotifyRecommendations,
  extractSpotifyId,
  setVoiceStatus,
  clearVoiceStatus,
  setListeningPresence,
  resetPresence,
};