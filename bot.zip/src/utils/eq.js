"use strict";

/**
 * Lavalink's standard 15-band equalizer (band index 0–14, ISO-ish center
 * frequencies). `setEQ()` on lavalink-client's FilterManager expects
 * exactly this shape: [{ band, gain }, ...].
 *
 * Lavalink's own documented gain range is -0.25 (band fully cut) to 1.0
 * (band boosted ~6x), with 0 meaning "no change" — that's the range a
 * Spotify-style EQ slider maps onto. Per request, this bot doubles that
 * headroom in both directions (EQ_MIN_GAIN/EQ_MAX_GAIN below) so bands can
 * be pushed further than Lavalink's own default recommendation allows.
 * Pushing gain that far can distort/clip audio — that's an intentional
 * trade-off for extra range, not a bug.
 */
const EQ_BANDS = [
  { band: 0,  freq: "25 Hz",     label: "Sub-bass (deep rumble)",        short: "Sub-bass" },
  { band: 1,  freq: "40 Hz",     label: "Deep bass",                     short: "Deep bass" },
  { band: 2,  freq: "63 Hz",     label: "Punchy bass",                   short: "Punchy bass" },
  { band: 3,  freq: "100 Hz",    label: "Bass guitar / kick impact",     short: "Bass / kick" },
  { band: 4,  freq: "160 Hz",    label: "Upper bass",                    short: "Upper bass" },
  { band: 5,  freq: "250 Hz",    label: "Low mids / warmth",             short: "Low mids" },
  { band: 6,  freq: "400 Hz",    label: "Midrange body",                 short: "Mid body" },
  { band: 7,  freq: "630 Hz",    label: "Midrange presence",             short: "Mid presence" },
  { band: 8,  freq: "1 kHz",     label: "Vocals core / fundamental",     short: "Vocals core" },
  { band: 9,  freq: "1.6 kHz",   label: "Vocal clarity / bite",          short: "Vocal clarity" },
  { band: 10, freq: "2.5 kHz",   label: "Upper mids / speech",           short: "Upper mids" },
  { band: 11, freq: "4 kHz",     label: "Presence / edge",               short: "Presence" },
  { band: 12, freq: "6.3 kHz",   label: "Treble / high sparkle",         short: "Treble" },
  { band: 13, freq: "10 kHz",    label: "Brilliance / air",              short: "Brilliance" },
  { band: 14, freq: "16 kHz",    label: "Extreme highs",                 short: "Extreme highs" },
];

// Double Lavalink's native -0.25..1.0 range in both directions.
const EQ_MIN_GAIN = -0.5;
const EQ_MAX_GAIN = 2.0;

// Ready-made curves, Spotify-preset-style. Values stay well inside the
// doubled range so they sound usable rather than maxed-out/clipping.
const EQ_PRESETS = {
  flat:   { label: "Flat",                     gains: new Array(15).fill(0) },
  bass:   { label: "Bass Boost",                gains: [1.4, 1.2, 1.0, 0.8, 0.4, 0.15, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  vocal:  { label: "Vocal Boost",                gains: [-0.2, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.45, 0.55, 0.5, 0.4, 0.25, 0.1, 0, 0] },
  treble: { label: "Treble Boost",               gains: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0.1, 0.3, 0.6, 0.9, 1.2, 1.4] },
  vshape: { label: "V-Shape (Bass + Treble)",    gains: [1.2, 1.0, 0.8, 0.5, 0.2, 0, -0.15, -0.2, -0.2, -0.15, 0, 0.2, 0.5, 0.8, 1.0] },
};

/** Clamp a requested gain into the (doubled) allowed range. */
function clampGain(gain) {
  return Math.min(EQ_MAX_GAIN, Math.max(EQ_MIN_GAIN, gain));
}

module.exports = { EQ_BANDS, EQ_MIN_GAIN, EQ_MAX_GAIN, EQ_PRESETS, clampGain };
