"use strict";

const { createCanvas } = require("@napi-rs/canvas");

const W = 540;
const H = 420;
const ROWS = 10;
const TOP_Y = 40;
const ROW_GAP = 30;
const PEG_GAP = 34;

const INK        = "#1b1b1f";
const BG         = "#ffffff";
const PEG_COLOR  = "#c7ccd1";
const PATH_COLOR = "#e0503f";
const SLOT_COLOR = "#9aa0a6";
const HIT_COLOR  = "#e0503f";

function pegX(row, pos) {
  return W / 2 + (pos - row / 2) * PEG_GAP;
}
function pegY(row) {
  return TOP_Y + row * ROW_GAP;
}

/**
 * @param {("L"|"R")[]} moves - length ROWS, the sequence of left/right steps taken
 * @param {number[]} multTable - length ROWS+1, multiplier per landing slot
 * @param {number} landingSlot - index into multTable where the chip landed
 * @returns {Buffer} PNG image buffer
 */
function renderPlinkoBoard({ moves, multTable, landingSlot }) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, H);

  // Pegs, triangular arrangement
  ctx.fillStyle = PEG_COLOR;
  for (let row = 0; row <= ROWS; row++) {
    for (let pos = 0; pos <= row; pos++) {
      ctx.beginPath();
      ctx.arc(pegX(row, pos), pegY(row), 4, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Trace the chip's actual path through the board
  let pos = 0;
  const points = [{ x: W / 2, y: TOP_Y - 22 }];
  for (let row = 0; row < moves.length; row++) {
    if (moves[row] === "R") pos++;
    points.push({ x: pegX(row + 1, pos), y: pegY(row + 1) });
  }

  ctx.strokeStyle = PATH_COLOR;
  ctx.lineWidth = 3;
  ctx.setLineDash([5, 4]);
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
  ctx.stroke();
  ctx.setLineDash([]);

  // Chip start + resting dot
  ctx.fillStyle = INK;
  ctx.beginPath();
  ctx.arc(points[0].x, points[0].y, 6, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = PATH_COLOR;
  ctx.beginPath();
  ctx.arc(points[points.length - 1].x, points[points.length - 1].y, 7, 0, Math.PI * 2);
  ctx.fill();

  // Slot dividers + multiplier labels along the bottom
  const slotY = pegY(ROWS) + 26;
  const slotCount = multTable.length;
  const boardLeft  = pegX(ROWS, 0) - PEG_GAP / 2;
  const slotWidth  = PEG_GAP;

  ctx.strokeStyle = INK;
  ctx.lineWidth = 2;
  for (let i = 0; i <= slotCount; i++) {
    const x = boardLeft + i * slotWidth;
    ctx.beginPath();
    ctx.moveTo(x, slotY - 14);
    ctx.lineTo(x, slotY + 14);
    ctx.stroke();
  }

  ctx.font = "12px sans-serif";
  ctx.textAlign = "center";
  for (let i = 0; i < slotCount; i++) {
    const cx = boardLeft + i * slotWidth + slotWidth / 2;
    const isHit = i === landingSlot;
    ctx.fillStyle = isHit ? HIT_COLOR : SLOT_COLOR;
    ctx.fillRect(boardLeft + i * slotWidth + 2, slotY - 12, slotWidth - 4, 24);
    ctx.fillStyle = "#ffffff";
    ctx.fillText(`${multTable[i]}x`, cx, slotY + 4);
  }

  return canvas.toBuffer("image/png");
}

module.exports = { renderPlinkoBoard };
