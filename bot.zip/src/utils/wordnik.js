"use strict";

const { isKnown5LetterWord, randomKnown5LetterWord } = require("./localDictionary");

const BASE = "https://api.wordnik.com/v4";

/**
 * Fetch a random word from Wordnik.
 * @param {object} opts
 * @param {number} [opts.minLength]
 * @param {number} [opts.maxLength]
 * @returns {Promise<string|null>} lowercase alphabetic word, or null on failure
 */
async function getRandomWord({ minLength, maxLength } = {}) {
  const apiKey = process.env.WORDNIK_API_KEY;
  const isFiveLetterRequest = minLength === 5 && maxLength === 5;

  if (!apiKey) {
    console.error("[Wordnik] WORDNIK_API_KEY is not set in the environment.");
    // Wordle always asks for exactly 5 letters -- the bundled local list can
    // stand in so the game still works without a Wordnik key. Hangman uses
    // a variable length range (5-10) the local 5-letter-only list can't
    // cover, so that still needs Wordnik.
    return isFiveLetterRequest ? randomKnown5LetterWord() : null;
  }

  const params = new URLSearchParams({
    hasDictionaryDef: "true",
    includePartOfSpeech: "noun,adjective,verb",
    excludePartOfSpeech: "proper-noun,proper-noun-plural,abbreviation,family-name,given-name",
    minCorpusCount: "1000",
    maxCorpusCount: "-1",
    minDictionaryCount: "1",
    minLength: String(minLength ?? 4),
    maxLength: String(maxLength ?? 10),
    api_key: apiKey,
  });

  try {
    const res = await fetch(`${BASE}/words.json/randomWord?${params.toString()}`);
    if (!res.ok) {
      console.error(`[Wordnik] randomWord failed: ${res.status} ${res.statusText}`);
      return isFiveLetterRequest ? randomKnown5LetterWord() : null;
    }
    const data = await res.json();
    const word = data?.word?.toLowerCase();
    if (!word || !/^[a-z]+$/.test(word)) {
      return isFiveLetterRequest ? randomKnown5LetterWord() : null;
    }
    return word;
  } catch (err) {
    console.error("[Wordnik] randomWord error:", err.message);
    return isFiveLetterRequest ? randomKnown5LetterWord() : null;
  }
}

/**
 * Check whether a word exists in Wordnik's dictionary (used to validate
 * Wordle guesses so players can't just be told "not a word" for free).
 *
 * Previously this failed OPEN (returned true) whenever the API key was
 * missing or the request failed -- which meant literally any 5-letter
 * string was accepted as a "valid" guess whenever Wordnik wasn't reachable.
 * Now it checks the bundled local word list in both of those cases, so
 * validation is always actually enforced, key or no key, outage or not.
 */
async function isRealWord(word) {
  const apiKey = process.env.WORDNIK_API_KEY;
  if (!apiKey) return isKnown5LetterWord(word);

  try {
    const res = await fetch(
      `${BASE}/word.json/${encodeURIComponent(word.toLowerCase())}/definitions?limit=1&api_key=${apiKey}`
    );
    if (res.status === 404) return false;
    if (!res.ok) return isKnown5LetterWord(word); // API hiccup -- fall back to the local list, don't blindly accept
    const data = await res.json();
    if (Array.isArray(data) && data.length > 0) return true;
    // Wordnik has no definition on file -- still check the local list before
    // rejecting, since it's specifically the curated Wordle guess list and
    // catches valid words Wordnik occasionally misses.
    return isKnown5LetterWord(word);
  } catch (err) {
    console.error("[Wordnik] isRealWord error:", err.message);
    return isKnown5LetterWord(word);
  }
}

module.exports = { getRandomWord, isRealWord };