"use strict";

const fs   = require("fs");
const path = require("path");
const { REST, Routes } = require("discord.js");

// Reads every command file's .data (the slash-command definition) without
// needing a live client -- used both for auto-registration on startup and
// by the standalone `npm run register` script.
function loadCommandDefinitions() {
  const dir = path.join(__dirname, "..", "commands");
  const definitions = [];
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith(".js"))) {
    const cmd = require(path.join(dir, file));
    if (cmd.data) definitions.push(cmd.data.toJSON());
  }
  return definitions;
}

// Registers slash commands with Discord globally. Some hosts (e.g.
// Pterodactyl-based panels) don't give you real shell access -- the Console
// tab only sends stdin to the running process, not a shell -- so
// `npm run register` can't be run manually there. Calling this on every
// startup means commands stay in sync just by restarting the bot.
//
// clientOrToken: either a logged-in discord.js Client (uses client.user.id),
// or a plain { token, clientId } pair for the standalone script, which runs
// before any client exists.
async function registerCommands(clientOrToken) {
  const isClient = typeof clientOrToken?.user?.id === "string";
  const token    = isClient ? process.env.DISCORD_TOKEN : clientOrToken.token;
  const clientId = isClient ? clientOrToken.user.id      : clientOrToken.clientId;

  const commands = loadCommandDefinitions();
  const rest = new REST({ version: "10" }).setToken(token);
  await rest.put(Routes.applicationCommands(clientId), { body: commands });
  return commands.length;
}

module.exports = { registerCommands, loadCommandDefinitions };
