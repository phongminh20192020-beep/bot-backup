"use strict";

const fs   = require("fs");
const path = require("path");

const STORE_DIR  = path.join(__dirname, "../../data/queues");
const TTL_MS     = 3 * 24 * 60 * 60 * 1000; // 3 days in ms

// Ensure the data directory exists
if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true });

function filePath(guildId) {
  return path.join(STORE_DIR, `${guildId}.json`);
}

/**
 * Save the current queue for a guild.
 * Stores: current track, upcoming tracks, repeat mode, volume, timestamp.
 *
 * `meta` is optional and used by the automatic session-recovery path
 * (see utils/sessionRecovery.js) to tag *why* this was saved and where to
 * report back to -- a manual /disconnect save doesn't pass any of this and
 * behaves exactly as before.
 */
function saveQueue(player, meta = {}) {
  try {
    const current = player.queue.current;
    const tracks  = player.queue.tracks;

    // Nothing worth saving
    if (!current && !tracks.length) return;

    const data = {
      savedAt:        Date.now(),
      repeatMode:      player.repeatMode ?? 0,
      volume:          player.volume     ?? 100,
      current:         current  ? serializeTrack(current)  : null,
      tracks:          tracks.map(serializeTrack),
      // Automatic-save-only metadata (undefined/omitted on a manual save):
      voiceChannelId:  meta.auto ? player.voiceChannelId : undefined,
      textChannelId:   meta.auto ? player.textChannelId  : undefined,
      position:        meta.auto ? player.position       : undefined,
      wasPlaying:      meta.auto ? player.playing         : undefined,
      reason:          meta.reason,
      auto:            !!meta.auto,
      notified:        false,
    };

    fs.writeFileSync(filePath(player.guildId), JSON.stringify(data, null, 2));
    console.log(`[QueueStore] Saved ${tracks.length + (current ? 1 : 0)} tracks for guild ${player.guildId}${meta.auto ? ` (auto, reason: ${meta.reason})` : ""}`);
  } catch (err) {
    console.error("[QueueStore] Failed to save queue:", err.message);
  }
}

/**
 * Load a saved queue for a guild.
 * Returns null if no save exists or it has expired.
 */
function loadQueue(guildId) {
  try {
    const fp = filePath(guildId);
    if (!fs.existsSync(fp)) return null;

    const data = JSON.parse(fs.readFileSync(fp, "utf8"));

    // Check TTL
    if (Date.now() - data.savedAt > TTL_MS) {
      fs.unlinkSync(fp);
      console.log(`[QueueStore] Expired queue deleted for guild ${guildId}`);
      return null;
    }

    return data;
  } catch (err) {
    console.error("[QueueStore] Failed to load queue:", err.message);
    return null;
  }
}

/**
 * Delete a saved queue for a guild.
 */
function deleteQueue(guildId) {
  try {
    const fp = filePath(guildId);
    if (fs.existsSync(fp)) fs.unlinkSync(fp);
  } catch (err) {
    console.error("[QueueStore] Failed to delete queue:", err.message);
  }
}

/**
 * Flip the `notified` flag on a saved queue so the next startup doesn't
 * announce the same interrupted session again. Doesn't delete anything --
 * /restore still works on it exactly as before.
 */
function markNotified(guildId) {
  try {
    const fp = filePath(guildId);
    if (!fs.existsSync(fp)) return;
    const data = JSON.parse(fs.readFileSync(fp, "utf8"));
    data.notified = true;
    fs.writeFileSync(fp, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("[QueueStore] Failed to mark queue as notified:", err.message);
  }
}

/**
 * Purge all saved queues older than TTL. Call this on bot startup.
 */
function purgeExpired() {
  try {
    const files = fs.readdirSync(STORE_DIR).filter(f => f.endsWith(".json"));
    let purged  = 0;
    for (const file of files) {
      const fp   = path.join(STORE_DIR, file);
      const data = JSON.parse(fs.readFileSync(fp, "utf8"));
      if (Date.now() - data.savedAt > TTL_MS) {
        fs.unlinkSync(fp);
        purged++;
      }
    }
    if (purged) console.log(`[QueueStore] Purged ${purged} expired queue(s) on startup`);
  } catch (err) {
    console.error("[QueueStore] Purge error:", err.message);
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function serializeTrack(track) {
  return {
    encoded:  track.encoded,
    info:     track.info,
    userData: track.userData ?? {},
    // Store requester as plain object so it survives JSON round-trip
    requester: track.requester
      ? { id: track.requester.id, username: track.requester.username, globalName: track.requester.globalName }
      : null,
  };
}

module.exports = { saveQueue, loadQueue, deleteQueue, purgeExpired, markNotified, STORE_DIR };
