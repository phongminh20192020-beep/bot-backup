"use strict";

// ─────────────────────────────────────────────────────────────────────────
// A standalone, dependency-free chess rules engine.
//
// Board: 8x8 array, board[row][col]. row 0 = rank 1 (White's back rank),
// row 7 = rank 8 (Black's back rank). col 0 = file 'a', col 7 = file 'h'.
// A square holds either null or { type: 'p'|'n'|'b'|'r'|'q'|'k', color: 'w'|'b' }.
// ─────────────────────────────────────────────────────────────────────────

function squareName(row, col) {
  return String.fromCharCode(97 + col) + String(row + 1);
}
function parseSquare(name) {
  const col = name.charCodeAt(0) - 97;
  const row = parseInt(name[1], 10) - 1;
  return { row, col };
}
function inBounds(row, col) {
  return row >= 0 && row < 8 && col >= 0 && col < 8;
}
function cloneBoard(board) {
  return board.map(row => row.map(sq => (sq ? { ...sq } : null)));
}

function initialBoard() {
  const board = Array.from({ length: 8 }, () => Array(8).fill(null));
  const backRank = ["r", "n", "b", "q", "k", "b", "n", "r"];
  for (let c = 0; c < 8; c++) {
    board[0][c] = { type: backRank[c], color: "w" };
    board[1][c] = { type: "p", color: "w" };
    board[6][c] = { type: "p", color: "b" };
    board[7][c] = { type: backRank[c], color: "b" };
  }
  return board;
}

function newGame() {
  return {
    board: initialBoard(),
    turn: "w",
    castling: { wK: true, wQ: true, bK: true, bQ: true },
    enPassant: null, // {row, col} of the square a pawn can capture into
    halfmoveClock: 0,
    fullmoveNumber: 1,
    lastMove: null,
    status: "active", // active | checkmate | stalemate | draw | resigned
    winner: null,      // 'w' | 'b' | null
    history: [],        // { san-ish text, fromRow, fromCol, toRow, toCol, color }
  };
}

const DIRS_DIAGONAL   = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
const DIRS_STRAIGHT   = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const KNIGHT_OFFSETS  = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];

function findKing(board, color) {
  for (let r = 0; r < 8; r++)
    for (let c = 0; c < 8; c++) {
      const sq = board[r][c];
      if (sq && sq.type === "k" && sq.color === color) return { row: r, col: c };
    }
  return null;
}

/** Is (row,col) attacked by any piece of `byColor`? Pure board lookup, no check-legality recursion. */
function isSquareAttacked(board, row, col, byColor) {
  const pawnDir = byColor === "w" ? -1 : 1; // a byColor pawn attacking (row,col) sits one rank behind it, from that pawn's own forward direction
  for (const dc of [-1, 1]) {
    const r = row + pawnDir, c = col + dc;
    if (inBounds(r, c)) {
      const sq = board[r][c];
      if (sq && sq.type === "p" && sq.color === byColor) return true;
    }
  }
  for (const [dr, dc] of KNIGHT_OFFSETS) {
    const r = row + dr, c = col + dc;
    if (inBounds(r, c)) {
      const sq = board[r][c];
      if (sq && sq.type === "n" && sq.color === byColor) return true;
    }
  }
  for (const [dr, dc] of DIRS_DIAGONAL) {
    let r = row + dr, c = col + dc;
    while (inBounds(r, c)) {
      const sq = board[r][c];
      if (sq) {
        if (sq.color === byColor && (sq.type === "b" || sq.type === "q")) return true;
        break;
      }
      r += dr; c += dc;
    }
  }
  for (const [dr, dc] of DIRS_STRAIGHT) {
    let r = row + dr, c = col + dc;
    while (inBounds(r, c)) {
      const sq = board[r][c];
      if (sq) {
        if (sq.color === byColor && (sq.type === "r" || sq.type === "q")) return true;
        break;
      }
      r += dr; c += dc;
    }
  }
  for (const [dr, dc] of [...DIRS_DIAGONAL, ...DIRS_STRAIGHT]) {
    const r = row + dr, c = col + dc;
    if (inBounds(r, c)) {
      const sq = board[r][c];
      if (sq && sq.type === "k" && sq.color === byColor) return true;
    }
  }
  return false;
}

function isInCheck(state, color) {
  const king = findKing(state.board, color);
  if (!king) return false;
  return isSquareAttacked(state.board, king.row, king.col, color === "w" ? "b" : "w");
}

/** Pseudo-legal moves for the piece at (row,col) -- doesn't yet filter out moves that leave the mover's own king in check. */
function pseudoMoves(state, row, col) {
  const board = state.board;
  const piece = board[row][col];
  if (!piece) return [];
  const moves = [];
  const push = (r, c, flags = {}) => { if (inBounds(r, c)) moves.push({ fromRow: row, fromCol: col, toRow: r, toCol: c, ...flags }); };

  if (piece.type === "p") {
    const dir = piece.color === "w" ? 1 : -1;
    const startRow = piece.color === "w" ? 1 : 6;
    const promoRow = piece.color === "w" ? 7 : 0;
    const oneAhead = row + dir;
    if (inBounds(oneAhead, col) && !board[oneAhead][col]) {
      push(oneAhead, col, { promotion: oneAhead === promoRow });
      const twoAhead = row + dir * 2;
      if (row === startRow && !board[twoAhead][col]) {
        push(twoAhead, col, { doubleStep: true });
      }
    }
    for (const dc of [-1, 1]) {
      const r = oneAhead, c = col + dc;
      if (!inBounds(r, c)) continue;
      const target = board[r][c];
      if (target && target.color !== piece.color) {
        push(r, c, { capture: true, promotion: r === promoRow });
      } else if (!target && state.enPassant && state.enPassant.row === r && state.enPassant.col === c) {
        push(r, c, { capture: true, enPassant: true });
      }
    }
  } else if (piece.type === "n") {
    for (const [dr, dc] of KNIGHT_OFFSETS) {
      const r = row + dr, c = col + dc;
      if (!inBounds(r, c)) continue;
      const target = board[r][c];
      if (!target || target.color !== piece.color) push(r, c, { capture: !!target });
    }
  } else if (piece.type === "k") {
    for (const [dr, dc] of [...DIRS_DIAGONAL, ...DIRS_STRAIGHT]) {
      const r = row + dr, c = col + dc;
      if (!inBounds(r, c)) continue;
      const target = board[r][c];
      if (!target || target.color !== piece.color) push(r, c, { capture: !!target });
    }
    // Castling: rights + empty squares between + not currently in check +
    // king doesn't pass through / land on an attacked square.
    const color = piece.color;
    const homeRow = color === "w" ? 0 : 7;
    if (row === homeRow && col === 4 && !isSquareAttacked(board, row, col, color === "w" ? "b" : "w")) {
      const kRight = color === "w" ? state.castling.wK : state.castling.bK;
      const qRight = color === "w" ? state.castling.wQ : state.castling.bQ;
      if (kRight && !board[homeRow][5] && !board[homeRow][6] &&
          board[homeRow][7]?.type === "r" && board[homeRow][7]?.color === color &&
          !isSquareAttacked(board, homeRow, 5, color === "w" ? "b" : "w") &&
          !isSquareAttacked(board, homeRow, 6, color === "w" ? "b" : "w")) {
        push(homeRow, 6, { castle: "K" });
      }
      if (qRight && !board[homeRow][1] && !board[homeRow][2] && !board[homeRow][3] &&
          board[homeRow][0]?.type === "r" && board[homeRow][0]?.color === color &&
          !isSquareAttacked(board, homeRow, 3, color === "w" ? "b" : "w") &&
          !isSquareAttacked(board, homeRow, 2, color === "w" ? "b" : "w")) {
        push(homeRow, 2, { castle: "Q" });
      }
    }
  } else {
    const dirs = piece.type === "b" ? DIRS_DIAGONAL : piece.type === "r" ? DIRS_STRAIGHT : [...DIRS_DIAGONAL, ...DIRS_STRAIGHT];
    for (const [dr, dc] of dirs) {
      let r = row + dr, c = col + dc;
      while (inBounds(r, c)) {
        const target = board[r][c];
        if (!target) { push(r, c); }
        else { if (target.color !== piece.color) push(r, c, { capture: true }); break; }
        r += dr; c += dc;
      }
    }
  }
  return moves;
}

/** Apply a move to a (cloned) board+state fragment without touching game-level bookkeeping. Used both for real moves and check-simulation. */
function applyToBoard(board, move) {
  const piece = board[move.fromRow][move.fromCol];
  board[move.toRow][move.toCol] = piece;
  board[move.fromRow][move.fromCol] = null;
  if (move.enPassant) {
    const capturedRow = piece.color === "w" ? move.toRow - 1 : move.toRow + 1;
    board[capturedRow][move.toCol] = null;
  }
  if (move.castle === "K") {
    const homeRow = move.fromRow;
    board[homeRow][5] = board[homeRow][7];
    board[homeRow][7] = null;
  } else if (move.castle === "Q") {
    const homeRow = move.fromRow;
    board[homeRow][3] = board[homeRow][0];
    board[homeRow][0] = null;
  }
  if (move.promotion) {
    board[move.toRow][move.toCol] = { type: move.promoteTo || "q", color: piece.color };
  }
}

function wouldLeaveOwnKingInCheck(state, move) {
  const board = cloneBoard(state.board);
  applyToBoard(board, move);
  const color = state.board[move.fromRow][move.fromCol].color;
  const king = findKing(board, color);
  if (!king) return true;
  return isSquareAttacked(board, king.row, king.col, color === "w" ? "b" : "w");
}

function legalMovesFrom(state, row, col) {
  const piece = state.board[row][col];
  if (!piece || piece.color !== state.turn) return [];
  return pseudoMoves(state, row, col).filter(m => !wouldLeaveOwnKingInCheck(state, m));
}

function allLegalMoves(state, color = state.turn) {
  const moves = [];
  for (let r = 0; r < 8; r++)
    for (let c = 0; c < 8; c++) {
      const sq = state.board[r][c];
      if (sq && sq.color === color) moves.push(...legalMovesFrom({ ...state, turn: color }, r, c));
    }
  return moves;
}

function squaresWithLegalMoves(state, color = state.turn) {
  const out = [];
  for (let r = 0; r < 8; r++)
    for (let c = 0; c < 8; c++) {
      const sq = state.board[r][c];
      if (sq && sq.color === color && legalMovesFrom({ ...state, turn: color }, r, c).length > 0) {
        out.push({ row: r, col: c, piece: sq });
      }
    }
  return out;
}

const PIECE_NAME = { p: "Pawn", n: "Knight", b: "Bishop", r: "Rook", q: "Queen", k: "King" };

/**
 * Play a fully-specified legal move. Throws if illegal.
 * @param {string} promoteTo - one of 'q','r','b','n', required for pawn promotion.
 */
function makeMove(state, fromRow, fromCol, toRow, toCol, promoteTo) {
  const piece = state.board[fromRow][fromCol];
  if (!piece) throw new Error("There's no piece on that square.");
  if (piece.color !== state.turn) throw new Error("That's not your piece.");

  const legal = legalMovesFrom(state, fromRow, fromCol);
  const move = legal.find(m => m.toRow === toRow && m.toCol === toCol);
  if (!move) throw new Error("That move isn't legal.");
  if (move.promotion) move.promoteTo = ["q", "r", "b", "n"].includes(promoteTo) ? promoteTo : "q";

  const capturedPiece = state.board[toRow][toCol] || (move.enPassant ? { type: "p", color: piece.color === "w" ? "b" : "w" } : null);

  applyToBoard(state.board, move);

  // Castling rights
  if (piece.type === "k") {
    if (piece.color === "w") { state.castling.wK = false; state.castling.wQ = false; }
    else { state.castling.bK = false; state.castling.bQ = false; }
  }
  const clearRookRight = (row, col) => {
    if (row === 0 && col === 0) state.castling.wQ = false;
    if (row === 0 && col === 7) state.castling.wK = false;
    if (row === 7 && col === 0) state.castling.bQ = false;
    if (row === 7 && col === 7) state.castling.bK = false;
  };
  if (piece.type === "r") clearRookRight(fromRow, fromCol);
  if (capturedPiece) clearRookRight(toRow, toCol);

  // En passant target for the *next* move only
  state.enPassant = move.doubleStep ? { row: (fromRow + toRow) / 2, col: fromCol } : null;

  // Halfmove clock (50-move rule bookkeeping)
  state.halfmoveClock = (piece.type === "p" || capturedPiece) ? 0 : state.halfmoveClock + 1;

  const mover = piece.color;
  const san = `${PIECE_NAME[piece.type]} ${squareName(fromRow, fromCol)}${capturedPiece ? "x" : "-"}${squareName(toRow, toCol)}` +
    (move.castle ? ` (${move.castle === "K" ? "O-O" : "O-O-O"})` : "") +
    (move.promotion ? `=${PIECE_NAME[move.promoteTo].toUpperCase()}` : "");
  state.lastMove = { fromRow, fromCol, toRow, toCol, color: mover, capture: !!capturedPiece, san };
  state.history.push(san);

  state.turn = mover === "w" ? "b" : "w";
  if (mover === "b") state.fullmoveNumber++;

  const inCheck = isInCheck(state, state.turn);
  const anyMoves = allLegalMoves(state, state.turn).length > 0;
  if (!anyMoves) {
    state.status = inCheck ? "checkmate" : "stalemate";
    state.winner = inCheck ? mover : null;
  } else if (state.halfmoveClock >= 100) {
    state.status = "draw";
  } else {
    state.status = "active";
  }

  return { move, capturedPiece, inCheck, status: state.status, winner: state.winner };
}

function resign(state, color) {
  state.status = "resigned";
  state.winner = color === "w" ? "b" : "w";
}

// ─── Very simple bot AI: material-weighted greedy with a shallow check for
// hanging its own pieces, good enough to be a reasonable practice opponent
// without needing a real search tree. ─────────────────────────────────────
const PIECE_VALUE = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

function evaluateMaterial(board, color) {
  let score = 0;
  for (const row of board) for (const sq of row) {
    if (!sq) continue;
    score += (sq.color === color ? 1 : -1) * PIECE_VALUE[sq.type];
  }
  return score;
}

function chooseBotMove(state) {
  const color = state.turn;
  const moves = allLegalMoves(state, color);
  if (moves.length === 0) return null;

  let best = null, bestScore = -Infinity;
  for (const move of moves) {
    const trial = { board: cloneBoard(state.board), castling: { ...state.castling }, enPassant: state.enPassant, turn: color };
    const promoteTo = move.promotion ? "q" : undefined;
    if (move.promotion) move.promoteTo = promoteTo;
    const capturedPiece = trial.board[move.toRow][move.toCol];
    applyToBoard(trial.board, move);

    let score = evaluateMaterial(trial.board, color);
    // Mild bonus for capturing, and a penalty if the destination square is
    // then attacked by the opponent (i.e. it just hung the piece for free).
    if (capturedPiece) score += PIECE_VALUE[capturedPiece.type] * 0.25;
    const opponent = color === "w" ? "b" : "w";
    if (isSquareAttacked(trial.board, move.toRow, move.toCol, opponent)) {
      const movedPiece = trial.board[move.toRow][move.toCol];
      score -= PIECE_VALUE[movedPiece.type] * 0.9;
    }
    score += Math.random() * 0.1; // tie-break jitter so the bot isn't fully deterministic

    if (score > bestScore) { bestScore = score; best = move; }
  }
  return best;
}

module.exports = {
  squareName, parseSquare, inBounds, cloneBoard, initialBoard, newGame,
  findKing, isSquareAttacked, isInCheck, pseudoMoves, legalMovesFrom,
  allLegalMoves, squaresWithLegalMoves, makeMove, resign, chooseBotMove,
  PIECE_NAME, PIECE_VALUE,
};
