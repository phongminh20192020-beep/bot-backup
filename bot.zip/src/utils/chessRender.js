"use strict";

const { createCanvas } = require("@napi-rs/canvas");
const { isInCheck, findKing } = require("./chessEngine");

const SQUARE = 76;
const MARGIN = 34; // room for file/rank labels
const BOARD_PX = SQUARE * 8;

const LIGHT_SQ = "#eddccb";
const DARK_SQ  = "#a9765a";
const LIGHT_HL = "#f4f27a"; // last-move highlight, light square
const DARK_HL  = "#c9c14a"; // last-move highlight, dark square
const SELECT_RING = "#3a7bd5";
const DEST_DOT    = "rgba(38, 130, 60, 0.75)";
const DEST_CAPTURE_RING = "rgba(200, 40, 40, 0.85)";
const CHECK_GLOW = "rgba(230, 60, 60, 0.55)";

const WHITE_FILL = "#fbfbf8";
const WHITE_EDGE = "#1c1c1e";
const BLACK_FILL = "#26262b";
const BLACK_EDGE = "#e6e6ea";

/**
 * Draw a single piece, vector-style (no reliance on the host font having
 * chess glyphs, which many minimal Linux font stacks don't). `cx,cy` is the
 * center of the square, `size` the square's side length.
 */
function drawPiece(ctx, piece, cx, cy, size) {
  const fill = piece.color === "w" ? WHITE_FILL : BLACK_FILL;
  const edge = piece.color === "w" ? WHITE_EDGE : BLACK_EDGE;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.fillStyle = fill;
  ctx.strokeStyle = edge;
  ctx.lineWidth = Math.max(1.5, size * 0.028);
  ctx.lineJoin = "round";

  const s = size; // shorthand

  const base = (w, y, h) => {
    ctx.beginPath();
    ctx.moveTo(-w / 2, y);
    ctx.lineTo(w / 2, y);
    ctx.lineTo(w / 2 - w * 0.08, y - h);
    ctx.lineTo(-(w / 2 - w * 0.08), y - h);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
  };

  if (piece.type === "p") {
    base(s * 0.46, s * 0.34, s * 0.06);
    ctx.beginPath(); ctx.ellipse(0, s * 0.18, s * 0.16, s * 0.07, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, -s * 0.06, s * 0.16, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  } else if (piece.type === "r") {
    base(s * 0.52, s * 0.34, s * 0.06);
    ctx.beginPath(); ctx.rect(-s * 0.26, -s * 0.02, s * 0.52, s * 0.22); ctx.fill(); ctx.stroke();
    const towerW = s * 0.42, towerX = -towerW / 2, towerY = -s * 0.22, towerH = s * 0.22;
    ctx.beginPath(); ctx.rect(towerX, towerY, towerW, towerH); ctx.fill(); ctx.stroke();
    // Crenellations: three merlons drawn on top of the tower, additive
    // rectangles (not carved notches) so they always render cleanly.
    const merlonW = towerW / 4, merlonH = s * 0.1, merlonY = towerY - merlonH + s * 0.02;
    [towerX, towerX + merlonW * 1.5, towerX + towerW - merlonW].forEach(mx => {
      ctx.beginPath(); ctx.rect(mx, merlonY, merlonW, merlonH); ctx.fill(); ctx.stroke();
    });
  } else if (piece.type === "n") {
    // Horse head in profile, facing left, standing on the usual pedestal base.
    base(s * 0.5, s * 0.34, s * 0.06);
    ctx.beginPath();
    ctx.moveTo(-s * 0.05, s * 0.30);                                          // chest, bottom
    ctx.lineTo(-s * 0.22, s * 0.30);                                          // back of neck, bottom
    ctx.quadraticCurveTo(-s * 0.28, s * 0.10, -s * 0.22, -s * 0.08);          // neck curving up
    ctx.quadraticCurveTo(-s * 0.18, -s * 0.20, -s * 0.06, -s * 0.24);         // up toward the poll
    ctx.quadraticCurveTo(-s * 0.10, -s * 0.34, -s * 0.02, -s * 0.40);         // ear front edge
    ctx.quadraticCurveTo(s * 0.02, -s * 0.34, s * 0.00, -s * 0.27);           // ear back edge
    ctx.quadraticCurveTo(s * 0.10, -s * 0.26, s * 0.20, -s * 0.16);           // forehead down to nose bridge
    ctx.quadraticCurveTo(s * 0.30, -s * 0.10, s * 0.30, -s * 0.02);           // nose bump
    ctx.quadraticCurveTo(s * 0.30, s * 0.04, s * 0.22, s * 0.04);             // nostril / muzzle front
    ctx.quadraticCurveTo(s * 0.16, s * 0.05, s * 0.10, s * 0.02);             // mouth curving back
    ctx.quadraticCurveTo(s * 0.14, s * 0.10, s * 0.10, s * 0.16);             // chin/jaw
    ctx.lineTo(s * 0.16, s * 0.30);                                          // down to chest, bottom
    ctx.closePath();
    ctx.fill(); ctx.stroke();
    // Mane: a few short strokes along the back of the neck.
    ctx.strokeStyle = edge;
    ctx.lineWidth = Math.max(1, s * 0.02);
    for (const t of [-0.02, -0.10, -0.18]) {
      ctx.beginPath();
      ctx.moveTo(-s * 0.20, s * t);
      ctx.lineTo(-s * 0.10, s * (t - 0.05));
      ctx.stroke();
    }
    // Eye
    ctx.fillStyle = edge;
    ctx.beginPath(); ctx.arc(-s * 0.02, -s * 0.14, s * 0.025, 0, Math.PI * 2); ctx.fill();
  } else if (piece.type === "b") {
    base(s * 0.44, s * 0.34, s * 0.05);
    ctx.beginPath(); ctx.ellipse(0, s * 0.06, s * 0.18, s * 0.22, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, -s * 0.22, s * 0.10, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, -s * 0.36, s * 0.035, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    // the traditional diagonal slit
    ctx.strokeStyle = edge;
    ctx.beginPath(); ctx.moveTo(-s * 0.06, -s * 0.14); ctx.lineTo(s * 0.06, -s * 0.02); ctx.stroke();
  } else if (piece.type === "q") {
    base(s * 0.5, s * 0.34, s * 0.05);
    ctx.beginPath(); ctx.ellipse(0, s * 0.06, s * 0.22, s * 0.20, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    const pts = 5, rOuter = s * 0.28, rInner = s * 0.13, cy0 = -s * 0.14;
    ctx.beginPath();
    for (let i = 0; i < pts * 2; i++) {
      const r = i % 2 === 0 ? rOuter : rInner;
      const ang = (Math.PI * i) / pts - Math.PI / 2;
      const x = Math.sin(ang) * r, y = cy0 - Math.cos(ang) * r * 0.6;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath(); ctx.fill(); ctx.stroke();
    for (let i = 0; i < pts; i++) {
      const ang = (Math.PI * 2 * i) / pts - Math.PI / 2;
      const x = Math.sin(ang) * rOuter, y = cy0 - Math.cos(ang) * rOuter * 0.6;
      ctx.beginPath(); ctx.arc(x, y, s * 0.035, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    }
  } else if (piece.type === "k") {
    base(s * 0.5, s * 0.34, s * 0.05);
    ctx.beginPath(); ctx.ellipse(0, s * 0.08, s * 0.22, s * 0.18, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.roundRect(-s * 0.15, -s * 0.24, s * 0.30, s * 0.28, s * 0.08); ctx.fill(); ctx.stroke();
    // cross on top
    ctx.beginPath();
    ctx.rect(-s * 0.03, -s * 0.42, s * 0.06, s * 0.16);
    ctx.rect(-s * 0.09, -s * 0.37, s * 0.18, s * 0.06);
    ctx.fill(); ctx.stroke();
  }
  ctx.restore();
}

/**
 * Render the board.
 * @param {object} state - chessEngine game state
 * @param {object} [opts]
 * @param {boolean} [opts.flip] - render from Black's point of view (rank 8 at top becomes rank 1... i.e. rotate board 180)
 * @param {{row,col}} [opts.selected] - highlight the selected square
 * @param {Array<{row,col,capture}>} [opts.legalTargets] - dots/rings for legal destinations of the selected piece
 */
function renderBoardImage(state, opts = {}) {
  const { flip = false, selected = null, legalTargets = [] } = opts;
  const width = BOARD_PX + MARGIN * 2;
  const height = BOARD_PX + MARGIN * 2;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = "#12121a";
  ctx.fillRect(0, 0, width, height);

  const boardRowToY = boardRow => flip ? boardRow : 7 - boardRow; // screen row 0 = top
  const boardColToX = boardCol => flip ? 7 - boardCol : boardCol;

  const lastMove = state.lastMove;
  const kingInCheckSq = (() => {
    const inCheckNow = state.status === "checkmate" || (state.status === "active" && isInCheck(state, state.turn));
    if (!inCheckNow) return null;
    return findKing(state.board, state.turn);
  })();

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const screenRow = boardRowToY(r);
      const screenCol = boardColToX(c);
      const x = MARGIN + screenCol * SQUARE;
      const y = MARGIN + screenRow * SQUARE;
      const isLight = (r + c) % 2 === 1;
      const isLastMove = lastMove && ((lastMove.fromRow === r && lastMove.fromCol === c) || (lastMove.toRow === r && lastMove.toCol === c));
      ctx.fillStyle = isLastMove ? (isLight ? LIGHT_HL : DARK_HL) : (isLight ? LIGHT_SQ : DARK_SQ);
      ctx.fillRect(x, y, SQUARE, SQUARE);

      if (kingInCheckSq && kingInCheckSq.row === r && kingInCheckSq.col === c) {
        const grad = ctx.createRadialGradient(x + SQUARE / 2, y + SQUARE / 2, SQUARE * 0.1, x + SQUARE / 2, y + SQUARE / 2, SQUARE * 0.6);
        grad.addColorStop(0, CHECK_GLOW);
        grad.addColorStop(1, "rgba(230,60,60,0)");
        ctx.fillStyle = grad;
        ctx.fillRect(x, y, SQUARE, SQUARE);
      }

      const piece = state.board[r][c];
      if (piece) drawPiece(ctx, piece, x + SQUARE / 2, y + SQUARE / 2, SQUARE * 0.86);

      if (selected && selected.row === r && selected.col === c) {
        ctx.strokeStyle = SELECT_RING;
        ctx.lineWidth = 4;
        ctx.strokeRect(x + 2, y + 2, SQUARE - 4, SQUARE - 4);
      }
      const dest = legalTargets.find(t => t.row === r && t.col === c);
      if (dest) {
        if (dest.capture) {
          ctx.strokeStyle = DEST_CAPTURE_RING;
          ctx.lineWidth = 5;
          ctx.beginPath(); ctx.arc(x + SQUARE / 2, y + SQUARE / 2, SQUARE * 0.44, 0, Math.PI * 2); ctx.stroke();
        } else {
          ctx.fillStyle = DEST_DOT;
          ctx.beginPath(); ctx.arc(x + SQUARE / 2, y + SQUARE / 2, SQUARE * 0.14, 0, Math.PI * 2); ctx.fill();
        }
      }
    }
  }

  // Board border
  ctx.strokeStyle = "#0a0a10";
  ctx.lineWidth = 3;
  ctx.strokeRect(MARGIN, MARGIN, BOARD_PX, BOARD_PX);

  // File/rank labels
  ctx.fillStyle = "#c9ccd1";
  ctx.font = `bold ${Math.round(SQUARE * 0.2)}px sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  for (let c = 0; c < 8; c++) {
    const file = String.fromCharCode(97 + (flip ? 7 - c : c));
    const x = MARGIN + c * SQUARE + SQUARE / 2;
    ctx.fillText(file, x, MARGIN * 0.5);
    ctx.fillText(file, x, height - MARGIN * 0.5);
  }
  ctx.textAlign = "center";
  for (let r = 0; r < 8; r++) {
    const rank = String(flip ? r + 1 : 8 - r);
    const y = MARGIN + r * SQUARE + SQUARE / 2;
    ctx.fillText(rank, MARGIN * 0.5, y);
    ctx.fillText(rank, width - MARGIN * 0.5, y);
  }

  return canvas.toBuffer("image/png");
}

module.exports = { renderBoardImage, SQUARE, MARGIN, BOARD_PX };
