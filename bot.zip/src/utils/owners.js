"use strict";

// User IDs allowed to run owner-only commands (/coinadd, /status, /msgto, /servers).
const OWNER_IDS = new Set([
  "1175649653950267506",
  "1100942804689109164",
  "1464296873471770664",  
]);

function isOwner(userId) {
  return OWNER_IDS.has(userId);
}

module.exports = { OWNER_IDS, isOwner };
