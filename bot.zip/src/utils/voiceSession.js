"use strict";

const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  StreamType,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  EndBehaviorType,
  entersState,
  getVoiceConnection,
} = require("@discordjs/voice");
const prism = require("prism-media");
const { Readable } = require("stream");
const { UtteranceScheduler } = require("./utteranceScheduler");
const { synthesizeSpeech, PCM_SAMPLE_RATE, PCM_CHANNELS } = require("./tts");
const { transcribeAudioBuffer } = require("./groq");
const { spawn } = require("child_process");

const SILENCE_MS   = 1000; // how long someone must pause before their utterance is considered "done"
const MIN_MS       = 300;  // ignore captures shorter than this (mic pops, coughs, etc.)
const COOLDOWN_MS  = 3000;

// One session per guild. A session owns the raw voice connection, the audio
// player used to speak, and the utterance scheduler that decides who gets
// answered next.
const sessions = new Map();

function isSessionActive(guildId) {
  return sessions.has(guildId);
}

/** Wrap raw PCM (s16le/48k/stereo) into a WAV buffer so Whisper can read it. */
function pcmToWav(pcmBuffer) {
  return new Promise((resolve, reject) => {
    const ff = spawn("ffmpeg", [
      "-hide_banner", "-loglevel", "error",
      "-f", "s16le", "-ar", String(PCM_SAMPLE_RATE), "-ac", String(PCM_CHANNELS),
      "-i", "pipe:0",
      "-f", "wav", "pipe:1",
    ]);
    const out = [], err = [];
    ff.stdout.on("data", d => out.push(d));
    ff.stderr.on("data", d => err.push(d));
    ff.on("error", reject);
    ff.on("close", code => code === 0
      ? resolve(Buffer.concat(out))
      : reject(new Error(`ffmpeg exited ${code}: ${Buffer.concat(err).toString().slice(0, 200)}`)));
    ff.stdin.write(pcmBuffer);
    ff.stdin.end();
  });
}

/**
 * Start capturing one user's speech from the receiver. Resolves with the
 * captured PCM buffer once they've been silent for SILENCE_MS, or null if
 * the capture was too short to bother with.
 */
function captureUtterance(connection, userId) {
  return new Promise((resolve, reject) => {
    const opusStream = connection.receiver.subscribe(userId, {
      end: { behavior: EndBehaviorType.AfterSilence, duration: SILENCE_MS },
    });
    const decoder = new prism.opus.Decoder({ rate: PCM_SAMPLE_RATE, channels: PCM_CHANNELS, frameSize: 960 });
    const pcmChunks = [];
    const startedAt = Date.now();

    const pipeline = opusStream.pipe(decoder);
    pipeline.on("data", chunk => pcmChunks.push(chunk));
    pipeline.on("end", () => {
      const duration = Date.now() - startedAt;
      if (duration < MIN_MS || !pcmChunks.length) return resolve(null);
      resolve(Buffer.concat(pcmChunks));
    });
    pipeline.on("error", reject);
    opusStream.on("error", reject);
  });
}

/**
 * @param {object} opts
 * @param {import("discord.js").VoiceBasedChannel} opts.voiceChannel
 * @param {import("discord.js").TextBasedChannel} opts.textChannel
 * @param {(promptText: string, speakerId: string) => Promise<string>} opts.getReply
 *   Given transcribed text, return the reply text to speak back.
 * @param {string[]} [opts.onlyListenTo] - if set, only these user IDs are captured
 * @param {() => void} [opts.onUtteranceHandled] - called after each full reply, for single-shot callers
 */
async function startSession({ voiceChannel, textChannel, getReply, onlyListenTo = null, autoStopAfterReply = false }) {
  const guildId = voiceChannel.guild.id;
  if (sessions.has(guildId)) return sessions.get(guildId);

  const connection = joinVoiceChannel({
    channelId:      voiceChannel.id,
    guildId,
    adapterCreator: voiceChannel.guild.voiceAdapterCreator,
    selfDeaf:       false, // must NOT self-deafen -- we need to receive audio
    selfMute:       false,
  });

  try {
    await entersState(connection, VoiceConnectionStatus.Ready, 15_000);
  } catch (err) {
    connection.destroy();
    throw new Error(`Couldn't connect to voice: ${err.message}`);
  }

  const player = createAudioPlayer();
  connection.subscribe(player);

  const listeningUsers = new Set();

  const scheduler = new UtteranceScheduler({
    cooldownMs: COOLDOWN_MS,
    onProcess: async ({ userId, pcmBuffer }) => {
      try {
        const wav = await pcmToWav(pcmBuffer);
        const transcript = await transcribeAudioBuffer(wav, "utterance.wav");
        if (!transcript || transcript.length < 2) return;

        const replyText = await getReply(transcript, userId);
        if (!replyText) return;

        const speechPcm = await synthesizeSpeech(replyText);
        if (!speechPcm) return;

        await speak(speechPcm);
      } catch (err) {
        console.error(`[VoiceSession] Failed to handle utterance guild=${guildId}:`, err.message);
        textChannel?.send(`⚠️ Voice reply failed: ${err.message}`).catch(() => {});
      } finally {
        if (autoStopAfterReply) session.stop();
      }
    },
  });

  const speak = pcmBuffer => new Promise((resolve, reject) => {
    const resource = createAudioResource(Readable.from(pcmBuffer), { inputType: StreamType.Raw });
    player.play(resource);
    const onIdle = () => { cleanup(); resolve(); };
    const onError = err => { cleanup(); reject(err); };
    const cleanup = () => {
      player.off(AudioPlayerStatus.Idle, onIdle);
      player.off("error", onError);
    };
    player.once(AudioPlayerStatus.Idle, onIdle);
    player.once("error", onError);
  });

  const handleSpeakingStart = userId => {
    if (onlyListenTo && !onlyListenTo.includes(userId)) return;
    if (listeningUsers.has(userId)) return; // already capturing this user
    listeningUsers.add(userId);

    captureUtterance(connection, userId)
      .then(pcmBuffer => {
        listeningUsers.delete(userId);
        if (pcmBuffer) scheduler.push({ userId, pcmBuffer, completedAt: Date.now() });
      })
      .catch(err => {
        listeningUsers.delete(userId);
        console.error(`[VoiceSession] Capture error guild=${guildId} user=${userId}:`, err.message);
      });
  };

  connection.receiver.speaking.on("start", handleSpeakingStart);

  const session = {
    guildId,
    connection,
    player,
    scheduler,
    speak,
    stop() {
      connection.receiver.speaking.removeListener("start", handleSpeakingStart);
      scheduler.clear();
      player.stop(true);
      connection.destroy();
      sessions.delete(guildId);
    },
  };

  connection.on(VoiceConnectionStatus.Disconnected, () => {
    session.stop();
  });

  sessions.set(guildId, session);
  return session;
}

function stopSession(guildId) {
  const session = sessions.get(guildId);
  if (session) session.stop();
}

function getSession(guildId) {
  return sessions.get(guildId) || null;
}

/**
 * Join a voice channel just long enough to speak one clip, then leave.
 * Used for /askvoice's typed-question path, where no listening is needed.
 */
async function speakOnce({ voiceChannel, pcmBuffer }) {
  const connection = joinVoiceChannel({
    channelId:      voiceChannel.id,
    guildId:        voiceChannel.guild.id,
    adapterCreator: voiceChannel.guild.voiceAdapterCreator,
    selfDeaf:       false,
    selfMute:       false,
  });

  try {
    await entersState(connection, VoiceConnectionStatus.Ready, 15_000);
    const player = createAudioPlayer();
    connection.subscribe(player);
    const resource = createAudioResource(Readable.from(pcmBuffer), { inputType: StreamType.Raw });
    player.play(resource);

    await new Promise((resolve, reject) => {
      player.once(AudioPlayerStatus.Idle, resolve);
      player.once("error", reject);
    });
  } finally {
    connection.destroy();
  }
}

module.exports = { startSession, stopSession, getSession, isSessionActive, speakOnce };
