"use strict";

const { createCanvas } = require("@napi-rs/canvas");

// Canvas-drawn hangman scene, replacing the old emoji-grid gallows. Drawn as
// a proper doodle instead of straight geometric lines: a hand-sketched-style
// gallows in dark ink, with the figure itself drawn in a warm orange stroke
// that fills in one body part per wrong guess (head -> torso -> left arm ->
// right arm -> left leg -> right leg), matching the previous reveal order.

const WIDTH  = 360;
const HEIGHT = 420;

const INK    = "#1b1b1f"; // gallows
const FIGURE = "#d98a4e"; // body -- warm orange, hand-drawn look
const BG     = "#ffffff";

/** A slightly wobbly line between two points, for a hand-drawn feel. */
function wobblyLine(ctx, x1, y1, x2, y2, bow = 6) {
  const mx = (x1 + x2) / 2 + bow;
  const my = (y1 + y2) / 2 - bow;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(mx, my, x2, y2);
  ctx.stroke();
}

function drawGallows(ctx) {
  ctx.strokeStyle = INK;
  ctx.lineWidth = 7;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  // Base
  wobblyLine(ctx, 40, 380, 160, 380, 3);
  // Upright post
  wobblyLine(ctx, 90, 380, 90, 40, -4);
  // Top beam
  wobblyLine(ctx, 86, 42, 250, 40, -3);
  // Diagonal brace
  wobblyLine(ctx, 92, 90, 140, 44, 2);
  // Rope
  wobblyLine(ctx, 248, 42, 248, 82, 1);
}

function drawHead(ctx) {
  ctx.strokeStyle = FIGURE;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.ellipse(248, 116, 30, 34, 0, 0, Math.PI * 2);
  ctx.stroke();
}

function drawTorso(ctx) {
  ctx.strokeStyle = FIGURE;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  wobblyLine(ctx, 248, 150, 248, 250, 8);
}

function drawLeftArm(ctx) {
  ctx.strokeStyle = FIGURE;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  wobblyLine(ctx, 248, 175, 195, 220, -6);
}

function drawRightArm(ctx) {
  ctx.strokeStyle = FIGURE;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  wobblyLine(ctx, 248, 175, 301, 220, 6);
}

function drawLeftLeg(ctx) {
  ctx.strokeStyle = FIGURE;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  wobblyLine(ctx, 248, 250, 210, 320, -6);
}

function drawRightLeg(ctx) {
  ctx.strokeStyle = FIGURE;
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  wobblyLine(ctx, 248, 250, 286, 320, 6);
}

const BODY_STEPS = [drawHead, drawTorso, drawLeftArm, drawRightArm, drawLeftLeg, drawRightLeg];

/**
 * Renders the hangman scene for the current number of wrong guesses.
 * @param {number} wrong - 0 to 6 wrong guesses so far.
 * @returns {Buffer} PNG image buffer.
 */
function renderHangmanImage(wrong) {
  const canvas = createCanvas(WIDTH, HEIGHT);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  drawGallows(ctx);

  const revealed = Math.max(0, Math.min(wrong, BODY_STEPS.length));
  for (let i = 0; i < revealed; i++) BODY_STEPS[i](ctx);

  return canvas.toBuffer("image/png");
}

module.exports = { renderHangmanImage };
