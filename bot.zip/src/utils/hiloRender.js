"use strict";

const { createCanvas } = require("@napi-rs/canvas");
const { INK, BG, roundedRectPath, drawSuit } = require("./canvasDoodle");

const W = 220;
const H = 300;

const RED_SUITS = new Set(["♥", "♦"]);

/**
 * @param {{ rank: string, suit: "♠"|"♥"|"♦"|"♣" }} card
 * @returns {Buffer} PNG image buffer
 */
function renderCard(card) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, H);

  const color = RED_SUITS.has(card.suit) ? "#d1352b" : INK;

  roundedRectPath(ctx, 10, 10, W - 20, H - 20, 16);
  ctx.fillStyle = "#fdfdfd";
  ctx.fill();
  ctx.strokeStyle = INK;
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = color;
  ctx.font = "bold 30px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(card.rank, 26, 48);
  ctx.textAlign = "right";
  ctx.save();
  ctx.translate(W - 26, H - 30);
  ctx.rotate(Math.PI);
  ctx.textAlign = "left";
  ctx.fillText(card.rank, 0, 0);
  ctx.restore();

  drawSuit(ctx, card.suit, W / 2, H / 2, 70, color);

  return canvas.toBuffer("image/png");
}

module.exports = { renderCard };
