"use strict";

const fs   = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "../../data");
const FILE     = path.join(DATA_DIR, "snipeCache.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ─── Snipe cache ─────────────────────────────────────────────────────────────
// `live`: short-term, in-memory only. Every message seen gets a lightweight
// record here so a later delete can be matched back to its content. Never
// written to disk -- almost none of it will ever actually get deleted, so
// there's no reason to persist all normal chat.
//
// `deleted`: the only thing persisted, to data/snipeCache.json. A message
// only lands here once a delete has actually been confirmed for it. This is
// what /snipe reads.
const LIVE_PER_CHANNEL    = 15;
const DELETED_PER_CHANNEL = 5;
const ENTRY_TTL_MS        = 30 * 60 * 1000;

const live = new Map(); // channelId -> array of entries, oldest first

let deleted = null; // { channelId: [entry, ...] }

function load() {
  if (deleted) return deleted;
  try {
    const raw = fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE, "utf8")) : {};
    // Only trust top-level keys whose value is actually an array -- guards
    // against ever reading a differently-shaped or corrupted file as if it
    // were valid channel data.
    deleted = {};
    for (const key of Object.keys(raw)) {
      if (Array.isArray(raw[key])) deleted[key] = raw[key];
    }
  } catch (err) {
    console.error("[Snipe] Failed to load snipeCache.json, starting fresh:", err.message);
    deleted = {};
  }
  return deleted;
}

function persist() {
  try {
    fs.writeFileSync(FILE, JSON.stringify(deleted, null, 2));
  } catch (err) {
    console.error("[Snipe] Failed to save snipeCache.json:", err.message);
  }
}

function makeEntry(message) {
  return {
    id: message.id,
    content: message.content || "",
    attachments: [...message.attachments.values()].map(a => a.url),
    authorId: message.author.id,
    authorTag: message.author.username,
    authorAvatar: message.author.displayAvatarURL({ size: 128 }),
    createdTimestamp: message.createdTimestamp,
    deletedTimestamp: null,
  };
}

/** Call on every human message seen in a guild channel. Memory only. */
function recordMessage(message) {
  if (!message.guild || !message.channel?.id || !message.author) return;
  if (!message.content && message.attachments.size === 0) return;

  const arr = live.get(message.channel.id) || [];
  arr.push(makeEntry(message));
  if (arr.length > LIVE_PER_CHANNEL) arr.shift();
  live.set(message.channel.id, arr);
}

/**
 * Call with the raw id/channelId from a MESSAGE_DELETE gateway packet.
 * Matches it against `live`; if found, moves it into `deleted` and persists.
 */
function recordDelete(messageId, channelId) {
  const arr = live.get(channelId);
  const idx = arr ? arr.findIndex(e => e.id === messageId) : -1;
  if (idx === -1) {
    console.log(`[Snipe] Delete for ${messageId} in ${channelId} — not in the tracked buffer (sent before a restart, wasn't text/attachment, or was a bot message).`);
    return;
  }

  const [entry] = arr.splice(idx, 1);
  entry.deletedTimestamp = Date.now();

  const d = load();
  const delArr = d[channelId] || [];
  delArr.unshift(entry);
  if (delArr.length > DELETED_PER_CHANNEL) delArr.pop();
  d[channelId] = delArr;
  persist();
  console.log(`[Snipe] Recorded delete of ${messageId} in ${channelId} (${delArr.length} snipeable here now).`);
}

/** What /snipe reads: this channel's recent deletes, newest first, TTL-filtered. */
function getSnipes(channelId) {
  const arr = load()[channelId] || [];
  const now = Date.now();
  return arr.filter(e => now - e.deletedTimestamp < ENTRY_TTL_MS);
}

module.exports = { recordMessage, recordDelete, getSnipes };