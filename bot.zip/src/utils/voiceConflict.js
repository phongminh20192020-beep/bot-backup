"use strict";

const { isInAfkVoice } = require("./afkVoice");

/**
 * Voice-listening sessions (/ttsvoice, /askvoice) use a raw @discordjs/voice
 * connection, which cannot coexist with Lavalink's connection or the AFK
 * voice connection in the same guild -- Discord only allows one voice
 * session per guild per bot. Rather than silently kicking whichever one was
 * there first, these commands just refuse and ask the person to disconnect
 * it themselves first.
 * @returns {string|null} a user-facing reason if occupied, else null
 */
function getVoiceConflict(client, guildId) {
  const player = client.lavalink?.getPlayer(guildId);
  if (player && (player.playing || player.paused || player.connected)) {
    return "I'm playing a music, please use disconnect then continue using that command again.";
  }
  if (isInAfkVoice(guildId)) {
    return "I'm currently in AFK voice mode here, please use disconnect then continue using that command again.";
  }
  return null;
}

module.exports = { getVoiceConflict };
