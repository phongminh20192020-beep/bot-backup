"use strict";

const { createCanvas, loadImage } = require("@napi-rs/canvas");

const COLOR_HEX = {
  red:    "#e64949",
  yellow: "#f0c419",
  green:  "#2fae5c",
  blue:   "#3a7bd5",
  wild:   "#1c1c1e",
  // UNO Flip dark-side colors (unoflip.js / unoVariants.js)
  teal:   "#0e8f8f",
  orange: "#e0722a",
  purple: "#7a3ac9",
  pink:   "#d94f8c",
};

// Any color string not in COLOR_HEX (shouldn't normally happen) falls back
// to a neutral gray instead of throwing/undefined, so a new variant card
// type never crashes rendering.
function colorHex(color) {
  return COLOR_HEX[color] || "#555b66";
}

// Short center label for card types the base renderer below doesn't have a
// bespoke icon for (used by the UNO Flip / No Mercy variants). Kept generic
// and additive so none of the existing classic-card branches change.
const GENERIC_CENTER_LABEL = {
  draw1:          "+1",
  draw5:          "+5",
  draw6:          "+6",
  draw10:         "+10",
  skipall:        "SKIP\nALL",
  discardall:     "ALL",
  flip:           "FLIP",
  wilddraw2:      "+2",
  wilddrawcolor:  "+?",
};
const GENERIC_CORNER_LABEL = {
  draw1: "+1", draw5: "+5", draw6: "+6", draw10: "+10",
  skipall: "SK*", discardall: "ALL", flip: "FLIP",
  wilddraw2: "+2", wilddrawcolor: "+?",
};

const CARD_W = 140;
const CARD_H = 200;

function roundRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y,     x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x,     y + h, r);
  ctx.arcTo(x,     y + h, x,     y,     r);
  ctx.arcTo(x,     y,     x + w, y,     r);
  ctx.closePath();
}

function drawSkipIcon(ctx, cx, cy, r, color) {
  ctx.strokeStyle = color;
  ctx.lineWidth = r * 0.28;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 0.72, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  const dx = r * 0.72 * Math.cos(Math.PI / 4);
  const dy = r * 0.72 * Math.sin(Math.PI / 4);
  ctx.moveTo(cx - dx, cy - dy);
  ctx.lineTo(cx + dx, cy + dy);
  ctx.stroke();
}

function drawReverseIcon(ctx, cx, cy, r, color) {
  ctx.fillStyle = color;
  const shaftW = r * 0.34;
  const headW  = r * 0.62;
  const headL  = r * 0.5;
  const gap    = r * 0.22;

  // Top arrow, pointing right
  ctx.save();
  ctx.translate(cx, cy - gap);
  ctx.beginPath();
  ctx.rect(-r * 0.75, -shaftW / 2, r * 1.1, shaftW);
  ctx.moveTo(r * 0.35, -headW / 2);
  ctx.lineTo(r * 0.35 + headL, 0);
  ctx.lineTo(r * 0.35, headW / 2);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // Bottom arrow, pointing left
  ctx.save();
  ctx.translate(cx, cy + gap);
  ctx.beginPath();
  ctx.rect(-r * 0.35, -shaftW / 2, r * 1.1, shaftW);
  ctx.moveTo(-r * 0.35, -headW / 2);
  ctx.lineTo(-r * 0.35 - headL, 0);
  ctx.lineTo(-r * 0.35, headW / 2);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawWildQuadrants(ctx, cx, cy, r) {
  const colors = [COLOR_HEX.red, COLOR_HEX.yellow, COLOR_HEX.green, COLOR_HEX.blue];
  colors.forEach((hex, i) => {
    ctx.fillStyle = hex;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, r, (Math.PI / 2) * i, (Math.PI / 2) * (i + 1));
    ctx.closePath();
    ctx.fill();
  });
}

function cornerText(card) {
  if (card.type === "number")  return String(card.value);
  if (card.type === "skip")    return "SKIP";
  if (card.type === "reverse") return "REV";
  if (card.type === "draw2")   return "+2";
  if (card.type === "wild4")   return "+4";
  if (GENERIC_CORNER_LABEL[card.type]) return GENERIC_CORNER_LABEL[card.type];
  return "W";
}

/**
 * Render a single UNO card face onto its own canvas.
 * @returns {import("@napi-rs/canvas").Canvas}
 */
function renderCardCanvas(card, { width = CARD_W, height = CARD_H, faceDown = false } = {}) {
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");
  const r = width * 0.12;

  if (faceDown) {
    roundRectPath(ctx, 1, 1, width - 2, height - 2, r);
    ctx.fillStyle = "#12121a";
    ctx.fill();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.save();
    ctx.translate(width / 2, height / 2);
    ctx.rotate(-0.35);
    ctx.fillStyle = "#e64949";
    ctx.font = `bold ${width * 0.24}px sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("UNO", 0, 0);
    ctx.restore();
    return canvas;
  }

  const baseHex = colorHex(card.color);

  roundRectPath(ctx, 1, 1, width - 2, height - 2, r);
  ctx.fillStyle = baseHex;
  ctx.fill();
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 3;
  ctx.stroke();

  // The classic tilted white ellipse behind the big central symbol.
  ctx.save();
  ctx.translate(width / 2, height / 2);
  ctx.rotate(-0.35);
  ctx.scale(1, 0.62);
  ctx.beginPath();
  ctx.arc(0, 0, width * 0.62, 0, Math.PI * 2);
  ctx.fillStyle = "#ffffff";
  ctx.fill();
  ctx.restore();

  const cx = width / 2, cy = height / 2;
  const symbolRadius = width * 0.30;

  if (card.color === "wild") {
    drawWildQuadrants(ctx, cx, cy, symbolRadius);
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(cx, cy, symbolRadius * 0.32, 0, Math.PI * 2);
    ctx.fill();
    if (card.type === "wild4") {
      ctx.fillStyle = "#1c1c1e";
      ctx.font = `bold ${width * 0.16}px sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("+4", cx, cy);
    }
  } else if (card.type === "number") {
    ctx.fillStyle = baseHex;
    ctx.font = `bold ${width * 0.42}px sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(card.value), cx, cy + height * 0.02);
  } else if (card.type === "skip") {
    drawSkipIcon(ctx, cx, cy, symbolRadius, baseHex);
  } else if (card.type === "reverse") {
    drawReverseIcon(ctx, cx, cy, symbolRadius, baseHex);
  } else if (card.type === "draw2") {
    ctx.fillStyle = baseHex;
    ctx.font = `bold ${width * 0.20}px sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("+2", cx, cy);
  } else if (GENERIC_CENTER_LABEL[card.type]) {
    // UNO Flip / UNO No Mercy card faces -- a plain bold label centered on
    // the card, in the same visual language as the classic +2/+4 cards
    // above, so a new card type never needs its own bespoke icon to be
    // legible on the table/hand images.
    ctx.fillStyle = baseHex;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const label = GENERIC_CENTER_LABEL[card.type];
    const lines = label.split("\n");
    const fontSize = lines.length > 1 ? width * 0.155 : width * 0.20;
    ctx.font = `bold ${fontSize}px sans-serif`;
    const lineH = fontSize * 1.05;
    const startY = cy - ((lines.length - 1) * lineH) / 2;
    lines.forEach((line, i) => ctx.fillText(line, cx, startY + i * lineH));
  }

  // Small corner index, top-left and bottom-right, for quick scanning.
  const label = cornerText(card);
  ctx.fillStyle = "#ffffff";
  ctx.font = `bold ${width * 0.11}px sans-serif`;
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.fillText(label, width * 0.08, height * 0.05);

  ctx.save();
  ctx.translate(width * 0.92, height * 0.95);
  ctx.rotate(Math.PI);
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.fillText(label, 0, 0);
  ctx.restore();

  return canvas;
}

/**
 * Render a full hand as one wide image, cards side by side with index numbers
 * underneath (so a player can reference "play card 3" if needed, though the
 * bot primarily uses select menus for actual input).
 */
function renderHandImage(hand) {
  const gap = 12;
  const labelH = 26;
  const width  = hand.length * CARD_W + (hand.length + 1) * gap;
  const height = CARD_H + labelH + gap * 2;

  const canvas = createCanvas(Math.max(width, 200), height);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#0e0e14";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  hand.forEach((card, i) => {
    const x = gap + i * (CARD_W + gap);
    const y = gap;
    const cardCanvas = renderCardCanvas(card);
    ctx.drawImage(cardCanvas, x, y);

    ctx.fillStyle = "#c9ccd1";
    ctx.font = "bold 18px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    ctx.fillText(String(i + 1), x + CARD_W / 2, y + CARD_H + 4);
  });

  return canvas.toBuffer("image/png");
}

/**
 * Render the shared table view: discard pile top card, current color banner,
 * turn direction, and each player's name + card count (never their cards).
 */
function renderTableImage(state) {
  const width    = 900;
  const rowH     = 56;
  const cardArea = 320; // room for the discard card + color banner + direction text
  const height   = cardArea + state.players.length * rowH + 20;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = "#12121a";
  ctx.fillRect(0, 0, width, height);

  // Discard pile (top card)
  const topCard = state.discard[state.discard.length - 1];
  const cardCanvas = renderCardCanvas(topCard, { width: 180, height: 258 });
  ctx.drawImage(cardCanvas, 40, 30);

  // Current color banner
  const bannerHex = COLOR_HEX[state.currentColor] || "#888";
  ctx.fillStyle = bannerHex;
  roundRectPath(ctx, 260, 30, 300, 50, 10);
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 22px sans-serif";
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  const colorName = state.currentColor[0].toUpperCase() + state.currentColor.slice(1);
  ctx.fillText(`Current color: ${colorName}`, 278, 55);

  // Direction indicator (small drawn arrow instead of a unicode glyph, which
  // this environment's font doesn't have a glyph for)
  ctx.fillStyle = "#c9ccd1";
  ctx.font = "20px sans-serif";
  ctx.fillText("Direction:", 260, 100);
  ctx.save();
  ctx.translate(400, 100);
  if (state.direction === -1) ctx.scale(-1, 1);
  ctx.fillStyle = "#e6e6ea";
  ctx.beginPath();
  ctx.moveTo(-22, -6); ctx.lineTo(10, -6); ctx.lineTo(10, -14); ctx.lineTo(28, 0);
  ctx.lineTo(10, 14); ctx.lineTo(10, 6); ctx.lineTo(-22, 6);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  ctx.fillStyle = "#c9ccd1";
  ctx.font = "20px sans-serif";
  ctx.fillText(state.direction === 1 ? "Clockwise" : "Counter-clockwise", 445, 100);
  ctx.fillText(`Cards left in deck: ${state.deck.length}`, 260, 128);

  // Player rows
  let y = cardArea;
  ctx.font = "bold 24px sans-serif";
  state.players.forEach((p, i) => {
    const isTurn = i === state.turnIndex;
    if (isTurn) {
      ctx.fillStyle = "rgba(255,255,255,0.08)";
      ctx.fillRect(20, y - 34, width - 40, rowH - 6);
      // Small filled triangle marker instead of a unicode ▶ (unsupported glyph)
      ctx.fillStyle = "#f0c419";
      ctx.beginPath();
      ctx.moveTo(36, y - 8); ctx.lineTo(50, y); ctx.lineTo(36, y + 8);
      ctx.closePath();
      ctx.fill();
    }
    ctx.fillStyle = isTurn ? "#f0c419" : "#e6e6ea";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    const botTag = p.isBot ? " (bot)" : "";
    ctx.fillText(`${p.username}${botTag}`, 60, y);

    ctx.textAlign = "right";
    ctx.fillStyle = "#9aa0a6";
    ctx.font = "20px sans-serif";
    ctx.fillText(`${p.hand.length} card${p.hand.length === 1 ? "" : "s"}`, width - 40, y);
    ctx.font = "bold 24px sans-serif";

    y += rowH;
  });

  return canvas.toBuffer("image/png");
}

module.exports = { renderCardCanvas, renderHandImage, renderTableImage, CARD_W, CARD_H, COLOR_HEX, colorHex, roundRectPath };