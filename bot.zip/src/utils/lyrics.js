"use strict";

/**
 * Shared lyrics lookup used by /lyrics, /lyric, and the dashboard's lyrics
 * panel. Tries LRCLIB first (free, keyless, purpose-built for time-synced
 * LRC lyrics) and falls back to lyrics.ovh for plain text only when no
 * synced (or even unsynced) match exists there.
 */

const https = require("https");
const { fetchFromMusixmatch } = require("./musixmatch");
const { fetchFromSpotify } = require("./spotify-lyrics");

const CACHE_TTL_MS = 10 * 60 * 1000; // 10 min
const cache = new Map(); // key -> { at, data }

function cacheKey(artist, title) {
  return `${(artist || "").toLowerCase().trim()}|${(title || "").toLowerCase().trim()}`;
}

function httpsGetJson(hostname, path, headers) {
  return new Promise((resolve, reject) => {
    const req = https.request({ hostname, path, method: "GET", headers }, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
        try {
          resolve(JSON.parse(data));
        } catch {
          reject(new Error("Parse error"));
        }
      });
    });
    req.on("error", reject);
    req.setTimeout(8000, () => { req.destroy(); reject(new Error("Timeout")); });
    req.end();
  });
}

/** Parses standard LRC-format text ("[mm:ss.xx]line") into [{time, text}] in ms, sorted. */
function parseLrc(lrcText) {
  const lines = [];
  for (const raw of lrcText.split("\n")) {
    const match = raw.match(/^\[(\d{1,2}):(\d{2}(?:\.\d{1,3})?)\](.*)$/);
    if (!match) continue;
    const minutes = parseInt(match[1], 10);
    const seconds = parseFloat(match[2]);
    const text = match[3].trim();
    lines.push({ time: Math.round((minutes * 60 + seconds) * 1000), text });
  }
  return lines.sort((a, b) => a.time - b.time);
}

// Trailing tag words YouTube titles commonly carry ("Official Video", "Lyrics", …)
// that get peeled off one at a time once the title is split on dashes. A
// segment counts as junk only if *every* word in it is one of these.
const JUNK_WORDS = new Set([
  "official", "music", "lyrics", "lyric", "video", "audio", "visualizer", "mv", "hd", "4k", "hq",
]);
function isJunkSegment(segment) {
  const words = segment.toLowerCase().split(/\s+/).filter(Boolean);
  return words.length > 0 && words.every((w) => JUNK_WORDS.has(w));
}

/**
 * Cleans a title/author the same way across every caller, so lookups match
 * consistently. Handles messy real-world YouTube titles like
 * "Channel Official — ARTIST - Song Title | OFFICIAL LYRICS VIDEO" by:
 *   1. stripping (Official Video)/[4K]-style bracketed junk
 *   2. dropping anything after a "|" separator (another common junk spot)
 *   3. splitting the rest on spaced dashes (" - " / " – " / " — ") and
 *      peeling trailing junk words off the end
 *   4. taking the *last two* remaining segments as Artist - Title, since
 *      channel branding (if any) sits before an earlier dash, not after
 */
function resolveArtistTitle(track) {
  const rawTitle = (track.info.title || "")
    // Only drop (...)/[...] when every word inside is junk — real subtitles
    // like "(MƯA VỘI PHÓNG)" or alt-language titles must survive, since
    // that's often the exact text lyrics databases index the song under.
    .replace(/[\(\[]([^\)\]]*)[\)\]]/g, (full, inner) => (isJunkSegment(inner) ? "" : full))
    .replace(/["""'']/g, "") // stray quote marks (e.g. group names like ANH TRAI "SAY HI")
    .split("|")[0] // "Song Title | OFFICIAL LYRICS VIDEO" -> "Song Title "
    .trim();

  const rawAuthor = (track.info.author || "")
    .replace(/\s*-\s*Topic$/i, "")
    .replace(/VEVO\s*$/i, "")
    .replace(/\s*-?\s*Official$/i, "")
    .replace(/["""'']/g, "")
    .trim();

  const parts = rawTitle
    .split(/\s+[-–—]\s+/) // spaced dashes only, so "Sorry-Not-Sorry" stays intact
    .map((s) => s.trim())
    .filter(Boolean);
  while (parts.length > 1 && isJunkSegment(parts[parts.length - 1])) parts.pop();

  if (parts.length >= 2) {
    // Last two segments are the real "Artist - Title" pair — anything
    // before that (channel branding joined by an earlier dash) is dropped.
    return { artist: parts[parts.length - 2], title: parts[parts.length - 1] };
  }
  return { artist: rawAuthor, title: parts.join(" - ") || rawTitle };
}

async function fetchFromLrclib(artist, title, durationSec) {
  const qs = new URLSearchParams({ track_name: title, artist_name: artist || "" });
  if (durationSec) qs.set("duration", String(Math.round(durationSec)));

  // Exact-match endpoint first (best quality match when it hits).
  try {
    const exact = await httpsGetJson("lrclib.net", `/api/get?${qs.toString()}`, { "User-Agent": "DiscordMusicBot/1.0" });
    if (exact && (exact.syncedLyrics || exact.plainLyrics)) {
      return {
        synced: exact.syncedLyrics ? parseLrc(exact.syncedLyrics) : null,
        plain: exact.plainLyrics || null,
      };
    }
  } catch {
    // fall through to fuzzy search
  }

  // Fuzzy search fallback — take the first result that actually has synced lyrics.
  try {
    const results = await httpsGetJson(
      "lrclib.net",
      `/api/search?${new URLSearchParams({ track_name: title, artist_name: artist || "" }).toString()}`,
      { "User-Agent": "DiscordMusicBot/1.0" }
    );
    if (Array.isArray(results)) {
      const withSync = results.find((r) => r.syncedLyrics) || results.find((r) => r.plainLyrics);
      if (withSync) {
        return {
          synced: withSync.syncedLyrics ? parseLrc(withSync.syncedLyrics) : null,
          plain: withSync.plainLyrics || null,
        };
      }
    }
  } catch {
    // nothing found
  }

  return { synced: null, plain: null };
}

function fetchFromLyricsOvh(artist, title) {
  return new Promise((resolve, reject) => {
    const slug = (str) => encodeURIComponent((str || "").replace(/[^\w\s'-]/gi, "").trim());
    const path = artist ? `/v1/${slug(artist)}/${slug(title)}` : `/v1/unknown/${slug(title)}`;

    https.get({ hostname: "api.lyrics.ovh", path, headers: { "User-Agent": "DiscordMusicBot/1.0" } }, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        if (res.statusCode !== 200) return reject(new Error("Not found"));
        try {
          const json = JSON.parse(data);
          json.lyrics ? resolve(json.lyrics.trim()) : reject(new Error("No lyrics field"));
        } catch {
          reject(new Error("Parse error"));
        }
      });
    }).on("error", reject);
  });
}

/**
 * Returns { synced: [{time,text}]|null, plain: string|null, source: string|null }.
 * `synced` is only present when real timestamp data was found (LRCLIB).
 */
async function getLyrics(artist, title, durationSec, spotifyTrackId) {
  const key = cacheKey(artist, title);
  const cached = cache.get(key);
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.data;

  let result = await lookupAllSources(artist, title, durationSec, spotifyTrackId);

  // Channel-derived artist names are sometimes wrong in a way no amount of
  // string-cleanup fixes — e.g. a show's parent-brand name ("ANH TRAI SAY
  // HI") vs. the actual credited sub-group ("TINH HÀ SAY HI"). If nothing
  // matched with the artist included, retry once title-only: LRCLIB's fuzzy
  // search and Musixmatch's matcher can often still find the right song on
  // title alone, where a wrong artist would otherwise rule every candidate out.
  if (!result.plain && !result.synced && artist) {
    result = await lookupAllSources("", title, durationSec, undefined);
  }

  cache.set(key, { at: Date.now(), data: result });
  return result;
}

async function lookupAllSources(artist, title, durationSec, spotifyTrackId) {
  let result = { synced: null, plain: null, source: null };

  try {
    const spotify = await fetchFromSpotify(artist, title, spotifyTrackId);
    if (spotify && (spotify.synced || spotify.plain)) {
      result = { synced: spotify.synced, plain: spotify.plain, source: "spotify" };
    }
  } catch {
    // SPOTIFY_SP_DC missing/expired, or Spotify unreachable — fall through.
  }

  if (!result.plain && !result.synced) {
    try {
      const mxm = await fetchFromMusixmatch(artist, title, { durationSec });
      if (mxm && (mxm.synced || mxm.plain)) {
        result = {
          synced: mxm.synced ? parseLrc(mxm.synced) : null,
          plain: mxm.plain || null,
          source: "musixmatch",
        };
      }
    } catch {
      // Musixmatch unreachable/blocked on this host — fall through to LRCLIB.
    }
  }

  if (!result.plain && !result.synced) {
    try {
      const lrclib = await fetchFromLrclib(artist, title, durationSec);
      if (lrclib.synced || lrclib.plain) {
        result = { synced: lrclib.synced, plain: lrclib.plain, source: "lrclib" };
      }
    } catch {
      // ignore, try next source
    }
  }

  if (!result.plain && !result.synced) {
    try {
      const plain = await fetchFromLyricsOvh(artist, title);
      result = { synced: null, plain, source: "lyrics.ovh" };
    } catch {
      // no lyrics anywhere
    }
  }

  return result;
}

/**
 * Converts a LavaLyrics-plugin result (returned by lavalink-client's
 * player.getCurrentLyrics()/getLyrics()) into the same {synced, plain}
 * shape used everywhere else in the bot.
 */
function fromLavalyricsResult(result) {
  if (!result) return null;
  const lines = Array.isArray(result.lines) ? result.lines : [];
  const synced = lines.length > 1
    ? lines
        // Keep `null`/`undefined` distinguishable from a genuine 0ms
        // timestamp — some sources (notably plain-text-only providers with
        // no real per-line sync data) report every line at the same
        // timestamp, which isPlausiblySynced() below needs to catch.
        .map((l) => ({ time: typeof l.timestamp === "number" ? l.timestamp : 0, text: l.line || "" }))
        .sort((a, b) => a.time - b.time)
    : null;
  const plain = result.text || (lines.length ? lines.map((l) => l.line).join("\n") : null);
  return synced || plain ? { synced, plain } : null;
}

/**
 * Some lyrics sources report a "synced" line list that isn't really
 * time-synced (e.g. every line stamped at 0ms, or only a couple of lines
 * carrying a real timestamp). Trusting that blindly makes the dashboard's
 * live-sync view look permanently broken — no line ever becomes "active"
 * as the track plays, since positions never line up. This sanity-checks
 * the timestamps before treating a result as genuinely synced.
 */
function isPlausiblySynced(synced) {
  if (!Array.isArray(synced) || synced.length < 2) return false;
  const times = synced.map((l) => l.time).filter((t) => typeof t === "number" && t >= 0);
  const positive = times.filter((t) => t > 0);
  if (positive.length < synced.length * 0.6) return false; // too many blank/zero timestamps
  return Math.max(...times) - Math.min(...times) > 3000; // needs real spread across the track
}

/**
 * Resolves lyrics for a currently-playing (or queued) track. Prefers
 * Lavalink's own built-in LavaLyrics plugin first — it reuses metadata
 * Lavalink already resolved for the track (Spotify/Deezer/YouTube), so
 * it's usually faster and better-matched than an external lookup — and
 * only falls back to LRCLIB / lyrics.ovh when the node has no plugin
 * loaded or no source has lyrics for that track.
 *
 * `player` is a lavalink-client Player instance. `track` defaults to
 * player.queue.current when omitted.
 */
async function getLyricsForTrack(player, track) {
  const t = track || player?.queue?.current;
  const { artist, title } = resolveArtistTitle(t);

  if (player && typeof player.getCurrentLyrics === "function") {
    try {
      const result = track
        ? await player.getLyrics(track, false)
        : await player.getCurrentLyrics(false);
      const converted = fromLavalyricsResult(result);
      if (converted) {
        const safeSynced = isPlausiblySynced(converted.synced) ? converted.synced : null;
        // Fall back to a flattened plain-text version of the same lines if
        // the node didn't also give us `text` directly — better than
        // discarding lyrics we already have just because they're not
        // reliably synced.
        const plain = converted.plain || (converted.synced ? converted.synced.map((l) => l.text).join("\n") : null);
        if (safeSynced || plain) {
          return {
            synced: safeSynced,
            plain,
            artist,
            title,
            source: `lavalink:${result.provider || result.sourceName || "node"}`,
          };
        }
      }
    } catch {
      // Node has no LavaLyrics plugin loaded, or no configured source matched — fall through.
    }
  }

  const durationSec = t?.info?.duration ? t.info.duration / 1000 : undefined;
  // If Lavalink already resolved this track via Spotify (LavaSrc), reuse
  // that ID directly instead of making fetchFromSpotify search for it —
  // more reliable than an artist/title text match.
  const spotifyTrackId = t?.info?.sourceName === "spotify" ? t.info.identifier : undefined;
  const { synced, plain, source } = await getLyrics(artist, title, durationSec, spotifyTrackId);
  const safeSynced = isPlausiblySynced(synced) ? synced : null;
  const safePlain = plain || (synced && !safeSynced ? synced.map((l) => l.text).join("\n") : null);
  return { synced: safeSynced, plain: safePlain, artist, title, source };
}

module.exports = { getLyrics, resolveArtistTitle, parseLrc, getLyricsForTrack, fromLavalyricsResult, isPlausiblySynced };
