"use strict";

const fs   = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "../../data");
const FILE     = path.join(DATA_DIR, "inbox.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// Single global inbox channel (not per-guild) -- the bot only has one DM
// inbox regardless of how many servers it's in, same convention as afk.json
// and economy.js. Shape: { channelId: string | null }
let cache = null;

function load() {
  if (cache) return cache;
  try {
    cache = fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE, "utf8")) : { channelId: null };
  } catch (err) {
    console.error("[Inbox] Failed to load inbox.json, starting fresh:", err.message);
    cache = { channelId: null };
  }
  return cache;
}

function persist() {
  try {
    fs.writeFileSync(FILE, JSON.stringify(cache, null, 2));
  } catch (err) {
    console.error("[Inbox] Failed to save inbox.json:", err.message);
  }
}

function getInboxChannelId() {
  return load().channelId ?? null;
}

function setInboxChannelId(channelId) {
  const data = load();
  data.channelId = channelId;
  persist();
}

function clearInboxChannelId() {
  const data = load();
  data.channelId = null;
  persist();
}

module.exports = { getInboxChannelId, setInboxChannelId, clearInboxChannelId };
