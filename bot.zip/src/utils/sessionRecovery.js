"use strict";

// ─── Session recovery ─────────────────────────────────────────────────────────
// Without this, a Lavalink disconnect or a process restart (redeploy, host
// killing the container, the watchdog giving up) just silently drops
// whatever was playing -- the bot comes back up with zero memory of what it
// was doing, and nobody in the server knows it was ever interrupted.
//
// This module does two things:
//   1. snapshotActiveSessions() -- called right before something is about to
//      yank playback out from under the bot. Saves every active player's
//      current track/position/queue/voice+text channel to disk, tagged with
//      *why*, reusing the existing queueStore save file so /restore keeps
//      working on it unchanged.
//   2. announceInterruptedSessions() -- called once, right after the bot's
//      first successful reconnect of the process. Scans for any auto-saved
//      (i.e. not a manual /disconnect) session that hasn't been reported yet
//      and posts a plain heads-up in the channel it was playing in, so
//      "why did the bot just vanish" has an answer waiting instead of
//      silence.

const fs   = require("fs");
const path = require("path");
const { EmbedBuilder }                         = require("discord.js");
const { saveQueue, STORE_DIR, markNotified }   = require("./queueStore");
const { formatDuration }                       = require("./helpers");

function snapshotActiveSessions(client, reason) {
  const players = client.lavalink?.players;
  if (!players?.size) return;

  let count = 0;
  for (const player of players.values()) {
    // Nothing playing/queued for this guild -- nothing worth reporting.
    if (!player.queue.current && !player.queue.tracks.length) continue;
    saveQueue(player, { auto: true, reason });
    count++;
  }
  if (count) console.log(`[SessionRecovery] Snapshotted ${count} active session(s) — reason: ${reason}`);
}

async function announceInterruptedSessions(client) {
  if (!fs.existsSync(STORE_DIR)) return;

  const files = fs.readdirSync(STORE_DIR).filter(f => f.endsWith(".json"));
  for (const file of files) {
    const guildId = file.replace(/\.json$/, "");
    let saved;
    try {
      saved = JSON.parse(fs.readFileSync(path.join(STORE_DIR, file), "utf8"));
    } catch {
      continue;
    }

    // Only auto-saved (i.e. actually interrupted) sessions that haven't
    // already been reported, and only if we know where to post.
    if (!saved?.auto || saved.notified || !saved.textChannelId) continue;

    try {
      const channel = await client.channels.fetch(saved.textChannelId).catch(() => null);
      if (channel) {
        const title    = saved.current?.info?.title || "something";
        const durMs    = saved.current?.info?.duration || 0;
        const posMs    = saved.position || 0;
        const minsAgo  = Math.max(0, Math.round((Date.now() - saved.savedAt) / 60000));
        const whenText = minsAgo <= 1 ? "less than a minute ago" : `about ${minsAgo} minutes ago`;

        await channel.send({
          embeds: [
            new EmbedBuilder()
              .setTitle("<:Warning:1537804174451015791> I got triggered an error during playing")
              .setDescription(
                `I was playing **${title}**` +
                (durMs ? ` (at ${formatDuration(posMs)} / ${formatDuration(durMs)})` : "") +
                `${saved.reason ? `\nReason: ${saved.reason}` : ""}\n` +
                `That happened ${whenText}, so I lost my connection mid-session instead of leaving cleanly.\n\n` +
                `Run \`/restore\` to pick back up where I left off.`
              ),
          ],
        }).catch(() => {});
      }
    } catch (err) {
      console.error(`[SessionRecovery] Failed to announce interrupted session for guild ${guildId}:`, err.message);
    } finally {
      // Mark it notified regardless of whether the send worked (channel
      // deleted, missing perms, etc.) -- otherwise a permanently-unreachable
      // channel would retry and log an error on every single restart.
      markNotified(guildId);
    }
  }
}

module.exports = { snapshotActiveSessions, announceInterruptedSessions };
