"use strict";

/**
 * Manages the order utterances get processed in for a single guild's voice
 * session: whoever finishes talking first gets answered first. If two or
 * more utterances finish at the exact same millisecond (a genuine tie --
 * rare, but possible with simultaneous speakers), the tie is broken randomly
 * rather than by array insertion order, per an explicit request to use
 * randomness for that case specifically.
 *
 * A cooldown enforces a minimum gap between the end of processing one
 * utterance and the start of the next, so replies don't pile up back-to-back.
 */
class UtteranceScheduler {
  constructor({ cooldownMs = 3000, onProcess } = {}) {
    this.cooldownMs = cooldownMs;
    this.onProcess  = onProcess; // async (item) => void
    this.queue      = [];
    this.processing = false;
    this.lastFinishedAt = 0;
  }

  /** @param {{ completedAt: number }} item - completedAt should be Date.now() when the utterance finished */
  push(item) {
    this.queue.push(item);
    this._drain();
  }

  size() {
    return this.queue.length;
  }

  clear() {
    this.queue = [];
  }

  _takeNext() {
    if (!this.queue.length) return null;
    // Sort ascending by completion time; break exact ties randomly rather
    // than always favoring whichever happened to be pushed first.
    let minTime = Infinity;
    for (const item of this.queue) if (item.completedAt < minTime) minTime = item.completedAt;
    const tied = this.queue.filter(item => item.completedAt === minTime);
    const chosen = tied[Math.floor(Math.random() * tied.length)];
    this.queue = this.queue.filter(item => item !== chosen);
    return chosen;
  }

  async _drain() {
    if (this.processing) return;
    this.processing = true;

    try {
      while (this.queue.length) {
        const waitLeft = this.cooldownMs - (Date.now() - this.lastFinishedAt);
        if (waitLeft > 0) await new Promise(r => setTimeout(r, waitLeft));

        const item = this._takeNext();
        if (!item) break;

        try {
          await this.onProcess(item);
        } catch (err) {
          console.error("[UtteranceScheduler] onProcess threw:", err.message);
        }
        this.lastFinishedAt = Date.now();
      }
    } finally {
      this.processing = false;
    }
  }
}

module.exports = { UtteranceScheduler };
