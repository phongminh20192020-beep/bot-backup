"use strict";

/**
 * Spotify's own internal lyrics endpoint, authenticated with a personal
 * `sp_dc` session cookie — the same cookie your browser holds while logged
 * into open.spotify.com. Set it as SPOTIFY_SP_DC in your .env.
 *
 * IMPORTANT: that cookie is a full session credential for your Spotify
 * account, equivalent to being logged in as you. Never commit it, paste it
 * anywhere public, or share it — treat it like a password. If it ever
 * leaks, log out of all devices from Spotify's account settings to
 * invalidate it.
 *
 * This isn't a public/documented API, just what the Spotify web player
 * itself calls for the logged-in account that cookie belongs to. Like
 * musixmatch.js, every function here fails quietly (returns null) instead
 * of throwing, so if the cookie is missing, expired, or Spotify blocks the
 * request, lyrics.js just falls through to the next source in the chain.
 */

const https = require("https");

let cachedAuth = null; // { accessToken, expiresAt }

function getJson(hostname, path, headers) {
  return new Promise((resolve, reject) => {
    const req = https.request({ hostname, path, method: "GET", headers }, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
        try {
          resolve(JSON.parse(data));
        } catch {
          reject(new Error("Spotify: non-JSON response"));
        }
      });
    });
    req.on("error", reject);
    req.setTimeout(8000, () => {
      req.destroy();
      reject(new Error("Spotify: timeout"));
    });
    req.end();
  });
}

async function fetchAccessToken() {
  const sp_dc = process.env.SPOTIFY_SP_DC;
  if (!sp_dc) return null; // not configured — this source is simply skipped

  const json = await getJson(
    "open.spotify.com",
    "/get_access_token?reason=transport&productType=web_player",
    { Cookie: `sp_dc=${sp_dc}`, "User-Agent": "Mozilla/5.0" }
  );
  if (!json?.accessToken) throw new Error("Spotify: no access token — sp_dc likely expired");

  return {
    accessToken: json.accessToken,
    // Spotify sends an absolute expiry timestamp; fall back to ~55min if missing.
    expiresAt: json.accessTokenExpirationTimestampMs || Date.now() + 55 * 60 * 1000,
  };
}

/** Returns a cached bearer token, refreshing ~30s before it actually expires. */
async function getAccessToken() {
  if (cachedAuth && Date.now() < cachedAuth.expiresAt - 30_000) return cachedAuth.accessToken;
  const auth = await fetchAccessToken();
  if (!auth) return null;
  cachedAuth = auth;
  return auth.accessToken;
}

async function findTrackId(accessToken, artist, title) {
  const q = encodeURIComponent(`${title} ${artist}`.trim());
  const json = await getJson("api.spotify.com", `/v1/search?q=${q}&type=track&limit=1`, {
    Authorization: `Bearer ${accessToken}`,
  });
  return json?.tracks?.items?.[0]?.id || null;
}

async function fetchLyricsById(accessToken, trackId) {
  const json = await getJson(
    "spclient.wg.spotify.com",
    `/color-lyrics/v2/track/${trackId}?format=json&market=from_token`,
    { Authorization: `Bearer ${accessToken}`, "App-platform": "WebPlayer" }
  );
  const lines = json?.lyrics?.lines;
  if (!Array.isArray(lines) || !lines.length) return null;

  const synced =
    json.lyrics.syncType === "LINE_SYNCED"
      ? lines.map((l) => ({ time: Number(l.startTimeMs) || 0, text: l.words || "" }))
      : null;
  const plain = lines.map((l) => l.words || "").join("\n");

  return { synced, plain };
}

/**
 * Looks up lyrics on Spotify. Returns { synced: [{time,text}]|null, plain:
 * string|null }, or null if unavailable for any reason (cookie missing or
 * expired, no track match, instrumental with no lyrics, network error).
 * Never throws.
 *
 * `spotifyTrackId` is optional — pass it when the track was already
 * resolved via Spotify (e.g. LavaSrc) to skip the search step and get a
 * more reliable match than an artist/title text search would give.
 */
async function fetchFromSpotify(artist, title, spotifyTrackId) {
  try {
    const accessToken = await getAccessToken();
    if (!accessToken) return null;

    const trackId = spotifyTrackId || (await findTrackId(accessToken, artist, title));
    if (!trackId) return null;

    return await fetchLyricsById(accessToken, trackId);
  } catch {
    return null;
  }
}

module.exports = { fetchFromSpotify, getAccessToken };
