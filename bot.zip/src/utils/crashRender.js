"use strict";

const { createCanvas } = require("@napi-rs/canvas");
const { INK, BG } = require("./canvasDoodle");

const W = 480;
const H = 240;
const PAD = 36;

/**
 * @param {number[]} history - multiplier value at each tick so far, e.g. [1, 1.06, 1.12, ...]
 * @param {boolean} crashed - whether this is the final "crashed" frame
 * @returns {Buffer} PNG image buffer
 */
function renderCrashChart(history, crashed = false) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, H);

  const maxVal = Math.max(2, ...history) * 1.15;
  const plotW = W - PAD * 2;
  const plotH = H - PAD * 2;

  // Axes
  ctx.strokeStyle = "#d0d0d0";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(PAD, PAD);
  ctx.lineTo(PAD, H - PAD);
  ctx.lineTo(W - PAD, H - PAD);
  ctx.stroke();

  // Grid lines + labels at nice multiplier steps
  ctx.fillStyle = "#9aa0a6";
  ctx.font = "11px sans-serif";
  ctx.textAlign = "right";
  const step = maxVal > 5 ? 1 : 0.5;
  for (let v = step; v < maxVal; v += step) {
    const y = H - PAD - (v / maxVal) * plotH;
    ctx.strokeStyle = "#eeeeee";
    ctx.beginPath();
    ctx.moveTo(PAD, y);
    ctx.lineTo(W - PAD, y);
    ctx.stroke();
    ctx.fillText(`${v.toFixed(1)}x`, PAD - 6, y + 4);
  }

  // The climb line
  const pointFor = (i, v) => ({
    x: PAD + (i / Math.max(1, history.length - 1)) * plotW,
    y: H - PAD - (v / maxVal) * plotH,
  });

  ctx.strokeStyle = crashed ? "#e0503f" : "#5cb85c";
  ctx.lineWidth = 3;
  ctx.beginPath();
  history.forEach((v, i) => {
    const { x, y } = pointFor(i, v);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  ctx.stroke();

  // Current point marker
  const last = pointFor(history.length - 1, history[history.length - 1]);
  ctx.fillStyle = crashed ? "#e0503f" : "#5cb85c";
  ctx.beginPath();
  ctx.arc(last.x, last.y, 6, 0, Math.PI * 2);
  ctx.fill();

  // Big multiplier readout
  ctx.fillStyle = INK;
  ctx.font = "bold 30px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(`${history[history.length - 1].toFixed(2)}x`, PAD, PAD - 8);

  if (crashed) {
    ctx.fillStyle = "#e0503f";
    ctx.font = "bold 18px sans-serif";
    ctx.textAlign = "right";
    ctx.fillText("CRASHED", W - PAD, PAD - 8);
  }

  return canvas.toBuffer("image/png");
}

module.exports = { renderCrashChart };
