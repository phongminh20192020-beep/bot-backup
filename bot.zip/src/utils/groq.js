"use strict";

const { withApiLog, logApiCall } = require("./apiLogger");
const { getNonameTools, runNonameTool } = require("./nonameTools");

// Two providers, chosen per request via a "target" ({model, provider, ...}):
//   - Groq       : text chat, tools, translate, /imagine moderation, Whisper, TTS
//   - NaraRouter : messages with IMAGES -> stepfun-3.7-flash (vision)
// File + function names still say "groq" so nothing else in the project needs renaming.
// Read lazily so values from .env / a panel's Variables tab are always picked up.
const groqEndpoint = () => `${(process.env.GROQ_BASE_URL || "https://api.groq.com/openai/v1").replace(/\/+$/, "")}/chat/completions`;
const chatModel    = () => ({ model: process.env.GROQ_CHAT_MODEL || "openai/gpt-oss-120b", provider: "groq" });

const chatEndpoint = () => `${(process.env.NARAROUTER_BASE_URL || "https://router.bynara.id/v1").replace(/\/+$/, "")}/chat/completions`;
// Thinking level sent to NaraRouter models as reasoning_effort (low / medium / high). "off" = don't send.
const chatEffort   = () => process.env.NARAROUTER_CHAT_REASONING || "medium";
const GROQ_KEY_MSG = "GROQ_API_KEY is not set — add it to your .env file.";
const NARA_KEY_MSG = "NARAROUTER_API_KEY is not set — add it to your .env file (needed for image messages).";
// Messages that carry images use a dedicated vision model on NaraRouter:
// Step 3.7 Flash ("stepfun-3.7-flash") with the NaraRouter key. To point it at
// another provider (StepFun direct: https://api.stepfun.ai/v1 with model
// step-3.7-flash, or OpenRouter: model stepfun/step-3.7-flash), set
// VISION_BASE_URL and VISION_API_KEY (and VISION_MODEL) in .env.
const visionTarget = () => ({
  model:    process.env.VISION_MODEL || "stepfun-3.7-flash",
  provider: "nara",
  endpoint: process.env.VISION_BASE_URL ? `${process.env.VISION_BASE_URL.replace(/\/+$/, "")}/chat/completions` : undefined,
  apiKey:   process.env.VISION_API_KEY || undefined,
});
const MAX_IMAGES_PER_MSG = 3;

// Whisper transcription for voice messages / audio attachments. This is a
// separate endpoint entirely (audio in, plain text out) rather than a chat
// model -- there's no single Groq model that takes raw audio directly in a
// chat completion the way vision models take images. The transcript gets
// folded into the prompt text before it ever reaches askGroq() below.
// whisper-large-v3-turbo is fast and still very accurate -- a good default
// for a bot that needs to reply quickly. Swap to whisper-large-v3 via
// GROQ_AUDIO_MODEL in .env for max accuracy over speed.
const AUDIO_ENDPOINT = "https://api.groq.com/openai/v1/audio/transcriptions";
const AUDIO_MODEL    = process.env.GROQ_AUDIO_MODEL || "whisper-large-v3-turbo";

// ─── Persona + response-format contract ───────────────────────────────────────
// "noname" is meant to read like an actual person hanging out in the server,
// not a customer-support bot. To let it also react, join voice, and send up
// to 10 separate messages per turn, it has to answer in a strict JSON shape
// that the caller (messageCreate handler) can parse and act on. Everything
// about *how* those actions get carried out lives in index.js — this file's
// only job is "talk to Groq, get back a validated action object."
//
// Looking things up and writing code are NOT part of that JSON any more --
// they're real function-calling tools (see utils/nonameTools.js and
// chatWithTools() below). The model calls a tool mid-turn, reads the result,
// and only then writes its final JSON reply.
//
// This is a single-shot example: the whole "text" field below is one
// concrete example of a valid model response (as if noname had just said
// "mb bro, put it in self_action, here u go: [rules]"), which small/fast
// models often follow more reliably than a plain-prose spec. The rules text
// is written as a normal string and JSON.stringify()'d into that example, so
// it can be edited freely without hand-escaping anything.
const PERSONA_RULES = [
`Role: noname, lazy/sarcastic Discord bot by @non.js. lowercase, slang(bro,fr), no punctuation, mild swearing. Greetings/mentions="?". Cannot do task=":sob:" or "bro what?". Your max msgs is 10 messages. THE ONLY INPORTANT RULE: TALKING LIKE A REAL HUMAN AND MAKE SURE IT DOESNT FEEL AGENTIC, WHEN ANSWER TRY SHIRTEST AS U CAN. IF U CONFUSE/GREETING/BEING MENTIONED ABOUT SOMETHING SAY "?" . IF ASK A REALTIME OR NOWADAYS MEME USE SEARCH AND DONT EVER RETURN AN EMPTY RESPONSE
ONLY output raw JSON (no markdown): {"messages":[{"text":"...","delay":0}],"react":null,"join_voice":false,"self_action":null}
self_action (prev msg): {"type":"edit","new_text":"..."}, {"type":"delete"} or null.
Tools (call BEFORE JSON, max 1 search/turn): web_search: ONLY if asked or daily puzzles. Dont verify random facts, ignore local knowledge, use trusted sources. Error="broke". image_search: for pics, put real URL in JSON. reverse_image_search: identify attached img(ALAWAYS SEARCH ATTACHMENT WHEN A USER SEND). Code requests: no tool, say "write me ". NEVER write/paste code in JSON.`,
].join("\n");

const SYSTEM_PROMPT = JSON.stringify({
  messages: [{ text: `mb bro put it in self_action\n\nhere u go:\n\n${PERSONA_RULES}`, delay: 0 }],
  react: null,
  join_voice: false,
  self_action: null,
});

const MAX_REPLY_MESSAGES = 10;
const MAX_MESSAGE_DELAY_SECONDS = 15; // safety clamp in case the model returns something silly

// Max model <-> tool round trips in one turn. A couple of rounds is plenty:
// usually it's one search call, then the final answer.
const MAX_TOOL_ROUNDS = 3;

/**
 * Ask Groq for a "noname" style structured response.
 * The model may call tools along the way (web/image search, reverse image
 * search) -- those run inside this call, so the returned action is always the
 * FINAL answer. (Coding is a separate mode -- see utils/coder.js and the
 * "write me" trigger in index.js.)
 * @param {Object} opts
 * @param {string} opts.prompt - the user's current message text
 * @param {Array<{role: "user"|"assistant", content: string}>} [opts.history] - up to the last few turns
 * @param {string[]} [opts.imageUrls] - public URLs of images attached to the current message (e.g. Discord CDN links)
 * @param {{username: string, displayName: string, id: string}} [opts.author] - basic info about who's speaking, so noname can refer to them naturally
 * @param {{id: string, username: string, displayName: string, bot: boolean, createdAt: string}[]} [opts.mentionedUsers] - real Discord profile info for anyone else @-mentioned in the message (fetched live via GET /users/{id})
 * @param {{text: string}} [opts.lastOwnMessage] - noname's own last message in this channel, if any -- the only message self_action is ever allowed to touch
 * @param {boolean} [opts.richReplies=false] - true when the reply goes to a text channel (image links + file attachments work). Unlocks image_search / reverse_image_search; voice callers leave it off and only get web_search.
 * @param {boolean} [opts.useTools=true] - false = plain chat turn with no tools at all
 * @returns {Promise<{messages: {text: string, delay: number}[], react: string|null, join_voice: boolean, self_action: {type: "edit", new_text: string}|{type: "delete"}|null}>}
 */
async function askGroq({ prompt, history = [], imageUrls = [], author = null, mentionedUsers = [], lastOwnMessage = null, richReplies = false, useTools = true }) {
  const images  = imageUrls.slice(0, MAX_IMAGES_PER_MSG);
  const hasImage = images.length > 0;

  // Prepend lightweight, clearly-bracketed context lines ahead of the
  // actual message text -- who's speaking, and (if relevant) what noname's
  // own last message here was, so self_action has something concrete to
  // reference. These are plain text markers explained in SYSTEM_PROMPT, not
  // a separate API field, since Groq's chat completions endpoint has no
  // extra per-message metadata channel to carry this in otherwise.
  // Always present, not conditional -- without knowing what "today" is, the
  // model has no real way to judge whether something might be past its own
  // knowledge cutoff (e.g. "who won last night's game" is unanswerable-by-
  // guessing in a way the model can't even detect without a date to reason
  // against). This is what web_search's judgment above actually depends on.
  let contextPrefix = `[today: ${new Date().toISOString().slice(0, 10)}]\n`;
  if (author) {
    contextPrefix += `[speaking: ${author.displayName} (@${author.username}, id ${author.id})]\n`;
  }
  for (const u of mentionedUsers) {
    contextPrefix += `[mentioned: ${u.displayName} (@${u.username}, id ${u.id}, account created ${u.createdAt}${u.bot ? ", bot" : ""})]\n`;
  }
  if (lastOwnMessage?.text) {
    contextPrefix += `[your last message in this channel was: "${lastOwnMessage.text.slice(0, 300)}"]\n`;
  }
  const promptWithContext = contextPrefix ? `${contextPrefix}${prompt || ""}` : prompt;

  // Groq's vision models accept OpenAI-style "content" arrays mixing text
  // and image_url parts. Discord attachment URLs are already public https
  // links, so they can be passed straight through -- no need to download
  // and base64-encode them ourselves.
  const currentUserMessage = hasImage
    ? {
        role: "user",
        content: [
          { type: "text", text: promptWithContext || "what do you think of this? (Please answer shortly)" },
          ...images.map(url => ({ type: "image_url", image_url: { url } })),
        ],
      }
    : { role: "user", content: promptWithContext };

  const messages = [
    { role: "system", content: SYSTEM_PROMPT },
    ...history.map(m => ({ role: m.role, content: m.content })),
    currentUserMessage,
  ];

  // Image messages -> vision model (Step 3.7 Flash, NaraRouter); plain text -> chat model (Groq).
  // (callGroq* / groqRequest accept either a model string or a {model, endpoint, apiKey} target.)
  const model = hasImage ? visionTarget() : chatModel();

  // Everything the tools need.
  const toolCtx = {
    imageUrls: images,
    userId: author?.id ?? null,
    searches: 0,
  };
  const tools = useTools ? getNonameTools({ hasImages: hasImage, richReplies }) : [];

  const raw = tools.length
    ? await chatWithTools(model, messages, tools, toolCtx)
    : await callGroqWithJsonFallback(model, messages);
  const action = parseAction(raw);

  // parseAction() silently swallows two failure modes into generic canned
  // replies ("bro idk what to say to that ngl" / "bro my brain glitched,
  // say that again?") so the conversation never just dies -- but that also
  // means a call that's ACTUALLY failing every time looks identical to a
  // normal successful call in /apilogs (askGroq never throws, so it's
  // always logged 🟢 ok). If you're hearing/seeing the same canned line
  // regardless of what was asked, that's this path firing repeatedly --
  // check /apilogs recent api:Groq, it'll now show a 🔴 "fallback" entry
  // with a snippet of what the model actually returned, right next to the
  // 🟢 entry for the same call.
  const reason = action.__fallbackReason;
  delete action.__fallbackReason;
  if (reason) {
    console.warn(`[Groq] askGroq() fell back to a canned reply (${reason}). Raw model output:`, raw.slice(0, 500));
    logApiCall({
      api: "Groq",
      action: "chat completion (fallback)",
      ok: false,
      ms: 0,
      detail: prompt?.slice(0, 60),
      error: `Fell back to canned reply — ${reason}. Raw: ${raw.slice(0, 150).replace(/\s+/g, " ")}`,
    });
  }

  return action;
}

/** Shared upload step for both transcription entry points below. */
async function postTranscription(audioBuffer, filename) {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    throw new Error("GROQ_API_KEY is not set — add it to your .env file.");
  }

  const form = new FormData();
  form.append("model", AUDIO_MODEL);
  form.append("response_format", "json");
  form.append("file", new Blob([audioBuffer]), filename);

  const res = await fetch(AUDIO_ENDPOINT, {
    method: "POST",
    headers: { "Authorization": `Bearer ${apiKey}` },
    body: form,
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`Groq transcription error ${res.status}: ${errText.slice(0, 300)}`);
  }

  const data = await res.json();
  const text = data?.text?.trim();
  if (!text) throw new Error("Groq returned an empty transcription.");
  return text;
}

/**
 * Download a Discord audio attachment (voice message or uploaded audio file)
 * and transcribe it via Groq's Whisper endpoint.
 * @param {string} url - public https URL (Discord CDN attachment link)
 * @param {string} [filename] - original filename, used to guess the right
 *   extension for the upload; Discord voice messages are .ogg
 * @returns {Promise<string>} the transcribed text
 */
async function transcribeAudio(url, filename = "audio.ogg") {
  const audioRes = await fetch(url);
  if (!audioRes.ok) {
    throw new Error(`Couldn't download the audio attachment (HTTP ${audioRes.status}).`);
  }
  const audioBuffer = await audioRes.arrayBuffer();
  return postTranscription(audioBuffer, filename);
}

/**
 * Transcribe audio already in memory (e.g. captured live from a voice
 * channel via @discordjs/voice), skipping the download step entirely.
 * @param {Buffer} buffer - audio bytes (any format Whisper accepts, e.g. WAV)
 * @param {string} [filename]
 * @returns {Promise<string>} the transcribed text
 */
async function transcribeAudioBuffer(buffer, filename = "audio.wav") {
  return postTranscription(buffer, filename);
}

// Shared by askGroq() and translateText(): tries strict JSON mode first,
// and if Groq itself rejects the generation for not being valid JSON
// (a hard 400 json_validate_failed -- happens when the model slips into a
// plain-text refusal/apology instead of the schema), retries once without
// forcing JSON mode. Both callers' parsers already tolerate non-JSON text
// as a fallback, so this just avoids turning a formatting slip into a
// dead reply.
async function callGroqWithJsonFallback(model, messages) {
  try {
    return await callGroq(model, messages, true);
  } catch (err) {
    if (err.groqJsonValidateFailed) {
      console.warn("[Groq] json_object mode rejected the generation — retrying without strict JSON mode...");
      return await callGroq(model, messages, false);
    }
    throw err;
  }
}

// Some Groq models "think" before answering. Without a reasoning setting the
// reasoning text lands in message.content (reasoning_format defaults to "raw"),
// which breaks JSON parsing. Keep it out of the visible output per model family:
//   - Qwen: reasoning_effort "none" disables thinking outright.
//   - gpt-oss / deepseek-r1 / kimi-k2: reasoning_format "hidden".
// Plain non-reasoning models (llama-3.3, etc.) don't accept either param.
function reasoningParams(model) {
  if (/^qwen\//i.test(model))                        return { reasoning_effort: "none" };
  if (/deepseek-r1|gpt-oss|kimi-k2/i.test(model))     return { reasoning_format: "hidden" };
  return {};
}

// Low-level chat completion. `target` is a model string (NaraRouter) or a
// {model, provider: "groq"|"nara", endpoint?, apiKey?} object. Returns the whole
// assistant message (content and/or tool_calls). Errors carry .status / .groqCode /
// .groqJsonValidateFailed so callers can decide whether to retry differently.
// On NaraRouter, optional params (max_tokens, JSON mode, reasoning_effort) are a
// best-effort nudge: a 400 is retried once with none of them.
async function groqRequest(target, messages, { useJsonMode = false, tools = null, toolChoice = undefined } = {}) {
  const t = typeof target === "string" ? { model: target, provider: "nara" } : target;
  const { model } = t;
  const isGroq = t.provider === "groq";
  const label  = isGroq ? "Groq" : "NaraRouter";

  const apiKey = t.apiKey || (isGroq ? process.env.GROQ_API_KEY : process.env.NARAROUTER_API_KEY);
  if (!apiKey) throw new Error(isGroq ? GROQ_KEY_MSG : NARA_KEY_MSG);

  const send = extras => fetch(t.endpoint || (isGroq ? groqEndpoint() : chatEndpoint()), {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
    body: JSON.stringify({
      model,
      messages,
      ...(tools ? { tools, tool_choice: toolChoice || "auto" } : {}),
      ...extras,
    }),
  });

  // JSON mode is never combined with tools; on tool turns the JSON comes from the prompt.
  const jsonMode = useJsonMode && !tools ? { response_format: { type: "json_object" } } : {};
  let extras;
  if (isGroq) {
    extras = {
      // Cap on the reply length (reasoning tokens count too on gpt-oss).
      max_tokens: 500,
      temperature: 0.9,
      ...jsonMode,
      ...reasoningParams(model),
    };
  } else {
    const effort = chatEffort();
    extras = {
      max_tokens: 1500, // headroom for hidden reasoning tokens
      ...jsonMode,
      ...(effort && effort !== "off" ? { reasoning_effort: effort } : {}),
    };
  }

  let res = await send(extras);
  if (!isGroq && res.status === 400) {
    const firstErr = await res.text().catch(() => "");
    console.warn("[NaraRouter] 400 with optional params, retrying plain:", firstErr.slice(0, 200));
    res = await send({});
  }

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    let code;
    try { code = JSON.parse(errText)?.error?.code; } catch { /* not JSON, ignore */ }

    const err = new Error(`${label} API error ${res.status}: ${errText.slice(0, 300)}`);
    err.status = res.status;
    err.groqCode = code;
    err.groqJsonValidateFailed = code === "json_validate_failed";
    throw err;
  }

  const data = await res.json();
  const message = data?.choices?.[0]?.message;
  if (!message) throw new Error(`${label} API returned an empty response.`);
  return message;
}

async function callGroq(model, messages, useJsonMode) {
  const message = await groqRequest(model, messages, { useJsonMode });
  const raw = message.content?.trim();
  if (!raw) throw new Error("The chat API returned an empty response.");
  return raw;
}

// The tool-calling loop for chat turns. Each round: ask the model; if it
// answers with tool_calls, run them, feed the results back, and ask again;
// when it answers with plain content, that's the final JSON reply.
//
// If Groq refuses tools for this model outright (some vision models don't
// support them) or the model produces a malformed tool call
// (tool_use_failed), this degrades to the old tool-less call instead of
// killing the reply -- with a note so the model doesn't pretend it searched.
async function chatWithTools(model, messages, tools, toolCtx) {
  const convo = [...messages];

  for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
    const finalRound = round === MAX_TOOL_ROUNDS;

    let message;
    try {
      message = await groqRequest(model, convo, { tools, toolChoice: finalRound ? "none" : "auto" });
    } catch (err) {
      const toolsRejected = err.status === 400 && (err.groqCode === "tool_use_failed" || /tool/i.test(err.message));
      if (toolsRejected) {
        console.warn(`[Groq] Tool calling failed on round ${round} (${err.groqCode || "rejected"}) — answering without tools:`, err.message.slice(0, 200));
        const plain = [
          ...convo,
          { role: "system", content: "Tools are unavailable for this reply. Answer from what you already know, and don't claim you searched or wrote code." },
        ];
        return callGroqWithJsonFallback(model, plain);
      }
      throw err;
    }

    const calls = message.tool_calls || [];
    if (!calls.length) {
      const raw = message.content?.trim();
      if (!raw) throw new Error("The chat API returned an empty response.");
      return raw;
    }

    convo.push({ role: "assistant", content: message.content || null, tool_calls: calls });
    for (const call of calls) {
      const result = await runNonameTool(call.function?.name, call.function?.arguments, toolCtx);
      convo.push({ role: "tool", tool_call_id: call.id, content: result });
    }
  }

  throw new Error("The chat API kept requesting tools without giving an answer.");
}

// Strips <think> blocks (both closed and cut-off/unclosed) and ```json
// fences that models sometimes wrap their answer in despite instructions.
// Shared cleanup step before either parseAction() or parseTranslation()
// attempts JSON.parse.
function cleanRawText(raw) {
  let text = raw.trim();
  text = text.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
  text = text.replace(/<think>[\s\S]*$/i, "").trim();
  text = text.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "").trim();
  return text;
}

/**
 * Parse + validate the model's raw text into a safe action object.
 * Falls back to treating the raw text as a single plain message if the
 * model didn't actually return valid JSON (models occasionally ignore
 * response_format, especially under load).
 */
function parseAction(raw) {
  const text = cleanRawText(raw);

  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    // Not valid JSON — fall back to a single plain-text message so the
    // conversation doesn't just silently die because of a formatting slip.
    // Use the already-cleaned `text` (not `raw`) so a stripped <think>
    // block doesn't come back in through this path.
    return {
      messages: text
        ? [{ text: text.slice(0, 1900), delay: 0 }]
        : [{ text: "bro my brain glitched, say that again?", delay: 0 }],
      react: null,
      join_voice: false,
      self_action: null,
      __fallbackReason: text ? "invalid_json_used_raw_text" : "invalid_json_empty",
    };
  }

  const rawMessages = Array.isArray(parsed.messages)
    ? parsed.messages
    : (typeof parsed.messages === "string" ? [parsed.messages] : []);

  // Each item is normally { text, delay }, but tolerate the model handing
  // back a bare string instead -- just treat that as a message with no
  // delay rather than dropping it entirely.
  let messages = rawMessages
    .map(m => {
      if (typeof m === "string") return { text: m, delay: 0 };
      if (m && typeof m === "object" && typeof m.text === "string") {
        const delay = Number(m.delay);
        return {
          text: m.text,
          delay: Number.isFinite(delay) ? Math.max(0, Math.min(delay, MAX_MESSAGE_DELAY_SECONDS)) : 0,
        };
      }
      return null;
    })
    .filter(m => m && m.text.trim().length)
    .map(m => ({ text: m.text.trim().slice(0, 1900), delay: m.delay }))
    .slice(0, MAX_REPLY_MESSAGES);

  let fallbackReason = null;
  if (!messages.length) {
    messages = [{ text: "bro idk what to say to that ngl", delay: 0 }];
    fallbackReason = "valid_json_but_no_usable_messages_field";
  }

  let react = typeof parsed.react === "string" ? parsed.react.trim() : null;
  // Sanity check — a real emoji (even multi-codepoint ones like 🏳️‍🌈) is
  // short; anything long is the model putting a word/sentence there instead.
  if (!react || react.length > 8 || /^(null|none|n\/a)$/i.test(react)) react = null;

  const join_voice = parsed.join_voice === true;

  // self_action can only ever be null, an edit with real replacement text,
  // or a delete -- anything malformed collapses to null (no-op) rather than
  // risking an unintended edit/delete. There's no message ID field here at
  // all: the model can only say "edit/delete my last message", and the
  // caller (index.js) resolves that against the single message ID it
  // tracks as noname's own last send in that channel. That's what keeps
  // this "bot side only" -- there is no code path from a Groq response to
  // touching anyone else's message.
  let self_action = null;
  if (parsed.self_action && typeof parsed.self_action === "object") {
    if (parsed.self_action.type === "delete") {
      self_action = { type: "delete" };
    } else if (parsed.self_action.type === "edit" && typeof parsed.self_action.new_text === "string" && parsed.self_action.new_text.trim()) {
      self_action = { type: "edit", new_text: parsed.self_action.new_text.trim().slice(0, 1900) };
    }
  }

  return { messages, react, join_voice, self_action, __fallbackReason: fallbackReason };
}

// ─── Translation ────────────────────────────────────────────────────────────
const TRANSLATE_SYSTEM_PROMPT = `
You are a precise translation engine embedded in a Discord bot. You will be given a short piece of text in any language, including possibly English.
1. Detect the source language.
2. Translate it into natural, fluent English.
Reply with ONLY a single raw JSON object — no markdown, no code fences, no text before or after it. It must match exactly this shape:
{
  "detected_language": "Japanese",
  "translation": "Hello, how are you?"
}
Rules:
- "detected_language": the common English name of the source language (e.g. "Spanish", "Korean", "French"). If the input is already in English, use "English".
- "translation": a natural, fluent English translation. If the input is already in English, put the original text here (lightly cleaned up, not rewritten).
- Preserve tone and meaning as closely as natural English allows. Don't add commentary, notes, or explanations of the translation choices.
- Never output anything outside that one JSON object.
`.trim();

/**
 * Detect the language of a piece of text and translate it to English.
 * @param {string} text
 * @returns {Promise<{detected_language: string, translation: string}>}
 */
// ─── Image prompt moderation ───────────────────────────────────────────────
// Used by utils/imagegen.js as a check BEFORE a prompt is ever handed to the
// image model. Runs as a plain chat completion (not the noname persona/
// action schema above) with its own tiny system prompt, asking the model to
// judge the prompt's intent rather than pattern-match keywords -- catches
// slang, misspellings, and "describe it without saying the word" phrasing
// that a keyword list will always miss.
// Deliberately a small, fast, non-reasoning model: this runs on every single
// /imagine call and only needs to return one word's worth of judgment, not
// think it through.
const moderationModel = () => ({ model: process.env.GROQ_MODERATION_MODEL || "openai/gpt-oss-safeguard-20b", provider: "groq" });

const MODERATION_SYSTEM_PROMPT = `
Safety filter for an image-gen Discord command. Judge the prompt's real intent, not just its wording -- catch misspellings, slang, and "artistic/educational" framing used to smuggle in a blocked request.
Block: sexual/nude/suggestive content; any sexualization of a minor (zero exceptions, no framing excuses it); real people shown nude/sexual/defamed/deepfaked; harassment of a private person; gore/torture/extreme violence for shock value; hate symbols/extremist glorification; weapon/explosive build instructions; suicide/self-harm depiction or glorification; illegal drug making/glamorizing; animal cruelty; scatological/bodily-waste content (feces, defecating, vomit, urine, etc.), All words that contains "sus","butt".
Allow: crude/edgy non-scatological humor, ordinary fictional violence (movies/games/war), satire of public figures, normal non-sexual depictions of public figures. When unsure, allow.
Raw JSON only: { "allowed": true, "reason": "short reason", "category": "none" }
"category": "none" if allowed, else the block-type it matches (e.g. "sexual", "minor", "gore", "weapons", "scatological").
`.trim();

/**
 * Asks Groq to judge whether an /imagine prompt is safe to actually render.
 * Fails CLOSED (treated as blocked) on any error or unparseable response --
 * for a safety check, "couldn't confirm it's safe" must mean "don't
 * generate it", not "generate it anyway".
 * @returns {Promise<{allowed: boolean, reason: string}>}
 */
async function moderateImagePrompt(prompt) {
  const messages = [
    { role: "system", content: MODERATION_SYSTEM_PROMPT },
    { role: "user", content: prompt },
  ];

  let raw;
  try {
    raw = await callGroqWithJsonFallback(moderationModel(), messages);
  } catch (err) {
    console.warn("[Groq] Image prompt moderation call failed, failing closed:", err.message);
    return { allowed: false, reason: "moderation check failed" };
  }

  try {
    const parsed = JSON.parse(cleanRawText(raw));
    if (typeof parsed.allowed !== "boolean") throw new Error("missing/invalid 'allowed' field");
    return {
      allowed:  parsed.allowed,
      reason:   String(parsed.reason || "").slice(0, 200),
      category: String(parsed.category || "none").slice(0, 20),
    };
  } catch (err) {
    console.warn("[Groq] Image prompt moderation returned unparseable output, failing closed:", raw?.slice(0, 200));
    return { allowed: false, reason: "moderation response was unparseable" };
  }
}

async function translateText(text) {
  const messages = [
    { role: "system", content: TRANSLATE_SYSTEM_PROMPT },
    { role: "user", content: text },
  ];

  const raw = await callGroqWithJsonFallback(chatModel(), messages);
  return parseTranslation(raw, text);
}

function parseTranslation(raw, originalText) {
  const text = cleanRawText(raw);

  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    // Model didn't return JSON -- treat its raw output as the translation
    // rather than failing the command outright.
    return { detected_language: "Unknown", translation: text || originalText };
  }

  const detected_language = typeof parsed.detected_language === "string" && parsed.detected_language.trim()
    ? parsed.detected_language.trim().slice(0, 100)
    : "Unknown";

  const translation = typeof parsed.translation === "string" && parsed.translation.trim()
    ? parsed.translation.trim()
    : originalText;

  return { detected_language, translation };
}

// ─── Live health check ─────────────────────────────────────────────────────
// Groq doesn't expose a "/v1/logs" endpoint for regular API keys (there's
// no way to pull historical request logs back out of the API itself) --
// what it does expose is GET /v1/models, which requires a valid key to
// respond at all. /apilogs uses this as an actual live ping: hit it, log
// the round-trip via withApiLog same as every other call, and report
// success + how many models came back + latency, instead of only ever
// showing the passive log of calls the bot happened to make on its own.
async function listModels() {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) throw new Error(GROQ_KEY_MSG);

  const res = await fetch(`${(process.env.GROQ_BASE_URL || "https://api.groq.com/openai/v1").replace(/\/+$/, "")}/models`, {
    headers: { "Authorization": `Bearer ${apiKey}` },
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`Groq models error ${res.status}: ${errText.slice(0, 300)}`);
  }

  const data = await res.json();
  return Array.isArray(data?.data) ? data.data : [];
}

module.exports = {
  askGroq:              withApiLog("Groq", "chat completion", askGroq, ({ prompt } = {}) => prompt?.slice(0, 60)),
  translateText:        withApiLog("Groq", "translate", translateText, t => t?.slice(0, 60)),
  transcribeAudio:      withApiLog("Groq", "transcribe (url)", transcribeAudio, (url, filename) => filename),
  transcribeAudioBuffer: withApiLog("Groq", "transcribe (buffer)", transcribeAudioBuffer, (buf, filename) => filename),
  listModels:           withApiLog("Groq", "list models", listModels),
  moderateImagePrompt:  withApiLog("Groq", "moderate image prompt", moderateImagePrompt, p => p?.slice(0, 60)),
};