"use strict";

const { withApiLog } = require("./apiLogger");
const { moderateImagePrompt } = require("./groq");

// Nano Banana 2 (Gemini's flash image model) has been replaced below with
// Pollinations.ai -- a free, no-API-key image generation endpoint. See the
// "Pollinations.ai image generation" comment further down for details.

// ─── Safety net ─────────────────────────────────────────────────────────────
// Three layers now, each catching what the one before it misses:
//   1. Local keyword check -- cheap, instant, zero network call. Hard-stops
//      the worst case (minor + sexual) regardless of what the LLM layer
//      below decides, and also hard-blocks scatological content outright --
//      the small moderation model was letting a lot of these through
//      ("shitting", "pooping", etc. in many phrasings), so this doesn't rely
//      on it judging intent for this category at all.
//   2. Groq prompt moderation (moderateImagePrompt, utils/groq.js) -- an
//      actual model reads the prompt for INTENT rather than pattern-
//      matching words. This is the layer that exists specifically because
//      the old keyword-only version got bypassed with plain slang the list
//      didn't happen to contain -- a word list can always be routed around
//      by using a different word for the same thing; a model judging intent
//      is much harder to route around that way.
//   3. Pollinations' own server-side safety filtering at generation time --
//      final backstop, catches things even if 1 and 2 both somehow missed it.
// None of these are a substitute for actually moderating what your server
// lets people generate with /imagine -- restrict the command to an
// NSFW-flagged channel (or off entirely) if that matters to you.
const MINOR_TERMS  = /\b(child|kid|kids|minor|toddler|infant|schoolgirl|schoolboy|teen|teenage|underage|loli|shota)\b/i;
const SEXUAL_TERMS = /\b(nude|naked|nsfw|porn|sex|sexy|erotic|fetish|hentai)\b/i;

// Scatological/bodily-waste terms -- blocked outright, not paired with
// anything else. Covers the common word plus its -ing/-ed/plural forms
// (e.g. "shit", "shitting", "shits") without needing a separate entry per
// form. Extend this list directly if more slang keeps slipping through --
// it's a flat list on purpose so adding a new word is a one-line change.
const SCATOLOGICAL_TERMS = /\b(shit(?:s|ting|ted)?|crap(?:s|ping|ped)?|poop(?:s|ing|ed)?|defecat(?:e|es|ing|ed)|feces|faeces|dung|turds?|diarrh(?:o|e)a|vomit(?:s|ing|ed)?|puke[sd]?|piss(?:es|ing|ed)?|urinat(?:e|es|ing|ed))\b/i;

function isBlocked(prompt) {
  if (SCATOLOGICAL_TERMS.test(prompt)) return true;
  return MINOR_TERMS.test(prompt) && SEXUAL_TERMS.test(prompt);
}

// Pollinations.ai image generation. Free, no signup or API key required on
// the anonymous tier -- this is the "imagegen endpoint" people mean when
// they say Pollinations is a free image API.
//   - Anonymous tier: rate-limited to ~1 request per 15s and may add a small
//     watermark.
//   - Registering for a free token at https://auth.pollinations.ai removes
//     both the rate limit and the watermark -- set POLLINATIONS_TOKEN if you
//     get one, otherwise it just runs anonymously.
// Unlike Gemini, this is a plain GET that returns the image bytes directly --
// there's no structured "blocked" response, just an HTTP error or a
// non-image response if something goes wrong.
const IMAGE_ENDPOINT = "https://image.pollinations.ai/prompt";

// Discord-friendly aspect ratios mapped to concrete pixel sizes (Pollinations
// takes width/height, not a ratio string).
const ASPECT_SIZES = {
  "1:1":   { width: 1024, height: 1024 },
  "3:4":   { width: 896,  height: 1152 },
  "4:3":   { width: 1152, height: 896 },
  "16:9":  { width: 1344, height: 768 },
};

async function generateImageRaw(prompt, { aspectRatio = "1:1", model } = {}) {
  const { width, height } = ASPECT_SIZES[aspectRatio] || ASPECT_SIZES["1:1"];

  const params = new URLSearchParams({
    width:  String(width),
    height: String(height),
    model:  model || "flux",
    nologo: "true",
    // Pollinations caches responses by URL -- same prompt + same
    // width/height/model always returns the exact same image bytes with
    // no seed. A fresh random seed on every call is what actually makes
    // each /imagine invocation generate a new image instead of replaying
    // a cached one (including across different users with similar prompts).
    seed: String(Math.floor(Math.random() * 1_000_000_000)),
  });
  const token = process.env.POLLINATIONS_TOKEN;
  if (token) params.set("token", token);

  const url = `${IMAGE_ENDPOINT}/${encodeURIComponent(prompt)}?${params.toString()}`;
  const res = await fetch(url);

  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try {
      const body = await res.text();
      if (body) msg = body.slice(0, 200);
    } catch { /* ignore -- keep the HTTP status message */ }
    // Pollinations returns 4xx text (not JSON) for content-policy refusals,
    // so surface those through the same BLOCKED_BY_API path imagine.js
    // already handles.
    if (res.status === 400 || res.status === 403) {
      throw new Error(`BLOCKED_BY_API: ${msg}`);
    }
    throw new Error(`Pollinations API error: ${msg}`);
  }

  const contentType = res.headers.get("content-type") || "image/jpeg";
  if (!contentType.startsWith("image/")) {
    throw new Error(`No image returned (got content-type: ${contentType})`);
  }

  const buffer = Buffer.from(await res.arrayBuffer());
  return { buffer, contentType };
}

/**
 * Generates an image from a text prompt.
 * @returns {Promise<{buffer: Buffer, contentType: string}>}
 * @throws {Error} "BLOCKED_PROMPT" (local keyword filter),
 *   "BLOCKED_BY_MODERATION: <reason>" (Groq judged the prompt unsafe),
 *   or "BLOCKED_BY_API: <reason>" (Pollinations itself refused at generation time).
 */
const generateImage = withApiLog(
  "Pollinations",
  "generate image",
  async (prompt, opts) => {
    if (isBlocked(prompt)) {
      throw new Error("BLOCKED_PROMPT");
    }

    const verdict = await moderateImagePrompt(prompt);
    if (!verdict.allowed) {
      throw new Error(`BLOCKED_BY_MODERATION: ${verdict.reason}`);
    }

    return generateImageRaw(prompt, opts);
  },
  prompt => prompt.slice(0, 60),
);

module.exports = { generateImage };