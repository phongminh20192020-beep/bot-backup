"use strict";

// Uses Google Translate's public "gtx" client endpoint -- the same one the
// Google Translate website itself calls under the hood. It's unofficial
// (no SLA, could theoretically change or rate-limit), but it's completely
// free: no API key, no Google Cloud billing account, no quota to burn.
// This is the same endpoint countless open-source translate libraries
// (google-translate-api, etc.) wrap.
const ENDPOINT = "https://translate.googleapis.com/translate_a/single";

// Common ISO 639-1 codes -> human-readable names, for a nicer embed than
// showing raw codes like "ja" or "pt". Falls back to the raw code for
// anything not in this list rather than failing.
const LANGUAGE_NAMES = {
  af: "Afrikaans", sq: "Albanian", am: "Amharic", ar: "Arabic", hy: "Armenian",
  az: "Azerbaijani", eu: "Basque", be: "Belarusian", bn: "Bengali", bs: "Bosnian",
  bg: "Bulgarian", ca: "Catalan", ceb: "Cebuano", ny: "Chichewa",
  "zh-cn": "Chinese (Simplified)", "zh-tw": "Chinese (Traditional)", zh: "Chinese",
  co: "Corsican", hr: "Croatian", cs: "Czech", da: "Danish", nl: "Dutch",
  en: "English", eo: "Esperanto", et: "Estonian", tl: "Filipino", fi: "Finnish",
  fr: "French", fy: "Frisian", gl: "Galician", ka: "Georgian", de: "German",
  el: "Greek", gu: "Gujarati", ht: "Haitian Creole", ha: "Hausa", haw: "Hawaiian",
  he: "Hebrew", iw: "Hebrew", hi: "Hindi", hmn: "Hmong", hu: "Hungarian",
  is: "Icelandic", ig: "Igbo", id: "Indonesian", ga: "Irish", it: "Italian",
  ja: "Japanese", jw: "Javanese", kn: "Kannada", kk: "Kazakh", km: "Khmer",
  ko: "Korean", ku: "Kurdish", ky: "Kyrgyz", lo: "Lao", la: "Latin",
  lv: "Latvian", lt: "Lithuanian", lb: "Luxembourgish", mk: "Macedonian",
  mg: "Malagasy", ms: "Malay", ml: "Malayalam", mt: "Maltese", mi: "Maori",
  mr: "Marathi", mn: "Mongolian", my: "Myanmar (Burmese)", ne: "Nepali",
  no: "Norwegian", or: "Odia", ps: "Pashto", fa: "Persian", pl: "Polish",
  pt: "Portuguese", pa: "Punjabi", ro: "Romanian", ru: "Russian", sm: "Samoan",
  gd: "Scots Gaelic", sr: "Serbian", st: "Sesotho", sn: "Shona", sd: "Sindhi",
  si: "Sinhala", sk: "Slovak", sl: "Slovenian", so: "Somali", es: "Spanish",
  su: "Sundanese", sw: "Swahili", sv: "Swedish", tg: "Tajik", ta: "Tamil",
  tt: "Tatar", te: "Telugu", th: "Thai", tr: "Turkish", tk: "Turkmen",
  uk: "Ukrainian", ur: "Urdu", ug: "Uyghur", uz: "Uzbek", vi: "Vietnamese",
  cy: "Welsh", xh: "Xhosa", yi: "Yiddish", yo: "Yoruba", zu: "Zulu",
};

function languageName(code) {
  if (!code) return "Unknown";
  return LANGUAGE_NAMES[code.toLowerCase()] || code;
}

/**
 * Detect the language of a piece of text and translate it to English, via
 * Google Translate's free public endpoint -- no API key, no credits used.
 * @param {string} text
 * @returns {Promise<{detected_language: string, translation: string}>}
 */
async function translateText(text) {
  const trimmed = (text || "").trim();
  if (!trimmed) return { detected_language: "Unknown", translation: "" };

  const params = new URLSearchParams({
    client: "gtx",
    sl: "auto",   // auto-detect source language
    tl: "en",     // always translate to English
    dt: "t",      // return translated text
  });
  // Google's own frontend URL-encodes q separately and expects it appended,
  // not passed through URLSearchParams (which double-encodes some chars in
  // a way that occasionally trips the endpoint up) -- build it by hand.
  const url = `${ENDPOINT}?${params.toString()}&q=${encodeURIComponent(trimmed)}`;

  let res;
  try {
    res = await fetch(url);
  } catch (err) {
    throw new Error(`Google Translate request failed: ${err.message}`);
  }

  if (!res.ok) {
    throw new Error(`Google Translate error ${res.status}: ${res.statusText}`);
  }

  let data;
  try {
    data = await res.json();
  } catch (err) {
    throw new Error(`Google Translate returned unexpected data: ${err.message}`);
  }

  // Response shape (undocumented, but stable): data[0] is an array of
  // [translatedChunk, originalChunk, ...] pairs covering the whole input
  // (long text gets split into multiple chunks); data[2] is the detected
  // source language code.
  const segments = Array.isArray(data?.[0]) ? data[0] : [];
  const translation = segments.map(seg => seg?.[0] ?? "").join("").trim();
  const detectedCode = typeof data?.[2] === "string" ? data[2] : null;

  if (!translation) {
    throw new Error("Google Translate returned an empty translation.");
  }

  return {
    detected_language: languageName(detectedCode),
    translation,
  };
}

module.exports = { translateText };
