"use strict";

// Small shared drawing helpers for the hand-sketched-doodle look used
// across this project's canvas renderers (tictactoe/wordle/minesweeper,
// and now the casino games).

const INK = "#1b1b1f";
const BG  = "#ffffff";

/** A slightly wobbly line between two points, for a hand-drawn feel. */
function wobblyLine(ctx, x1, y1, x2, y2, bow = 3) {
  const mx = (x1 + x2) / 2 + bow;
  const my = (y1 + y2) / 2 - bow;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(mx, my, x2, y2);
  ctx.stroke();
}

function roundedRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  if (typeof ctx.roundRect === "function") ctx.roundRect(x, y, w, h, r);
  else ctx.rect(x, y, w, h);
}

function drawHeart(ctx, cx, cy, size, filled, color) {
  const top = size * 0.3;
  ctx.beginPath();
  ctx.moveTo(cx, cy + top);
  ctx.bezierCurveTo(cx, cy, cx - size / 2, cy, cx - size / 2, cy + top);
  ctx.bezierCurveTo(cx - size / 2, cy + (size + top) / 2, cx, cy + (size + top) / 2, cx, cy + size);
  ctx.bezierCurveTo(cx, cy + (size + top) / 2, cx + size / 2, cy + (size + top) / 2, cx + size / 2, cy + top);
  ctx.bezierCurveTo(cx + size / 2, cy, cx, cy, cx, cy + top);
  ctx.closePath();
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.stroke();
  if (filled) { ctx.fillStyle = color; ctx.fill(); }
}

/** Diamond (♦) shape, vector -- avoids relying on an emoji/suit glyph font. */
function drawDiamond(ctx, cx, cy, w, h, color) {
  ctx.beginPath();
  ctx.moveTo(cx, cy - h / 2);
  ctx.lineTo(cx + w / 2, cy);
  ctx.lineTo(cx, cy + h / 2);
  ctx.lineTo(cx - w / 2, cy);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.strokeStyle = INK;
  ctx.lineWidth = 1.5;
  ctx.stroke();
}

/** Spade (♠) shape, vector. */
function drawSpade(ctx, cx, cy, size, color) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath();
  ctx.moveTo(0, -size * 0.55);
  ctx.bezierCurveTo(size * 0.55, -size * 0.05, size * 0.5, size * 0.35, 0, size * 0.15);
  ctx.bezierCurveTo(-size * 0.5, size * 0.35, -size * 0.55, -size * 0.05, 0, -size * 0.55);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.fillRect(-size * 0.06, size * 0.1, size * 0.12, size * 0.32);
  ctx.beginPath();
  ctx.moveTo(-size * 0.22, size * 0.42);
  ctx.lineTo(size * 0.22, size * 0.42);
  ctx.lineTo(0, size * 0.22);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/** Club (♣) shape, vector. */
function drawClub(ctx, cx, cy, size, color) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.fillStyle = color;
  for (const [dx, dy] of [[0, -size * 0.32], [-size * 0.3, size * 0.05], [size * 0.3, size * 0.05]]) {
    ctx.beginPath();
    ctx.arc(dx, dy, size * 0.28, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillRect(-size * 0.06, size * 0.05, size * 0.12, size * 0.4);
  ctx.beginPath();
  ctx.moveTo(-size * 0.22, size * 0.45);
  ctx.lineTo(size * 0.22, size * 0.45);
  ctx.lineTo(0, size * 0.25);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/** Draws whichever suit symbol matches `suit` ("♠"|"♥"|"♦"|"♣"). */
function drawSuit(ctx, suit, cx, cy, size, color) {
  if (suit === "♥") return drawHeart(ctx, cx, cy - size * 0.4, size * 0.8, true, color);
  if (suit === "♦") return drawDiamond(ctx, cx, cy, size * 0.7, size, color);
  if (suit === "♠") return drawSpade(ctx, cx, cy, size, color);
  return drawClub(ctx, cx, cy, size, color);
}

/** A single six-sided die face with pips. */
function drawDie(ctx, x, y, size, value) {
  roundedRectPath(ctx, x, y, size, size, size * 0.16);
  ctx.fillStyle = BG;
  ctx.fill();
  ctx.strokeStyle = INK;
  ctx.lineWidth = 2.5;
  ctx.stroke();

  const pip = size * 0.09;
  const c = size / 2;
  const off = size * 0.26;
  const positions = {
    1: [[c, c]],
    2: [[c - off, c - off], [c + off, c + off]],
    3: [[c - off, c - off], [c, c], [c + off, c + off]],
    4: [[c - off, c - off], [c + off, c - off], [c - off, c + off], [c + off, c + off]],
    5: [[c - off, c - off], [c + off, c - off], [c, c], [c - off, c + off], [c + off, c + off]],
    6: [[c - off, c - off], [c + off, c - off], [c - off, c], [c + off, c], [c - off, c + off], [c + off, c + off]],
  }[value] || [];

  ctx.fillStyle = INK;
  for (const [px, py] of positions) {
    ctx.beginPath();
    ctx.arc(x + px, y + py, pip, 0, Math.PI * 2);
    ctx.fill();
  }
}

module.exports = { INK, BG, wobblyLine, roundedRectPath, drawHeart, drawDiamond, drawSpade, drawClub, drawSuit, drawDie };
