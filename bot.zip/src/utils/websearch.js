"use strict";

const { withApiLog } = require("./apiLogger");

// ─── SerpApi (DuckDuckGo results, via a proper API) ─────────────────────────
// Uses SerpApi's DuckDuckGo Search endpoint (engine=duckduckgo).
// Setup:
//   1. Sign up at https://serpapi.com/ and grab your key from
//      https://serpapi.com/manage-api-key
//   2. Set SERPAPI_KEY in the environment.
const SEARCH_ENDPOINT = "https://serpapi.com/search.json";
const MAX_RESULTS = 10;

async function searchGoogleRaw(query, count = 5) {
  const apiKey = process.env.SERPAPI_KEY;
  if (!apiKey) {
    throw new Error("SERPAPI_KEY is not configured");
  }

  const params = new URLSearchParams({
    engine:  "duckduckgo",
    q:       query,
    kl:      "tr-tr", // DuckDuckGo region; use "wt-wt" for no region
    api_key: apiKey,
  });

  const res = await fetch(`${SEARCH_ENDPOINT}?${params.toString()}`);
  const data = await res.json();

  if (!res.ok || data.error) {
    const msg = data?.error || `HTTP ${res.status}`;
    throw new Error(`SerpApi error: ${msg}`);
  }

  const limit = Math.min(Math.max(count, 1), MAX_RESULTS);
  return (data.organic_results || []).slice(0, limit).map(item => ({
    title:   item.title || "",
    link:    item.link || "",
    snippet: item.snippet || "",
  }));
}

/**
 * Searches DuckDuckGo via SerpApi.
 * @param {string} query
 * @param {number} [count=5] - how many results to return (max 10)
 * @returns {Promise<{title: string, link: string, snippet: string}[]>}
 */
const searchGoogle = withApiLog(
  "GoogleSearch",
  "search",
  searchGoogleRaw,
  (query, count) => query?.slice(0, 60),
);

// ─── SerpApi Google Images ──────────────────────────────────────────────────
// Same API key/setup as the text search above (SERPAPI_KEY) -- SerpApi's
// google_images engine returns direct, hotlinkable image URLs. That's the
// part that actually matters here: the noname persona sends its replies as
// plain message text (see handleImageSearch in index.js), and Discord
// auto-embeds any raw image URL that appears in a message -- so there's no
// need for an attachment or embed builder, just a URL string in the text.
async function searchGoogleImagesRaw(query, count = 5) {
  const apiKey = process.env.SERPAPI_KEY;
  if (!apiKey) {
    throw new Error("SERPAPI_KEY is not configured");
  }

  const params = new URLSearchParams({
    engine:  "google_images",
    q:       query,
    api_key: apiKey,
  });

  const res = await fetch(`${SEARCH_ENDPOINT}?${params.toString()}`);
  const data = await res.json();

  if (!res.ok || data.error) {
    const msg = data?.error || `HTTP ${res.status}`;
    throw new Error(`SerpApi error: ${msg}`);
  }

  return (data.images_results || [])
    .filter(item => item.original) // occasionally missing on a handful of results; skip those rather than send a broken link
    .slice(0, Math.min(Math.max(count, 1), MAX_RESULTS))
    .map(item => ({
      title:     item.title || "",
      imageUrl:  item.original,
      sourceUrl: item.link || "",
    }));
}

/**
 * Searches Google Images via SerpApi.
 * @param {string} query
 * @param {number} [count=5] - how many results to return (max 10)
 * @returns {Promise<{title: string, imageUrl: string, sourceUrl: string}[]>}
 */
const searchGoogleImages = withApiLog(
  "GoogleImageSearch",
  "search",
  searchGoogleImagesRaw,
  (query, count) => query?.slice(0, 60),
);

// ─── SerpApi Google Lens (reverse image search) ─────────────────────────────
// Takes an image URL IN (a Discord CDN link works fine, it's publicly
// fetchable) and returns what Google Lens thinks it's looking at -- visual
// matches (similar/identical images elsewhere on the web, with their source
// pages) plus a "knowledge graph" entry when Lens can confidently identify
// the specific subject (e.g. a landmark, a piece of art, a species). This is
// the "what/where is this picture" tool -- the opposite direction from
// searchGoogleImages above, which goes text query -> new image.
async function searchImageContentRaw(imageUrl, count = 5) {
  const apiKey = process.env.SERPAPI_KEY;
  if (!apiKey) {
    throw new Error("SERPAPI_KEY is not configured");
  }

  const params = new URLSearchParams({
    engine:  "google_lens",
    url:     imageUrl,
    api_key: apiKey,
  });

  const res = await fetch(`${SEARCH_ENDPOINT}?${params.toString()}`);
  const data = await res.json();

  if (!res.ok || data.error) {
    const msg = data?.error || `HTTP ${res.status}`;
    throw new Error(`SerpApi error: ${msg}`);
  }

  const knowledgeGraph = data.knowledge_graph
    ? { title: data.knowledge_graph.title || "", description: data.knowledge_graph.description || "" }
    : null;

  const visualMatches = (data.visual_matches || [])
    .slice(0, Math.min(Math.max(count, 1), MAX_RESULTS))
    .map(item => ({
      title:     item.title || "",
      sourceUrl: item.link || "",
    }));

  return { knowledgeGraph, visualMatches };
}

/**
 * Reverse image search via SerpApi's Google Lens engine.
 * @param {string} imageUrl - a publicly fetchable image URL (e.g. a Discord CDN link)
 * @param {number} [count=5] - how many visual matches to return (max 10)
 * @returns {Promise<{knowledgeGraph: {title: string, description: string}|null, visualMatches: {title: string, sourceUrl: string}[]}>}
 */
const searchImageContent = withApiLog(
  "GoogleLens",
  "reverse image search",
  searchImageContentRaw,
  imageUrl => imageUrl?.slice(0, 60),
);

module.exports = { searchGoogle, searchGoogleImages, searchImageContent };
