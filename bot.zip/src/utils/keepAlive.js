"use strict";

// Sends a periodic "wake-up" ping to the dashboard's own health-check
// endpoint (see /api/health in src/dashboard/server.js). This keeps the
// process actively doing something on an interval, which is useful on
// hosts that spin down/idle a service after a period of no activity --
// and it doubles as a lightweight liveness log for the dashboard's HTTP
// server without needing any external uptime service.
//
// This module only pings and logs; it doesn't restart or touch anything
// else. If the ping fails a few times in a row, that's worth noticing in
// the logs, but this deliberately does not take any corrective action.

const PING_INTERVAL_MS = 10 * 60 * 1000; // 10 minutes

function startKeepAlive({ port } = {}) {
  const resolvedPort = port || process.env.PORT || process.env.SERVER_PORT || process.env.DASHBOARD_PORT || 3000;
  const url = `http://127.0.0.1:${resolvedPort}/api/health`;

  let consecutiveFailures = 0;

  async function ping() {
    try {
      const res = await fetch(url);
      if (res.ok) {
        consecutiveFailures = 0;
        const mem = process.memoryUsage();
        const mb = n => (n / 1024 / 1024).toFixed(1);
        console.log(
          `[KeepAlive] Wake-up ping to dashboard OK (${res.status}). ` +
          `Mem: rss=${mb(mem.rss)}MB heap=${mb(mem.heapUsed)}/${mb(mem.heapTotal)}MB ` +
          `external=${mb(mem.external)}MB uptime=${(process.uptime() / 3600).toFixed(2)}h`
        );
      } else {
        consecutiveFailures++;
        console.warn(`[KeepAlive] Wake-up ping to dashboard returned ${res.status} (${consecutiveFailures} in a row).`);
      }
    } catch (e) {
      consecutiveFailures++;
      console.warn(`[KeepAlive] Wake-up ping to dashboard failed: ${e.message} (${consecutiveFailures} in a row).`);
    }
  }

  console.log(`[KeepAlive] Will ping the dashboard at ${url} every ${PING_INTERVAL_MS / 60000} minutes.`);

  const timer = setInterval(ping, PING_INTERVAL_MS);
  timer.unref(); // a pending interval alone shouldn't keep the process alive

  return () => clearInterval(timer);
}

module.exports = { startKeepAlive };
