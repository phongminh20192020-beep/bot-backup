"""
open_chrome.py — launches Google Chrome every time it runs, and can install
itself into the Windows Startup folder so Chrome opens automatically at logon.

Usage (run from a terminal):
    python open_chrome.py              -> open Chrome right now
    python open_chrome.py --install   -> run automatically at every startup
    python open_chrome.py --remove    -> undo the --install

Change the URL below (or set it to None for a blank window).
"""

import os
import subprocess
import sys
from pathlib import Path

# Page to open when Chrome starts. Set to None to open a blank Chrome window.
URL = "https://www.google.com"


def chrome_exe():
    """Return the path to chrome.exe, or None if it isn't in the usual spots."""
    candidates = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
        / r"Google\Chrome\Application\chrome.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"))
        / r"Google\Chrome\Application\chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", ""))
        / r"Google\Chrome\Application\chrome.exe",
    ]
    for path in candidates:
        if path.is_file():
            return path
    return None


def open_chrome():
    """Launch Chrome (falls back to the default browser if Chrome isn't found)."""
    exe = chrome_exe()
    if exe:
        args = [str(exe)]
        if URL:
            args.append(URL)
        subprocess.Popen(args)
        print(f"Chrome launched from: {exe}")
    else:
        import webbrowser

        webbrowser.open(URL or "https://www.google.com")
        print("Chrome wasn't found in the usual install locations, "
              "so your default browser was opened instead.")


def startup_bat_path():
    """Full path of the launcher we drop into the user's Startup folder."""
    startup_dir = (
        Path(os.environ["APPDATA"])
        / r"Microsoft\Windows\Start Menu\Programs\Startup"
    )
    return startup_dir / "open_chrome_startup.bat"


def python_quiet():
    """Prefer pythonw.exe (no console window) if available."""
    exe = Path(sys.executable)
    pythonw = exe.with_name("pythonw.exe")
    return str(pythonw) if pythonw.is_file() else str(exe)


def install():
    """Create a small .bat in the Startup folder that runs this script."""
    if os.name != "nt":
        print("--install is Windows-only. On macOS/Linux, add this script to "
              "your desktop environment's autostart settings instead.")
        return
    bat = startup_bat_path()
    script = Path(__file__).resolve()
    bat.parent.mkdir(parents=True, exist_ok=True)
    bat.write_text(
        f'@echo off\r\nstart "" "{python_quiet()}" "{script}"\r\n',
        encoding="utf-8",
    )
    print("Done! Chrome will now open automatically every time you log in.")
    print(f"Startup launcher created at:\n  {bat}")


def remove():
    """Delete the Startup launcher created by --install."""
    if os.name != "nt":
        print("--remove is Windows-only.")
        return
    bat = startup_bat_path()
    if bat.exists():
        bat.unlink()
        print("Removed. Chrome will no longer open at startup.")
    else:
        print("Nothing to remove — the startup launcher doesn't exist.")


if __name__ == "__main__":
    if "--install" in sys.argv:
        install()
    elif "--remove" in sys.argv:
        remove()
    else:
        open_chrome()

# dakshu is boykisser