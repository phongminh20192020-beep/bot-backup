# Discord Bot — Moderation + Lavalink Music + Spotify Search

## Requirements
- Python 3.10+
- A running [Lavalink v3 server](https://github.com/lavalink-devs/Lavalink) (default `localhost:2333`, password `youshallnotpass`)
- Spotify app credentials ([developer dashboard](https://developer.spotify.com/dashboard)) — any app works with Client Credentials flow

```bash
pip install -U discord.py lavalink spotipy
```

## Setup
1. In `main.py`: replace `YOUR_BOT_TOKEN`.
2. In `cogs/music.py`: set `SPOTIFY_CLIENT_ID` / `SPOTIFY_CLIENT_SECRET`, and adjust the Lavalink node host/port/password/region to match your server.
3. Enable **Message Content** + **Server Members** intents in the Discord Developer Portal.
4. Run the Lavalink server, then:

```bash
python main.py
```

## Commands

### Moderation (prefix `!`)
- `!kick @user [reason]`, `!ban @user [reason]`, `!unban user_id`
- `!timeout @user minutes`, `!untimeout @user`
- `!purge count`, `!warn @user reason`, `!slowmode seconds`

### Music
- `!play <query | YouTube URL | Spotify track/album/playlist URL>` — Spotify links are resolved track-by-track and matched on YouTube via Lavalink
- `!skip`, `!stop`, `!pause`, `!resume`, `!nowplaying`, `!queue`, `!volume 0-100`

## Notes
- Spotify itself does not allow streaming playback for bots, so Spotify URLs are converted into metadata searches (title + artists) that are then loaded from YouTube through Lavalink — the standard approach.
- The queue-end hook disconnects the bot automatically when the queue finishes.
