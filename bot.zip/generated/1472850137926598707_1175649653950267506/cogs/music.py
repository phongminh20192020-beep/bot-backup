import re

import lavalink
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
from discord.ext import commands
import discord

url_rx = re.compile(r"https?://(?:www\.)?.+")


class LavalinkVoiceClient(discord.VoiceProtocol):
    """discord.py-compatible voice client that forwards state to Lavalink."""

    def __init__(self, client: discord.Client, channel: discord.abc.Connectable):
        self.client = client
        self.channel = channel
        self.lavalink = client.lavalink

    async def on_voice_server_update(self, data):
        await self.lavalink.voice_update_handler({"t": "VOICE_SERVER_UPDATE", "d": data})

    async def on_voice_state_update(self, data):
        await self.lavalink.voice_update_handler({"t": "VOICE_STATE_UPDATE", "d": data})

    async def connect(self, *, timeout, reconnect, self_deaf=False, self_mute=False):
        self.lavalink.player_manager.create(guild_id=self.channel.guild.id)
        await self.channel.guild.change_voice_state(channel=self.channel, self_mute=self_mute, self_deaf=self_deaf)

    async def disconnect(self, *, force=False):
        await self.channel.guild.change_voice_state(channel=None)
        self.cleanup()


class Music(commands.Cog):
    """Music playback via Lavalink, with Spotify search resolution."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

        if not hasattr(bot, "lavalink"):
            bot.lavalink = lavalink.Client(bot.user.id)
            bot.lavalink.add_node(
                host="localhost",        # your Lavalink server host
                port=2333,               # Lavalink port
                password="youshallnotpass",
                region="eu",             # e.g. us, eu
                name="main-node",
            )
            bot.add_listener(bot.lavalink.voice_update_handler)

        # v5 API: hooks are registered on the client, not the module
        bot.lavalink.add_event_hooks(self)

        self.sp = spotipy.Spotify(
            auth_manager=SpotifyClientCredentials(
                client_id="SPOTIFY_CLIENT_ID",
                client_secret="SPOTIFY_CLIENT_SECRET",
            )
        )

    async def cog_unload(self):
        self.bot.lavalink._get_node("main-node").destroy()

    def cog_check(self, ctx):
        if not ctx.guild:
            raise commands.NoPrivateMessage()
        return True

    async def _get_player(self, guild_id: int):
        player = self.bot.lavalink.player_manager.get(guild_id)
        if not player:
            player = self.bot.lavalink.player_manager.create(guild_id)
        return player

    # ---- Spotify helpers ----

    def is_spotify_url(self, query: str) -> bool:
        return "open.spotify.com" in query or "spotify:" in query

    def spotify_track_to_query(self, track: dict) -> str:
        artists = " ".join(a["name"] for a in track["artists"])
        return f"{track['name']} {artists}"

    async def resolve_spotify(self, query: str) -> list[str]:
        """Turn a Spotify URL into a list of plain-text search queries."""
        if "open.spotify.com/track/" in query:
            track_id = query.split("/track/")[1].split("?")[0]
            track = self.sp.track(track_id)
            return [self.spotify_track_to_query(track)]
        if "open.spotify.com/album/" in query:
            album_id = query.split("/album/")[1].split("?")[0]
            return [self.spotify_track_to_query(t) for t in self.sp.album(album_id)["tracks"]["items"]][:50]
        if "open.spotify.com/playlist/" in query:
            playlist_id = query.split("/playlist/")[1].split("?")[0]
            items = self.sp.playlist_items(playlist_id)
            return [self.spotify_track_to_query(i["track"]) for i in items["items"] if i["track"]][:50]
        return []

    async def search_first_track(self, query: str):
        """Search YouTube via Lavalink and return the first track, or None."""
        node = self.bot.lavalink._get_node("main-node")
        results = await node.get_tracks(f"ytsearch:{query}")
        if results and results.tracks:
            return results.tracks[0]
        return None

    # ---- Lavalink events ----

    @lavalink.listener(lavalink.events.QueueEndEvent)
    async def on_queue_end(self, event):
        guild = self.bot.get_guild(event.player.guild_id)
        if guild is not None and guild.voice_client:
            await guild.voice_client.disconnect(force=True)

    # ---- Commands ----

    @commands.command(aliases=["p"])
    async def play(self, ctx: commands.Context, *, query: str):
        player = self._get_player(ctx.guild.id)

        if not ctx.author.voice or not ctx.author.voice.channel:
            await ctx.send("Join a voice channel first!")
            return
        if not ctx.voice_client:
            perms = ctx.author.voice.channel.permissions_for(ctx.guild.me)
            if not perms.connect or not perms.speak:
                await ctx.send("I need `CONNECT` and `SPEAK` permissions.")
                return
            await ctx.author.voice.channel.connect(cls=LavalinkVoiceClient)

        if self.is_spotify_url(query):
            queries = await self.resolve_spotify(query)
            if not queries:
                await ctx.send("Couldn't resolve that Spotify link.")
                return
            added = 0
            for q in queries:
                track = await self.search_first_track(q)
                if track:
                    player.add(track=track, requester=ctx.author.id)
                    added += 1
            await ctx.send(f"Queued {added} track(s) from Spotify.")
        else:
            query = query if url_rx.match(query) else f"ytsearch:{query}"
            results = await player.node.get_tracks(query)
            if not results or not results.tracks:
                await ctx.send("Nothing found!")
                return
            if results.load_type == lavalink.LoadType.PLAYLIST:
                for track in results.tracks:
                    player.add(track=track, requester=ctx.author.id)
                await ctx.send(f"Queued {len(results.tracks)} tracks.")
            else:
                track = results.tracks[0]
                await ctx.send(f"Now queuing: **{track.title}**")
                player.add(track=track, requester=ctx.author.id)

        if not player.is_playing:
            await player.play()

    @commands.command()
    async def skip(self, ctx):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.is_playing:
            await ctx.send("Nothing to skip.")
            return
        await player.skip()
        await ctx.send("Skipped!")

    @commands.command()
    async def stop(self, ctx):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if player:
            player.queue.clear()
            await player.stop()
        if ctx.voice_client:
            await ctx.voice_client.disconnect(force=True)
        await ctx.send("Stopped and left the voice channel.")

    @commands.command()
    async def pause(self, ctx):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if player:
            await player.set_pause(True)
            await ctx.send("Paused.")

    @commands.command()
    async def resume(self, ctx):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if player:
            await player.set_pause(False)
            await ctx.send("Resumed.")

    @commands.command(aliases=["np"])
    async def nowplaying(self, ctx):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.current:
            await ctx.send("Nothing playing.")
            return
        await ctx.send(f"Now playing: **{player.current.title}**")

    @commands.command(aliases=["q"])
    async def queue(self, ctx):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.queue:
            await ctx.send("Queue is empty.")
            return
        lines = [f"**{i + 1}.** {t.title}" for i, t in enumerate(player.queue[:10])]
        await ctx.send("\n".join(lines))

    @commands.command()
    async def volume(self, ctx, vol: int):
        if not 0 <= vol <= 100:
            await ctx.send("Volume must be 0-100.")
            return
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if player:
            await player.set_volume(vol)
            await ctx.send(f"Volume set to {vol}%.")

    @play.error
    async def play_error(self, ctx, error):
        if isinstance(error, commands.NoPrivateMessage):
            await ctx.send("Music commands only work in servers.")
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Music(bot))
