import discord
from discord.ext import commands


class Moderation(commands.Cog):
    """Moderation commands: kick, ban, unban, timeout, purge, warn."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        await member.kick(reason=reason)
        await ctx.send(f"Kicked {member.mention} | Reason: {reason}")

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        await member.ban(reason=reason, delete_message_days=0)
        await ctx.send(f"Banned {member.mention} | Reason: {reason}")

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, user: discord.User):
        try:
            await ctx.guild.unban(user)
        except discord.NotFound:
            await ctx.send(f"{user} is not banned.")
            return
        await ctx.send(f"Unbanned {user.mention}.")

    @commands.command()
    @commands.has_permissions(moderate_members=True)
    async def timeout(self, ctx, member: discord.Member, minutes: int, *, reason: str = "No reason provided"):
        await member.timeout(discord.utils.utcnow() + discord.timedelta(minutes=minutes), reason=reason)
        await ctx.send(f"Muted {member.mention} for {minutes} minutes.")

    @commands.command()
    @commands.has_permissions(moderate_members=True)
    async def untimeout(self, ctx, member: discord.Member):
        await member.timeout(None)
        await ctx.send(f"Unmuted {member.mention}.")

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, count: int = 10):
        deleted = await ctx.channel.purge(limit=count + 1)
        await ctx.send(f"Deleted {len(deleted) - 1} messages.", delete_after=5)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def warn(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        try:
            await member.send(f"You have been warned in **{ctx.guild.name}**: {reason}")
        except discord.Forbidden:
            pass
        await ctx.send(f"Warned {member.mention} | Reason: {reason}")

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def slowmode(self, ctx, seconds: int = 0):
        await ctx.channel.edit(slowmode_delay=seconds)
        await ctx.send(f"Slowmode set to {seconds}s.")

    @kick.error
    @ban.error
    @timeout.error
    @purge.error
    async def mod_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("You don't have permission to use that command.")
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send("Missing arguments.")
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))
