import asyncio
import logging

import discord
from discord.ext import commands

logging.basicConfig(level=logging.INFO)

# No privileged intents requested -- a slash-command music bot doesn't need
# message_content or members. If you DO need them later, enable them first in
# the Developer Portal: Applications -> Bot -> Privileged Gateway Intents.
intents = discord.Intents.default()
intents.voice_states = True  # needed to track voice channel membership

bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    await bot.load_extension("cogs.music")
    if not bot.tree.synced:
        try:
            await bot.tree.sync()
        except Exception as e:
            logging.error(f"Slash command sync failed: {e}")


async def main():
    async with bot:
        await bot.load_extension("cogs.music")
        await bot.start("I inserted but i cant send in this")


if __name__ == "__main__":
    asyncio.run(main())
