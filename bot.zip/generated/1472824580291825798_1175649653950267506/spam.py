import time

MESSAGE = "spectravix is femboy"

while True:
    print(MESSAGE)
    time.sleep(1)
