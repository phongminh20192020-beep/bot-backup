import asyncio
from datetime import timedelta
import discord
from discord.ext import commands

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")


def is_mod(ctx):
    return ctx.author.guild_permissions.manage_messages


@bot.command()
@commands.check(is_mod)
async def kick(ctx, member: discord.Member, *, reason="No reason given"):
    await member.kick(reason=reason)
    await ctx.send(f"Kicked {member.mention} | Reason: {reason}")


@bot.command()
@commands.check(is_mod)
async def ban(ctx, member: discord.Member, *, reason="No reason given"):
    await member.ban(reason=reason)
    await ctx.send(f"Banned {member.mention} | Reason: {reason}")


@bot.command()
@commands.check(is_mod)
async def unban(ctx, user: discord.User):
    await ctx.guild.unban(user)
    await ctx.send(f"Unbanned {user.mention}")


@bot.command()
@commands.check(is_mod)
async def timeout(ctx, member: discord.Member, minutes: int, *, reason="No reason given"):
    until = discord.utils.utcnow() + timedelta(minutes=minutes)
    await member.timeout(until, reason=reason)
    await ctx.send(f"Timed out {member.mention} for {minutes} min | Reason: {reason}")


@bot.command()
@commands.check(is_mod)
async def clear(ctx, amount: int):
    amount = min(amount, 100)
    deleted = await ctx.channel.purge(limit=amount + 1)
    await ctx.send(f"Deleted {len(deleted) - 1} messages.", delete_after=5)


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CheckFailure):
        await ctx.send("You don't have permission to use that.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"Missing argument: `{error.param.name}`")
    elif isinstance(error, commands.BadArgument):
        await ctx.send("Couldn't find that user.")
    else:
        raise error


if __name__ == "__main__":
    import os
    bot.run(os.environ["DISCORD_TOKEN"])
