import os
import discord
from discord.ext import commands

# The bot needs the "message content" intent to read "!ping" in messages.
# Enable it in the Discord Developer Portal (Bot -> Privileged Gateway Intents).
intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")


@bot.command()
async def ping(ctx):
    """Replies with Pong."""
    await ctx.send("Pong")


if __name__ == "__main__":
    token = os.environ.get("DISCORD_TOKEN")
    if not token:
        raise SystemExit(
            "Error: DISCORD_TOKEN environment variable is not set. "
            "Set it to your bot token, e.g. `export DISCORD_TOKEN='your-token-here'`."
        )
    bot.run(token)
