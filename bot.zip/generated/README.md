# Ping-Pong Discord Bot

A minimal discord.py bot that replies **Pong** whenever someone types `!ping`.

## Setup

1. **Install the library**

   ```
   pip install -U discord.py
   ```

2. **Get a bot token**
   - Go to https://discord.com/developers/applications and create an application.
   - Under **Bot**, click **Reset Token** and copy it (keep it secret!).
   - Under **Bot -> Privileged Gateway Intents**, enable **Message Content Intent**
     (required for the bot to read `!ping`).

3. **Invite the bot to your server**
   - In the Developer Portal, go to **OAuth2 -> URL Generator**, check the
     `bot` scope and the **Send Messages** + **Read Message History** permissions,
     then open the generated URL.

4. **Run the bot**

   Linux / macOS:
   ```
   export DISCORD_TOKEN='your-token-here'
   python bot.py
   ```

   Windows (PowerShell):
   ```
   $env:DISCORD_TOKEN='your-token-here'
   python bot.py
   ```

5. Type `!ping` in a channel the bot can see — it will reply with **Pong**.
